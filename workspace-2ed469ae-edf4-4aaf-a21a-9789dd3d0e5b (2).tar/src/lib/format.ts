// Number / currency formatting helpers for the game UI.
export function formatNumber(n: number): string {
  if (n < 1000) return Math.floor(n).toString();
  const units = ["", "K", "M", "B", "T", "Qa", "Qi", "Sx", "Sp"];
  let u = 0;
  let v = n;
  while (v >= 1000 && u < units.length - 1) {
    v /= 1000;
    u++;
  }
  const str = v >= 100 ? v.toFixed(0) : v >= 10 ? v.toFixed(1) : v.toFixed(2);
  return `${str}${units[u]}`;
}

export function formatCoins(n: number): string {
  return formatNumber(n);
}

export function formatOre(n: number): string {
  return formatNumber(n);
}

/** compact time like 1m 30s */
export function formatTime(seconds: number): string {
  if (seconds < 1) return `${Math.round(seconds * 10) / 10}s`;
  const s = Math.floor(seconds);
  if (s < 60) return `${s}s`;
  const m = Math.floor(s / 60);
  const rs = s % 60;
  if (m < 60) return rs ? `${m}m ${rs}s` : `${m}m`;
  const h = Math.floor(m / 60);
  const rm = m % 60;
  return rm ? `${h}h ${rm}m` : `${h}h`;
}
