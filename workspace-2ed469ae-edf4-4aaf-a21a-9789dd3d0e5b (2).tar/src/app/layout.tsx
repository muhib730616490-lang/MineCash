import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "sonner";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Deep Delve — Idle Mining Tycoon",
  description:
    "Build a mining empire. Dig deep through 20 floors, hire workers and managers, run a single elevator and transport cart, and turn raw ore into a fortune.",
  keywords: [
    "idle game",
    "mining tycoon",
    "clicker game",
    "idle miner",
    "management game",
    "Next.js game",
  ],
  authors: [{ name: "Deep Delve Studios" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "Deep Delve — Idle Mining Tycoon",
    description: "Dig deep, hire miners, automate production, and grow a mining empire.",
    url: "https://chat.z.ai",
    siteName: "Deep Delve",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Deep Delve — Idle Mining Tycoon",
    description: "Dig deep, hire miners, automate production, and grow a mining empire.",
  },
};

export const viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  themeColor: "#1a1208",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster
          position="top-center"
          theme="dark"
          richColors
          closeButton
          toastOptions={{
            style: {
              borderRadius: "12px",
              border: "1px solid rgba(255,255,255,0.12)",
              background: "rgba(28,20,12,0.92)",
              color: "#fde9c7",
            },
          }}
        />
      </body>
    </html>
  );
}
