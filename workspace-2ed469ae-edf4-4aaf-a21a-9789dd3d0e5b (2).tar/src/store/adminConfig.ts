// Admin-configurable economy values.
// All gameplay economy reads from these values so admins can adjust at runtime
// without changing source code. Persisted in localStorage, editable via Admin Panel.
import { persist, createJSONStorage } from "zustand/middleware";
import { create } from "zustand";

export interface EconomyConfig {
  // Floor unlock costs (coins)
  floorUnlockCoins: Record<number, number>;
  // Floor unlock ad counts (0 = not available)
  floorUnlockAds: Record<number, number>;
  // Miner upgrade cost base + growth
  minerUpgradeBase: number;
  minerUpgradeGrowth: number;
  minerUpgradeFloorMultiplier: number;
  // Miner manager cost
  minerManagerBase: number;
  minerManagerGrowth: number;
  // Elevator / warehouse manager costs
  elevatorManagerCost: number;
  warehouseManagerCost: number;
  // Ore value growth per floor
  oreGrowthMultiplier: number;
  // Starting resources
  startingCoins: number;
  startingGems: number;
  // Gems threshold
  gemsPerCoinThreshold: number;
  // Ad rewards
  adCashSeconds: number;
  adCashMinimum: number;
  adGemReward: number;
  adCooldownMs: number;
  // Boost
  boostMultiplier: number;
  boostDurationMs: number;
}

export interface AdConfig {
  rewardedAdsEnabled: boolean;
  interstitialAdsEnabled: boolean;
  bannerAdsEnabled: boolean;
  adFrequency: number; // max ads per hour
  // Network adapter name — allows connecting any ad network later
  networkProvider: string; // "none" | "admob" | "unity" | "ironsource" | ...
  networkConfig: Record<string, string>;
}

export interface ReferralConfig {
  inviterRewardCoins: number;
  inviterRewardGems: number;
  inviteeRewardCoins: number;
  inviteeRewardGems: number;
  activeThresholdSec: number;
  maxReferrals: number; // 0 = unlimited
}

export interface WithdrawalConfig {
  enabled: boolean;
  minimumWithdrawal: number;
  methods: string[]; // e.g. ["paypal", "bank", "crypto"]
  processingTimeHours: number;
  // Supported crypto currencies for future withdrawals
  cryptoCurrencies: string[]; // e.g. ["USDT", "BTC", "ETH", "BNB"]
}

export interface OfflineConfig {
  /** Offline production efficiency (0..1). Default 0.10 = 10% of online rate. */
  efficiency: number;
  /** Maximum offline accumulation in hours. Default 8. */
  maxHours: number;
}

export interface EventConfig {
  id: string;
  name: string;
  description: string;
  startDate: number;
  endDate: number;
  enabled: boolean;
  rewardType: "coins" | "gems" | "wallet";
  rewardValue: number;
  winnerSelection: "random" | "leaderboard" | "manual";
  winnerCount: number;
  manualWinners: string[]; // player IDs
}

export interface GlobalSettings {
  maintenanceMode: boolean;
  maintenanceMessage: string;
  globalAnnouncement: string;
  announcementEnabled: boolean;
  supportedLanguages: string[];
}

export interface AdminConfigState {
  economy: EconomyConfig;
  ads: AdConfig;
  referral: ReferralConfig;
  withdrawal: WithdrawalConfig;
  offline: OfflineConfig;
  events: EventConfig[];
  settings: GlobalSettings;
  // actions
  updateEconomy: (patch: Partial<EconomyConfig>) => void;
  updateAds: (patch: Partial<AdConfig>) => void;
  updateReferral: (patch: Partial<ReferralConfig>) => void;
  updateWithdrawal: (patch: Partial<WithdrawalConfig>) => void;
  updateOffline: (patch: Partial<OfflineConfig>) => void;
  addEvent: (event: EventConfig) => void;
  updateEvent: (id: string, patch: Partial<EventConfig>) => void;
  deleteEvent: (id: string) => void;
  updateSettings: (patch: Partial<GlobalSettings>) => void;
  resetConfig: () => void;
}

const DEFAULT_ECONOMY: EconomyConfig = {
  floorUnlockCoins: { 2: 5000, 3: 20000, 4: 100000, 5: 600000 },
  floorUnlockAds: { 2: 3, 3: 6, 4: 12, 5: 20, 6: 20, 7: 20, 8: 20, 9: 20, 10: 20 },
  minerUpgradeBase: 50,
  minerUpgradeGrowth: 1.4,
  minerUpgradeFloorMultiplier: 1.15,
  minerManagerBase: 200,
  minerManagerGrowth: 1.35,
  elevatorManagerCost: 500,
  warehouseManagerCost: 500,
  oreGrowthMultiplier: 3.5,
  startingCoins: 1500,
  startingGems: 0,
  gemsPerCoinThreshold: 2000,
  adCashSeconds: 300,
  adCashMinimum: 50,
  adGemReward: 5,
  adCooldownMs: 20000,
  boostMultiplier: 2,
  boostDurationMs: 300000,
};

const DEFAULT_ADS: AdConfig = {
  rewardedAdsEnabled: true,
  interstitialAdsEnabled: false,
  bannerAdsEnabled: false,
  adFrequency: 20,
  networkProvider: "none",
  networkConfig: {},
};

const DEFAULT_REFERRAL: ReferralConfig = {
  inviterRewardCoins: 5000,
  inviterRewardGems: 10,
  inviteeRewardCoins: 2000,
  inviteeRewardGems: 5,
  activeThresholdSec: 60,
  maxReferrals: 0,
};

const DEFAULT_WITHDRAWAL: WithdrawalConfig = {
  enabled: false,
  minimumWithdrawal: 100000,
  methods: ["paypal", "bank", "crypto"],
  processingTimeHours: 48,
  cryptoCurrencies: ["USDT", "BTC", "ETH", "BNB"],
};

const DEFAULT_OFFLINE: OfflineConfig = {
  efficiency: 0.10, // 10% of online production
  maxHours: 8,
};

const DEFAULT_SETTINGS: GlobalSettings = {
  maintenanceMode: false,
  maintenanceMessage: "The game is under maintenance. Please check back soon.",
  globalAnnouncement: "",
  announcementEnabled: false,
  supportedLanguages: ["en", "ar"],
};

export const useAdminConfig = create<AdminConfigState>()(
  persist(
    (set) => ({
      economy: DEFAULT_ECONOMY,
      ads: DEFAULT_ADS,
      referral: DEFAULT_REFERRAL,
      withdrawal: DEFAULT_WITHDRAWAL,
      offline: DEFAULT_OFFLINE,
      events: [],
      settings: DEFAULT_SETTINGS,

      updateEconomy: (patch) =>
        set((s) => ({ economy: { ...s.economy, ...patch } })),
      updateAds: (patch) => set((s) => ({ ads: { ...s.ads, ...patch } })),
      updateReferral: (patch) =>
        set((s) => ({ referral: { ...s.referral, ...patch } })),
      updateWithdrawal: (patch) =>
        set((s) => ({ withdrawal: { ...s.withdrawal, ...patch } })),
      updateOffline: (patch) =>
        set((s) => ({ offline: { ...s.offline, ...patch } })),
      addEvent: (event) =>
        set((s) => ({ events: [...s.events, event] })),
      updateEvent: (id, patch) =>
        set((s) => ({
          events: s.events.map((e) => (e.id === id ? { ...e, ...patch } : e)),
        })),
      deleteEvent: (id) =>
        set((s) => ({ events: s.events.filter((e) => e.id !== id) })),
      updateSettings: (patch) =>
        set((s) => ({ settings: { ...s.settings, ...patch } })),
      resetConfig: () =>
        set({
          economy: DEFAULT_ECONOMY,
          ads: DEFAULT_ADS,
          referral: DEFAULT_REFERRAL,
          withdrawal: DEFAULT_WITHDRAWAL,
          offline: DEFAULT_OFFLINE,
          events: [],
          settings: DEFAULT_SETTINGS,
        }),
    }),
    {
      name: "idle-mining-admin-config-v1",
      storage: createJSONStorage(() => localStorage),
      // NO skipHydration — auto-hydrate synchronously.
      partialize: (s) => ({
        economy: s.economy,
        ads: s.ads,
        referral: s.referral,
        withdrawal: s.withdrawal,
        offline: s.offline,
        events: s.events,
        settings: s.settings,
      }),
    }
  )
);

/* ---- Helper functions that read from admin config ---- */

export function getFloorUnlockCoins(cfg: EconomyConfig, floorId: number): number {
  if (floorId <= 1) return 0;
  if (cfg.floorUnlockCoins[floorId]) return cfg.floorUnlockCoins[floorId];
  const base = cfg.floorUnlockCoins[5] ?? 600000;
  return Math.floor(base * Math.pow(5, floorId - 5));
}

export function getFloorUnlockAds(cfg: EconomyConfig, floorId: number): number {
  if (floorId < 2 || floorId > 10) return 0;
  return cfg.floorUnlockAds[floorId] ?? 0;
}

export function getMinerUpgradeCost(
  cfg: EconomyConfig,
  level: number,
  floorId: number
): number {
  return Math.floor(
    cfg.minerUpgradeBase *
      Math.pow(cfg.minerUpgradeGrowth, level - 1) *
      Math.pow(cfg.minerUpgradeFloorMultiplier, floorId - 1)
  );
}

export function getMinerManagerCost(
  cfg: EconomyConfig,
  floorId: number
): number {
  return Math.floor(
    cfg.minerManagerBase * Math.pow(cfg.minerManagerGrowth, floorId - 1)
  );
}

export function getOreUnitValue(
  cfg: EconomyConfig,
  mineBaseValue: number,
  floorId: number
): number {
  return Math.max(
    1,
    Math.round(mineBaseValue * Math.pow(cfg.oreGrowthMultiplier, floorId - 1))
  );
}
