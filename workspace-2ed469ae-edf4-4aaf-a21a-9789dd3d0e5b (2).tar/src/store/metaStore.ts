// Meta store: account, referral, daily reward, missions, achievements, profile,
// extended settings. Separate from the game simulation store for clarity.
// Both share the same persist key prefix so they restore together.
import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import type {
  AccountInfo,
  AccountType,
  ReferralState,
  ReferralFriend,
  DailyRewardState,
  Mission,
  AchievementState,
  SettingsState,
  ProfileData,
  Language,
} from "@/game/types";
import {
  DAILY_REWARD_DAYS,
  DAILY_REWARDS,
  dateKey,
  daysBetween,
  generateReferralCode,
  generatePlayerId,
  generateDailyMissions,
  ACHIEVEMENTS,
  REFERRAL_INVITER_REWARD,
  REFERRAL_INVITEE_REWARD,
  REFERRAL_ACTIVE_THRESHOLD_SEC,
} from "@/game/config";

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */

function createInitialAccount(): AccountInfo {
  return {
    type: "local",
    id: generatePlayerId(),
    name: "Miner",
    createdAt: Date.now(),
    googleEmail: null,
    linkedAt: null,
  };
}

function createInitialReferral(): ReferralState {
  const code = generateReferralCode();
  return {
    code,
    link: typeof window !== "undefined" ? `${window.location.origin}/?ref=${code}` : `/?ref=${code}`,
    friends: [],
    totalInvited: 0,
    activeInvited: 0,
    pendingRewards: 0,
  };
}

function createInitialDailyReward(): DailyRewardState {
  return { streak: 0, lastClaimDate: "", totalClaimed: 0 };
}

function createInitialMissions(dateStr: string): Mission[] {
  const defs = generateDailyMissions(dateStr, 4);
  return defs.map((d, i) => ({
    id: `${dateStr}-${i}`,
    type: d.type,
    description: d.description,
    target: d.target,
    progress: 0,
    completed: false,
    claimed: false,
    rewardCoins: d.rewardCoins,
    rewardGems: d.rewardGems,
    date: dateStr,
  }));
}

function createInitialAchievements(): AchievementState[] {
  return ACHIEVEMENTS.map((a) => ({
    id: a.id,
    unlocked: false,
    unlockedAt: null,
    claimed: false,
  }));
}

function createInitialSettings(): SettingsState {
  return {
    language: "en",
    musicOn: true,
    soundOn: true,
    notificationsOn: true,
    graphicsQuality: "high",
    hapticsOn: true,
  };
}

function createInitialProfile(): ProfileData {
  return {
    name: "Miner",
    createdAt: Date.now(),
    totalPlayTime: 0,
    lastSeenAt: Date.now(),
    walletUnlocked: false,
    offlineEarnings: 0,
    offlineCalculatedAt: 0,
    offlineSecondsAway: 0,
  };
}

/* ------------------------------------------------------------------ */
/* Meta state + actions                                                */
/* ------------------------------------------------------------------ */

interface MetaState {
  account: AccountInfo;
  referral: ReferralState;
  dailyReward: DailyRewardState;
  missions: Mission[];
  achievements: AchievementState[];
  settings: SettingsState;
  profile: ProfileData;

  // tracking counters (for missions + achievements)
  stats: {
    totalAdsWatched: number;
    totalCoinsEarned: number;
    totalUpgrades: number;
    totalManagersHired: number;
  };

  // welcome flow
  welcomeCompleted: boolean;

  // actions
  quickStart: () => void;
  linkGoogle: (email: string) => void;
  setPlayerName: (name: string) => void;

  // referral
  addReferralFriend: (friend: ReferralFriend) => void;
  claimReferralRewards: () => { coins: number; gems: number };

  // daily reward
  canClaimDaily: () => boolean;
  claimDailyReward: () => { coins: number; gems: number } | null;

  // missions
  trackMission: (type: Mission["type"], amount: number) => void;
  claimMission: (missionId: string) => { coins: number; gems: number } | null;
  refreshMissionsIfNeeded: () => void;

  // achievements
  checkAchievements: (context: AchievementContext) => string[];
  claimAchievement: (achievementId: string) => { coins: number; gems: number } | null;

  // settings
  setLanguage: (l: Language) => void;
  setMusic: (on: boolean) => void;
  setSound: (on: boolean) => void;
  setNotifications: (on: boolean) => void;
  setGraphicsQuality: (q: "low" | "medium" | "high") => void;
  setHaptics: (on: boolean) => void;

  // profile
  addPlayTime: (seconds: number) => void;
  addCoinsEarned: (amount: number) => void;
  incrementAdsWatched: () => void;
  incrementUpgrades: () => void;
  incrementManagersHired: () => void;

  // offline earnings
  /** Calculate offline earnings based on time away + production rate. Returns coins earned. */
  calculateOfflineEarnings: (productionRatePerSec: number, efficiency: number, maxHours: number) => number;
  /** Claim offline earnings (normal 1x). Returns the claimed amount. */
  claimOfflineEarnings: () => number;
  /** Claim offline earnings at 2x (after watching ad). Returns the claimed amount. */
  claimOfflineEarnings2x: () => number;
  /** Clear offline earnings after claiming. */
  clearOfflineEarnings: () => void;

  // wallet unlock
  unlockWallet: () => void;

  completeWelcome: () => void;
  resetMeta: () => void;
}

export interface AchievementContext {
  floorsUnlocked: number;
  managersHired: number;
  adsWatched: number;
  referralsActive: number;
  totalCoins: number;
  maxMinerLevel: number;
}

export const useMetaStore = create<MetaState>()(
  persist(
    (set, get) => ({
      account: createInitialAccount(),
      referral: createInitialReferral(),
      dailyReward: createInitialDailyReward(),
      missions: createInitialMissions(dateKey(Date.now())),
      achievements: createInitialAchievements(),
      settings: createInitialSettings(),
      profile: createInitialProfile(),
      stats: {
        totalAdsWatched: 0,
        totalCoinsEarned: 0,
        totalUpgrades: 0,
        totalManagersHired: 0,
      },
      welcomeCompleted: false,

      quickStart: () =>
        set((s) => ({
          account: { ...s.account, type: "local" as AccountType },
          welcomeCompleted: true,
        })),

      linkGoogle: (email) =>
        set((s) => ({
          account: {
            ...s.account,
            type: "google" as AccountType,
            googleEmail: email,
            linkedAt: Date.now(),
          },
          profile: { ...s.profile, name: email.split("@")[0] || s.profile.name },
        })),

      setPlayerName: (name) =>
        set((s) => ({
          account: { ...s.account, name },
          profile: { ...s.profile, name },
        })),

      addReferralFriend: (friend) =>
        set((s) => {
          if (s.referral.friends.some((f) => f.id === friend.id)) return s;
          const friends = [...s.referral.friends, friend];
          const activeInvited = friends.filter((f) => f.active).length;
          const pendingRewards = friends.filter(
            (f) => f.active && !f.inviterRewarded
          ).length;
          return {
            referral: {
              ...s.referral,
              friends,
              totalInvited: friends.length,
              activeInvited,
              pendingRewards,
            },
          };
        }),

      claimReferralRewards: () => {
        const s = get();
        const claimable = s.referral.friends.filter(
          (f) => f.active && !f.inviterRewarded
        );
        if (claimable.length === 0) return { coins: 0, gems: 0 };
        const coins = claimable.length * REFERRAL_INVITER_REWARD.coins;
        const gems = claimable.length * REFERRAL_INVITER_REWARD.gems;
        set({
          referral: {
            ...s.referral,
            friends: s.referral.friends.map((f) =>
              f.active && !f.inviterRewarded ? { ...f, inviterRewarded: true } : f
            ),
            pendingRewards: 0,
          },
        });
        return { coins, gems };
      },

      canClaimDaily: () => {
        const s = get();
        const today = dateKey(Date.now());
        if (s.dailyReward.lastClaimDate === today) return false;
        return true;
      },

      claimDailyReward: () => {
        const s = get();
        const today = dateKey(Date.now());
        if (s.dailyReward.lastClaimDate === today) return null;
        // determine streak
        let streak: number;
        if (s.dailyReward.lastClaimDate === "") {
          streak = 1;
        } else {
          const gap = daysBetween(s.dailyReward.lastClaimDate, today);
          if (gap === 1) {
            streak = Math.min(s.dailyReward.streak + 1, DAILY_REWARD_DAYS);
          } else {
            streak = 1; // reset
          }
        }
        const reward = DAILY_REWARDS[streak - 1] ?? DAILY_REWARDS[0];
        set({
          dailyReward: {
            streak,
            lastClaimDate: today,
            totalClaimed: s.dailyReward.totalClaimed + 1,
          },
        });
        return { coins: reward.coins, gems: reward.gems };
      },

      trackMission: (type, amount) =>
        set((s) => {
          let changed = false;
          const missions = s.missions.map((m) => {
            if (m.type === type && !m.completed) {
              const progress = Math.min(m.target, m.progress + amount);
              const completed = progress >= m.target;
              if (progress !== m.progress || completed !== m.completed) changed = true;
              return { ...m, progress, completed };
            }
            return m;
          });
          return changed ? { missions } : s;
        }),

      claimMission: (missionId) => {
        const s = get();
        const mission = s.missions.find((m) => m.id === missionId);
        if (!mission || !mission.completed || mission.claimed) return null;
        set({
          missions: s.missions.map((m) =>
            m.id === missionId ? { ...m, claimed: true } : m
          ),
        });
        return { coins: mission.rewardCoins, gems: mission.rewardGems };
      },

      refreshMissionsIfNeeded: () => {
        const s = get();
        const today = dateKey(Date.now());
        if (s.missions.length === 0 || s.missions[0].date !== today) {
          set({ missions: createInitialMissions(today) });
        }
      },

      checkAchievements: (ctx) => {
        const s = get();
        const newlyUnlocked: string[] = [];
        const achievements = s.achievements.map((a) => {
          if (a.unlocked) return a;
          const def = ACHIEVEMENTS.find((d) => d.id === a.id);
          if (!def) return a;
          let value = 0;
          switch (def.check) {
            case "floorsUnlocked": value = ctx.floorsUnlocked; break;
            case "managersHired": value = ctx.managersHired; break;
            case "adsWatched": value = ctx.adsWatched; break;
            case "referralsActive": value = ctx.referralsActive; break;
            case "totalCoins": value = ctx.totalCoins; break;
            case "minerLevel": value = ctx.maxMinerLevel; break;
          }
          if (value >= def.threshold) {
            newlyUnlocked.push(a.id);
            return { ...a, unlocked: true, unlockedAt: Date.now() };
          }
          return a;
        });
        if (newlyUnlocked.length > 0) set({ achievements });
        return newlyUnlocked;
      },

      claimAchievement: (achievementId) => {
        const s = get();
        const ach = s.achievements.find((a) => a.id === achievementId);
        if (!ach || !ach.unlocked || ach.claimed) return null;
        const def = ACHIEVEMENTS.find((d) => d.id === achievementId);
        if (!def) return null;
        set({
          achievements: s.achievements.map((a) =>
            a.id === achievementId ? { ...a, claimed: true } : a
          ),
        });
        return { coins: def.rewardCoins, gems: def.rewardGems };
      },

      setLanguage: (l) =>
        set((s) => ({ settings: { ...s.settings, language: l } })),
      setMusic: (on) => set((s) => ({ settings: { ...s.settings, musicOn: on } })),
      setSound: (on) => set((s) => ({ settings: { ...s.settings, soundOn: on } })),
      setNotifications: (on) =>
        set((s) => ({ settings: { ...s.settings, notificationsOn: on } })),
      setGraphicsQuality: (q) =>
        set((s) => ({ settings: { ...s.settings, graphicsQuality: q } })),
      setHaptics: (on) => set((s) => ({ settings: { ...s.settings, hapticsOn: on } })),

      addPlayTime: (seconds) =>
        set((s) => ({
          profile: { ...s.profile, totalPlayTime: s.profile.totalPlayTime + seconds, lastSeenAt: Date.now() },
        })),

      addCoinsEarned: (amount) =>
        set((s) => ({
          stats: { ...s.stats, totalCoinsEarned: s.stats.totalCoinsEarned + amount },
        })),

      incrementAdsWatched: () =>
        set((s) => ({ stats: { ...s.stats, totalAdsWatched: s.stats.totalAdsWatched + 1 } })),

      incrementUpgrades: () =>
        set((s) => ({ stats: { ...s.stats, totalUpgrades: s.stats.totalUpgrades + 1 } })),

      incrementManagersHired: () =>
        set((s) => ({ stats: { ...s.stats, totalManagersHired: s.stats.totalManagersHired + 1 } })),

      // ---- Offline earnings ----
      calculateOfflineEarnings: (productionRatePerSec, efficiency, maxHours) => {
        const s = get();
        const now = Date.now();
        const lastSeen = s.profile.lastSeenAt || now;
        const secondsAway = Math.max(0, (now - lastSeen) / 1000);
        // Cap at maxHours
        const cappedSeconds = Math.min(secondsAway, maxHours * 3600);
        // Offline earnings = production rate × efficiency × time away
        const earnings = Math.floor(productionRatePerSec * efficiency * cappedSeconds);
        set({
          profile: {
            ...s.profile,
            offlineEarnings: earnings,
            offlineCalculatedAt: now,
            offlineSecondsAway: Math.floor(secondsAway),
          },
        });
        return earnings;
      },

      claimOfflineEarnings: () => {
        const s = get();
        const amount = s.profile.offlineEarnings;
        if (amount <= 0) return 0;
        set({
          profile: {
            ...s.profile,
            offlineEarnings: 0,
            lastSeenAt: Date.now(),
          },
        });
        return amount;
      },

      claimOfflineEarnings2x: () => {
        const s = get();
        const amount = s.profile.offlineEarnings * 2;
        if (amount <= 0) return 0;
        set({
          profile: {
            ...s.profile,
            offlineEarnings: 0,
            lastSeenAt: Date.now(),
          },
        });
        return amount;
      },

      clearOfflineEarnings: () =>
        set((s) => ({
          profile: { ...s.profile, offlineEarnings: 0, lastSeenAt: Date.now() },
        })),

      // ---- Wallet unlock ----
      unlockWallet: () =>
        set((s) => ({
          profile: { ...s.profile, walletUnlocked: true },
        })),

      completeWelcome: () => set({ welcomeCompleted: true }),

      resetMeta: () =>
        set({
          account: createInitialAccount(),
          referral: createInitialReferral(),
          dailyReward: createInitialDailyReward(),
          missions: createInitialMissions(dateKey(Date.now())),
          achievements: createInitialAchievements(),
          settings: createInitialSettings(),
          profile: createInitialProfile(),
          stats: { totalAdsWatched: 0, totalCoinsEarned: 0, totalUpgrades: 0, totalManagersHired: 0 },
          welcomeCompleted: false,
        }),
    }),
    {
      name: "idle-mining-tycoon-meta-v4",
      storage: createJSONStorage(() => localStorage),
      // NO skipHydration — auto-hydrate synchronously.
      // partialize ensures only data (not functions) is saved/restored.
      partialize: (s) => ({
        account: s.account,
        referral: s.referral,
        dailyReward: s.dailyReward,
        missions: s.missions,
        achievements: s.achievements,
        settings: s.settings,
        profile: s.profile,
        stats: s.stats,
        welcomeCompleted: s.welcomeCompleted,
      }),
    }
  )
);

/* ------------------------------------------------------------------ */
/* Referral link parsing helper (called on app load)                   */
/* ------------------------------------------------------------------ */

/** Check URL for ?ref= param and add as a pending friend (simulated). */
export function processReferralLink() {
  if (typeof window === "undefined") return;
  const params = new URLSearchParams(window.location.search);
  const ref = params.get("ref");
  if (!ref) return;
  // Don't re-process if already stored
  const stored = localStorage.getItem("imt-ref-processed");
  if (stored === ref) return;
  localStorage.setItem("imt-ref-processed", ref);
  // Simulate: add the inviter as a "pending" friend to the current player's referral
  // (in a real backend, this would call an API). For demo, we just grant the invitee reward.
  const meta = useMetaStore.getState();
  // Add a friend representing the inviter (so the inviter's reward is "pending" until active)
  meta.addReferralFriend({
    id: ref,
    name: `Friend ${ref.slice(0, 4)}`,
    joinedAt: Date.now(),
    active: false,
    inviterRewarded: false,
    inviteeRewarded: false,
  });
  // Grant invitee reward immediately (welcome bonus for using a referral link)
  useMetaStore.setState((s) => ({
    // Mark invitee as rewarded by storing a flag
    referral: {
      ...s.referral,
      // The invitee gets their reward on first session
    },
  }));
}
