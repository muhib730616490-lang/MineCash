// Zustand game store (Stage 3): single-miner-per-floor system, level 1-20,
// ad-based floor unlock, starting coins for manager purchase, save v3.
import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import type {
  MineId,
  MineRuntime,
  FloorState,
  ElevatorState,
  CartState,
  WarehouseState,
  Language,
  AdRewardType,
} from "@/game/types";
import {
  FLOOR_COUNT,
  MAX_MINER_LEVEL,
  MINES,
  getMineConfig,
  oreUnitValue,
  floorUnlockCostCoins,
  floorUnlockAds,
  canUnlockFloorWithAds,
  minerUpgradeCost,
  minerManagerCost,
  workerCountFromLevel,
  minerCycleTime,
  ORE_PER_BATCH,
  floorProgressRate,
  ELEVATOR_MANAGER_COST,
  WAREHOUSE_MANAGER_COST,
  ELEVATOR_LOAD_TIME,
  ELEVATOR_UNLOAD_TIME,
  elevatorCapacity,
  elevatorTravelPerFloor,
  elevatorCapacityUpgradeCost,
  elevatorSpeedUpgradeCost,
  CART_TRAVEL_TIME,
  CART_SELL_TIME,
  CART_IDLE_DELAY,
  cartCapacity,
  cartLoadTime,
  cartCapacityUpgradeCost,
  cartSpeedUpgradeCost,
  warehouseCapacity,
  warehouseCapacityUpgradeCost,
  GEMS_PER_COIN_THRESHOLD,
  STARTING_COINS,
  STARTING_GEMS,
  AD_COOLDOWN_MS,
  BOOST_DURATION_MS,
  BOOST_MULTIPLIER,
  AD_CASH_SECONDS,
  AD_CASH_MINIMUM,
  AD_GEM_REWARD,
  estimateIncomeRate,
} from "@/game/config";

/* ------------------------------------------------------------------ */
/* Initial state factories                                             */
/* ------------------------------------------------------------------ */

function createInitialFloors(): FloorState[] {
  return Array.from({ length: FLOOR_COUNT }, (_, i) => {
    const id = i + 1;
    return {
      id,
      unlocked: id === 1,
      minerLevel: 1,
      progress: 0,
      pendingOre: 0,
      minerManagerHired: false,
      adsWatched: 0,
    } satisfies FloorState;
  });
}

function createInitialElevator(): ElevatorState {
  return {
    phase: "idle",
    targetFloor: 0,
    currentFloor: 0,
    cargo: 0,
    cargoValue: 0,
    capacityLevel: 0,
    speedLevel: 1,
    managerHired: false,
    timer: 0.5,
    phaseDuration: 0.5,
  };
}

function createInitialCart(): CartState {
  return {
    phase: "idle",
    cargo: 0,
    cargoValue: 0,
    capacityLevel: 0,
    speedLevel: 1,
    managerHired: false,
    position: 0,
    timer: CART_IDLE_DELAY,
    phaseDuration: CART_IDLE_DELAY,
  };
}

function createInitialWarehouse(): WarehouseState {
  return { ore: 0, value: 0, capacityLevel: 0 };
}

function createInitialMine(): MineRuntime {
  return {
    unlocked: true,
    floors: createInitialFloors(),
    elevator: createInitialElevator(),
    cart: createInitialCart(),
    warehouse: createInitialWarehouse(),
  };
}

function createInitialMines(): Record<MineId, MineRuntime> {
  const mines = {} as Record<MineId, MineRuntime>;
  for (const m of MINES) {
    const runtime = createInitialMine();
    runtime.unlocked = !m.locked;
    mines[m.id] = runtime;
  }
  return mines;
}

/* ------------------------------------------------------------------ */
/* Simulation: advance one mine by dt seconds                          */
/* ------------------------------------------------------------------ */

function advanceMine(
  mr: MineRuntime,
  mineBaseValue: number,
  dt: number,
  multiplier: number
): { mine: MineRuntime; coinsEarned: number; lastSaleValue: number } {
  let coinsEarned = 0;
  let lastSaleValue = 0;

  // --- floors: auto-production only when miner manager hired ---
  const floors = mr.floors.map((f) => {
    if (!f.unlocked) return f;
    const rate = floorProgressRate(f.minerLevel, f.minerManagerHired);
    if (rate === 0) return f;
    let progress = f.progress + rate * dt;
    let pendingOre = f.pendingOre;
    let guard = 0;
    while (progress >= 1 && guard < 50) {
      progress -= 1;
      pendingOre += ORE_PER_BATCH;
      guard++;
    }
    pendingOre = Math.min(pendingOre, 100);
    return { ...f, progress, pendingOre };
  });

  const elevator = { ...mr.elevator };
  const cart = { ...mr.cart };
  const warehouse = { ...mr.warehouse };

  const elevCap = elevatorCapacity(elevator.capacityLevel);
  const travelPerFloor = elevatorTravelPerFloor(elevator.speedLevel);
  const whCap = warehouseCapacity(warehouse.capacityLevel);

  // --- ELEVATOR state machine ---
  // The elevator ALWAYS auto-dispatches when there's pending ore or cargo to
  // unload — it never sits idle while work is available. The Elevator Manager
  // adds the ability to chain multiple floors in a single trip (efficiency).
  elevator.timer -= dt;
  if (elevator.phase === "idle") {
    const oreFloors = floors.filter((f) => f.unlocked && f.pendingOre > 0);
    if (elevator.cargo >= elevCap) {
      // Cargo full → ascend to unload (always)
      elevator.phase = "ascending";
      elevator.targetFloor = 0;
      elevator.phaseDuration = Math.max(0.4, elevator.currentFloor * travelPerFloor);
      elevator.timer = elevator.phaseDuration;
    } else if (oreFloors.length > 0) {
      // Pending ore exists → descend to collect (ALWAYS, even without manager)
      const target = oreFloors.reduce((a, b) => (b.id > a.id ? b : a));
      elevator.phase = "descending";
      elevator.targetFloor = target.id;
      elevator.phaseDuration = Math.max(
        0.45,
        Math.abs(target.id - elevator.currentFloor) * travelPerFloor + 0.3
      );
      elevator.timer = elevator.phaseDuration;
    } else if (elevator.cargo > 0) {
      // Cargo exists but no pending ore → ascend to unload
      elevator.phase = "ascending";
      elevator.targetFloor = 0;
      elevator.phaseDuration = Math.max(0.4, elevator.currentFloor * travelPerFloor);
      elevator.timer = elevator.phaseDuration;
    } else {
      // Nothing to do — reset timer to prevent negative accumulation
      elevator.timer = 0.5;
      elevator.phaseDuration = 0.5;
    }
  } else if (elevator.timer <= 0) {
    if (elevator.phase === "descending") {
      elevator.currentFloor = elevator.targetFloor;
      const floor = floors.find((f) => f.id === elevator.currentFloor);
      if (floor) {
        const room = elevCap - elevator.cargo;
        const take = Math.min(floor.pendingOre, room);
        if (take > 0) {
          floor.pendingOre -= take;
          elevator.cargo += take;
          elevator.cargoValue += take * oreUnitValue(mineBaseValue, floor.id);
        }
      }
      elevator.phase = "loading";
      elevator.phaseDuration = ELEVATOR_LOAD_TIME;
      elevator.timer = ELEVATOR_LOAD_TIME;
    } else if (elevator.phase === "loading") {
      const room = elevCap - elevator.cargo;
      const here = floors.find((f) => f.id === elevator.currentFloor);
      const hereMore = here && here.pendingOre > 0 && room > 0;
      const otherOre = floors.find(
        (f) => f.unlocked && f.pendingOre > 0 && f.id !== elevator.currentFloor
      );
      if (room > 0 && hereMore) {
        const take = Math.min(here!.pendingOre, room);
        here!.pendingOre -= take;
        elevator.cargo += take;
        elevator.cargoValue += take * oreUnitValue(mineBaseValue, here!.id);
        elevator.phase = "loading";
        elevator.phaseDuration = ELEVATOR_LOAD_TIME;
        elevator.timer = ELEVATOR_LOAD_TIME;
      } else if (room > 0 && otherOre && elevator.managerHired) {
        const candidates = floors.filter((f) => f.unlocked && f.pendingOre > 0);
        const target = candidates.reduce((a, b) => (b.id > a.id ? b : a), candidates[0]);
        if (target) {
          elevator.phase = "descending";
          elevator.targetFloor = target.id;
          elevator.phaseDuration = Math.max(
            0.45,
            Math.abs(target.id - elevator.currentFloor) * travelPerFloor + 0.3
          );
          elevator.timer = elevator.phaseDuration;
        }
      } else {
        elevator.phase = "ascending";
        elevator.targetFloor = 0;
        elevator.phaseDuration = Math.max(0.4, elevator.currentFloor * travelPerFloor);
        elevator.timer = elevator.phaseDuration;
      }
    } else if (elevator.phase === "ascending") {
      elevator.currentFloor = 0;
      const drop = Math.min(elevator.cargo, whCap - warehouse.ore);
      if (drop > 0) {
        warehouse.ore += drop;
        warehouse.value += elevator.cargoValue;
      }
      elevator.cargo = 0;
      elevator.cargoValue = 0;
      elevator.phase = "unloading";
      elevator.phaseDuration = ELEVATOR_UNLOAD_TIME;
      elevator.timer = ELEVATOR_UNLOAD_TIME;
    } else if (elevator.phase === "unloading") {
      elevator.phase = "idle";
      elevator.timer = 0.2;
      elevator.phaseDuration = 0.2;
    }
  }

  // --- CART state machine ---
  // The cart ALWAYS auto-dispatches when there's ore in the warehouse — it
  // never sits idle while ore is waiting to be sold. The Warehouse Manager
  // is kept for future upgrades (e.g. faster auto-sell, multiple carts).
  const cCap = cartCapacity(cart.capacityLevel);
  const cLoadTime = cartLoadTime(cart.speedLevel);
  cart.timer -= dt;
  if (cart.phase === "idle") {
    if (warehouse.ore > 0) {
      cart.phase = "loading";
      cart.phaseDuration = cLoadTime;
      cart.timer = cLoadTime;
    } else {
      // reset timer to prevent negative accumulation
      cart.timer = CART_IDLE_DELAY;
      cart.phaseDuration = CART_IDLE_DELAY;
    }
  } else if (cart.timer <= 0) {
    if (cart.phase === "loading") {
      const take = Math.min(warehouse.ore, cCap);
      cart.cargo = take;
      cart.cargoValue = warehouse.ore > 0 ? Math.round(warehouse.value * (take / warehouse.ore)) : 0;
      warehouse.ore -= take;
      warehouse.value -= cart.cargoValue;
      cart.phase = "departing";
      cart.position = 1;
      cart.phaseDuration = CART_TRAVEL_TIME;
      cart.timer = CART_TRAVEL_TIME;
    } else if (cart.phase === "departing") {
      cart.phase = "selling";
      cart.phaseDuration = CART_SELL_TIME;
      cart.timer = CART_SELL_TIME;
    } else if (cart.phase === "selling") {
      coinsEarned += cart.cargoValue;
      lastSaleValue = cart.cargoValue;
      cart.cargo = 0;
      cart.cargoValue = 0;
      cart.phase = "returning";
      cart.position = 0;
      cart.phaseDuration = CART_TRAVEL_TIME;
      cart.timer = CART_TRAVEL_TIME;
    } else if (cart.phase === "returning") {
      cart.phase = "idle";
      cart.phaseDuration = CART_IDLE_DELAY;
      cart.timer = CART_IDLE_DELAY;
    }
  }

  coinsEarned = Math.round(coinsEarned * multiplier);

  return {
    mine: { ...mr, floors, elevator, cart, warehouse },
    coinsEarned,
    lastSaleValue,
  };
}

/* ------------------------------------------------------------------ */
/* Store interface                                                     */
/* ------------------------------------------------------------------ */

interface GameState {
  coins: number;
  gems: number;
  gemsProgress: number;
  activeMine: MineId;
  mines: Record<MineId, MineRuntime>;
  hydrated: boolean;
  firstLaunch: boolean;
  language: Language;
  soundOn: boolean;

  // boost / ads
  boostMultiplier: number;
  boostUntil: number;
  lastAdTime: number;

  // last sale value (for floating coin animation)
  lastSaleValue: number;
  lastSaleAt: number;

  // actions
  setActiveMine: (id: MineId) => void;
  upgradeMiner: (floorId: number) => void;
  hireMinerManager: (floorId: number) => void;
  unlockFloor: (floorId: number) => void;
  watchAdForFloorUnlock: (floorId: number) => void;
  tapFloor: (floorId: number) => void;

  upgradeElevatorCapacity: () => void;
  upgradeElevatorSpeed: () => void;
  hireElevatorManager: () => void;
  dispatchElevator: () => void;

  upgradeCartCapacity: () => void;
  upgradeCartSpeed: () => void;
  upgradeWarehouseCapacity: () => void;
  hireWarehouseManager: () => void;
  dispatchCart: () => void;

  tick: (dt: number) => void;
  claimAdReward: (type: AdRewardType) => number | void;
  canWatchAd: () => boolean;

  setHydrated: (v: boolean) => void;
  setLanguage: (l: Language) => void;
  completeFirstLaunch: (l: Language) => void;
  toggleSound: () => void;
  resetGame: () => void;
  grantGems: (n: number) => void;
  grantCoins: (n: number) => void;
  grantReward: (coins: number, gems: number) => void;
}

/* ------------------------------------------------------------------ */
/* Store implementation                                                */
/* ------------------------------------------------------------------ */

export const useGameStore = create<GameState>()(
  persist(
    (set, get) => ({
      coins: STARTING_COINS,
      gems: STARTING_GEMS,
      gemsProgress: 0,
      activeMine: "copper",
      mines: createInitialMines(),
      // hydrated = true by default: Zustand persist auto-hydrates synchronously
      // from localStorage during store creation, so by the time React renders
      // the persisted state is already loaded.
      hydrated: true,
      firstLaunch: true,
      language: "en",
      soundOn: true,
      boostMultiplier: 1,
      boostUntil: 0,
      lastAdTime: 0,
      lastSaleValue: 0,
      lastSaleAt: 0,

      setActiveMine: (id) => {
        const mr = get().mines[id];
        if (mr && mr.unlocked) set({ activeMine: id });
      },

      // Upgrade miner level (1..20). At L10 → 2 workers, L20 → 3 workers.
      upgradeMiner: (floorId) =>
        set((s) => {
          const mine = s.mines[s.activeMine];
          const floor = mine.floors.find((f) => f.id === floorId);
          if (!floor || !floor.unlocked || floor.minerLevel >= MAX_MINER_LEVEL) return s;
          const cost = minerUpgradeCost(floor.minerLevel, floorId);
          if (s.coins < cost) return s;
          const floors = mine.floors.map((f) =>
            f.id === floorId ? { ...f, minerLevel: f.minerLevel + 1 } : f
          );
          return {
            coins: s.coins - cost,
            mines: { ...s.mines, [s.activeMine]: { ...mine, floors } },
          };
        }),

      hireMinerManager: (floorId) =>
        set((s) => {
          const mine = s.mines[s.activeMine];
          const floor = mine.floors.find((f) => f.id === floorId);
          if (!floor || !floor.unlocked || floor.minerManagerHired) return s;
          const cost = minerManagerCost(floorId);
          if (s.coins < cost) return s;
          const floors = mine.floors.map((f) =>
            f.id === floorId ? { ...f, minerManagerHired: true } : f
          );
          return {
            coins: s.coins - cost,
            mines: { ...s.mines, [s.activeMine]: { ...mine, floors } },
          };
        }),

      // Unlock floor with coins
      unlockFloor: (floorId) =>
        set((s) => {
          const mine = s.mines[s.activeMine];
          const floor = mine.floors.find((f) => f.id === floorId);
          if (!floor || floor.unlocked) return s;
          const prev = mine.floors.find((f) => f.id === floorId - 1);
          if (!prev || !prev.unlocked) return s;
          const cost = floorUnlockCostCoins(floorId);
          if (s.coins < cost) return s;
          const floors = mine.floors.map((f) =>
            f.id === floorId ? { ...f, unlocked: true } : f
          );
          const mines = { ...s.mines, [s.activeMine]: { ...mine, floors } };
          // Check if this unlock completes the mine (floor 20) → unlock next mine
          if (floorId === FLOOR_COUNT) {
            if (s.activeMine === "copper" && !mines.gold.unlocked) {
              mines.gold = { ...mines.gold, unlocked: true };
              // Unlock the wallet permanently when Gold Mine is first reached.
              // Lazy import to avoid circular dependency + reduce bundle size.
              import("@/store/metaStore").then(({ useMetaStore }) => {
                useMetaStore.getState().unlockWallet();
              });
            } else if (s.activeMine === "gold" && !mines.rawGold.unlocked) {
              mines.rawGold = { ...mines.rawGold, unlocked: true };
            }
          }
          return { coins: s.coins - cost, mines };
        }),

      // Watch ad to progress floor unlock (floors 2-10 only)
      watchAdForFloorUnlock: (floorId) =>
        set((s) => {
          const mine = s.mines[s.activeMine];
          const floor = mine.floors.find((f) => f.id === floorId);
          if (!floor || floor.unlocked) return s;
          if (!canUnlockFloorWithAds(floorId)) return s;
          const required = floorUnlockAds(floorId);
          const newAdsWatched = floor.adsWatched + 1;
          const willUnlock = newAdsWatched >= required;
          const floors = mine.floors.map((f) =>
            f.id === floorId
              ? { ...f, adsWatched: newAdsWatched, unlocked: willUnlock }
              : f
          );
          const mines = { ...s.mines, [s.activeMine]: { ...mine, floors } };
          if (willUnlock && floorId === FLOOR_COUNT) {
            if (s.activeMine === "copper" && !mines.gold.unlocked) {
              mines.gold = { ...mines.gold, unlocked: true };
            } else if (s.activeMine === "gold" && !mines.rawGold.unlocked) {
              mines.rawGold = { ...mines.rawGold, unlocked: true };
            }
          }
          return { mines };
        }),

      // Manual tap: produce one batch instantly (only without miner manager)
      tapFloor: (floorId) =>
        set((s) => {
          const mine = s.mines[s.activeMine];
          const floor = mine.floors.find((f) => f.id === floorId);
          if (!floor || !floor.unlocked) return s;
          if (floor.minerManagerHired) return s; // auto, no tap needed
          const floors = mine.floors.map((f) =>
            f.id === floorId
              ? { ...f, progress: 0, pendingOre: Math.min(f.pendingOre + ORE_PER_BATCH, 100) }
              : f
          );
          return { mines: { ...s.mines, [s.activeMine]: { ...mine, floors } } };
        }),

      upgradeElevatorCapacity: () =>
        set((s) => {
          const mine = s.mines[s.activeMine];
          const cost = elevatorCapacityUpgradeCost(mine.elevator.capacityLevel);
          if (s.coins < cost) return s;
          return {
            coins: s.coins - cost,
            mines: {
              ...s.mines,
              [s.activeMine]: {
                ...mine,
                elevator: { ...mine.elevator, capacityLevel: mine.elevator.capacityLevel + 1 },
              },
            },
          };
        }),

      upgradeElevatorSpeed: () =>
        set((s) => {
          const mine = s.mines[s.activeMine];
          const cost = elevatorSpeedUpgradeCost(mine.elevator.speedLevel);
          if (s.coins < cost) return s;
          return {
            coins: s.coins - cost,
            mines: {
              ...s.mines,
              [s.activeMine]: {
                ...mine,
                elevator: { ...mine.elevator, speedLevel: mine.elevator.speedLevel + 1 },
              },
            },
          };
        }),

      hireElevatorManager: () =>
        set((s) => {
          const mine = s.mines[s.activeMine];
          if (mine.elevator.managerHired) return s;
          if (s.coins < ELEVATOR_MANAGER_COST) return s;
          return {
            coins: s.coins - ELEVATOR_MANAGER_COST,
            mines: {
              ...s.mines,
              [s.activeMine]: {
                ...mine,
                elevator: { ...mine.elevator, managerHired: true },
              },
            },
          };
        }),

      dispatchElevator: () =>
        set((s) => {
          const mine = s.mines[s.activeMine];
          const e = mine.elevator;
          if (e.phase !== "idle") return s;
          const oreFloors = mine.floors.filter((f) => f.unlocked && f.pendingOre > 0);
          const travelPerFloor = elevatorTravelPerFloor(e.speedLevel);
          if (e.cargo > 0) {
            const elevator = {
              ...e,
              phase: "ascending" as const,
              targetFloor: 0,
              phaseDuration: Math.max(0.4, e.currentFloor * travelPerFloor),
              timer: Math.max(0.4, e.currentFloor * travelPerFloor),
            };
            return { mines: { ...s.mines, [s.activeMine]: { ...mine, elevator } } };
          } else if (oreFloors.length > 0) {
            const target = oreFloors.reduce((a, b) => (b.id > a.id ? b : a));
            const elevator = {
              ...e,
              phase: "descending" as const,
              targetFloor: target.id,
              phaseDuration: Math.max(0.45, Math.abs(target.id - e.currentFloor) * travelPerFloor + 0.3),
              timer: Math.max(0.45, Math.abs(target.id - e.currentFloor) * travelPerFloor + 0.3),
            };
            return { mines: { ...s.mines, [s.activeMine]: { ...mine, elevator } } };
          }
          return s;
        }),

      upgradeCartCapacity: () =>
        set((s) => {
          const mine = s.mines[s.activeMine];
          const cost = cartCapacityUpgradeCost(mine.cart.capacityLevel);
          if (s.coins < cost) return s;
          return {
            coins: s.coins - cost,
            mines: {
              ...s.mines,
              [s.activeMine]: {
                ...mine,
                cart: { ...mine.cart, capacityLevel: mine.cart.capacityLevel + 1 },
              },
            },
          };
        }),

      upgradeCartSpeed: () =>
        set((s) => {
          const mine = s.mines[s.activeMine];
          const cost = cartSpeedUpgradeCost(mine.cart.speedLevel);
          if (s.coins < cost) return s;
          return {
            coins: s.coins - cost,
            mines: {
              ...s.mines,
              [s.activeMine]: {
                ...mine,
                cart: { ...mine.cart, speedLevel: mine.cart.speedLevel + 1 },
              },
            },
          };
        }),

      upgradeWarehouseCapacity: () =>
        set((s) => {
          const mine = s.mines[s.activeMine];
          const cost = warehouseCapacityUpgradeCost(mine.warehouse.capacityLevel);
          if (s.coins < cost) return s;
          return {
            coins: s.coins - cost,
            mines: {
              ...s.mines,
              [s.activeMine]: {
                ...mine,
                warehouse: { ...mine.warehouse, capacityLevel: mine.warehouse.capacityLevel + 1 },
              },
            },
          };
        }),

      hireWarehouseManager: () =>
        set((s) => {
          const mine = s.mines[s.activeMine];
          if (mine.cart.managerHired) return s;
          if (s.coins < WAREHOUSE_MANAGER_COST) return s;
          return {
            coins: s.coins - WAREHOUSE_MANAGER_COST,
            mines: {
              ...s.mines,
              [s.activeMine]: {
                ...mine,
                cart: { ...mine.cart, managerHired: true },
              },
            },
          };
        }),

      dispatchCart: () =>
        set((s) => {
          const mine = s.mines[s.activeMine];
          const c = mine.cart;
          if (c.phase !== "idle" || mine.warehouse.ore <= 0) return s;
          const loadTime = cartLoadTime(c.speedLevel);
          const cart = { ...c, phase: "loading" as const, phaseDuration: loadTime, timer: loadTime };
          return { mines: { ...s.mines, [s.activeMine]: { ...mine, cart } } };
        }),

      tick: (dt) =>
        set((s) => {
          const boostActive = s.boostUntil > Date.now();
          const multiplier = boostActive ? s.boostMultiplier : 1;
          let coinsEarned = 0;
          let lastSaleValue = 0;
          let lastSaleAt = s.lastSaleAt;
          const mines = { ...s.mines };
          for (const m of MINES) {
            const mr = mines[m.id];
            if (!mr || !mr.unlocked) continue;
            const res = advanceMine(mr, m.baseOreValue, dt, multiplier);
            mines[m.id] = res.mine;
            coinsEarned += res.coinsEarned;
            if (res.lastSaleValue > 0) {
              lastSaleValue = res.lastSaleValue;
              lastSaleAt = Date.now();
            }
          }
          if (coinsEarned <= 0 && lastSaleValue === 0) return { mines };
          let gems = s.gems;
          let gemsProgress = s.gemsProgress + coinsEarned;
          while (gemsProgress >= GEMS_PER_COIN_THRESHOLD) {
            gemsProgress -= GEMS_PER_COIN_THRESHOLD;
            gems += 1;
          }
          return {
            coins: s.coins + coinsEarned,
            gems,
            gemsProgress,
            mines,
            lastSaleValue,
            lastSaleAt,
          };
        }),

      canWatchAd: () => Date.now() - get().lastAdTime >= AD_COOLDOWN_MS,

      claimAdReward: (type) => {
        const s = get();
        if (Date.now() - s.lastAdTime < AD_COOLDOWN_MS) return;
        const cfg = getMineConfig(s.activeMine);
        if (type === "cash") {
          const rate = estimateIncomeRate(s.mines, cfg.baseOreValue, s.activeMine);
          const reward = Math.max(AD_CASH_MINIMUM, Math.floor(rate * AD_CASH_SECONDS));
          set({ coins: s.coins + reward, lastAdTime: Date.now() });
          return reward;
        } else if (type === "boost") {
          set({
            boostMultiplier: BOOST_MULTIPLIER,
            boostUntil: Date.now() + BOOST_DURATION_MS,
            lastAdTime: Date.now(),
          });
          return;
        } else {
          set({ gems: s.gems + AD_GEM_REWARD, lastAdTime: Date.now() });
          return AD_GEM_REWARD;
        }
      },

      setHydrated: (v) => set({ hydrated: v }),
      setLanguage: (l) => set({ language: l }),
      completeFirstLaunch: (l) => set({ firstLaunch: false, language: l }),
      toggleSound: () => set((s) => ({ soundOn: !s.soundOn })),
      grantGems: (n) => set((s) => ({ gems: s.gems + n })),
      grantCoins: (n) => set((s) => ({ coins: s.coins + n })),
      grantReward: (coins, gems) => set((s) => ({ coins: s.coins + coins, gems: s.gems + gems })),

      resetGame: () =>
        set({
          coins: STARTING_COINS,
          gems: STARTING_GEMS,
          gemsProgress: 0,
          activeMine: "copper",
          mines: createInitialMines(),
          boostMultiplier: 1,
          boostUntil: 0,
          lastAdTime: 0,
          lastSaleValue: 0,
          lastSaleAt: 0,
          hydrated: true,
        }),
    }),
    {
      name: "idle-mining-tycoon-v3",
      storage: createJSONStorage(() => localStorage),
      // NO skipHydration — let Zustand auto-hydrate synchronously from localStorage.
      // This prevents the race condition where the default state overwrites the save.
      partialize: (s) => ({
        coins: s.coins,
        gems: s.gems,
        gemsProgress: s.gemsProgress,
        activeMine: s.activeMine,
        mines: s.mines,
        firstLaunch: s.firstLaunch,
        language: s.language,
        soundOn: s.soundOn,
        boostMultiplier: s.boostMultiplier,
        boostUntil: s.boostUntil,
        lastAdTime: s.lastAdTime,
        lastSaleValue: s.lastSaleValue,
        lastSaleAt: s.lastSaleAt,
      }),
      onRehydrateStorage: () => (state) => {
        // Mark as hydrated after auto-rehydration completes.
        if (state) state.hydrated = true;
      },
    }
  )
);

export function selectActiveMine(s: GameState): MineRuntime {
  return s.mines[s.activeMine];
}
