// Player wallet store: balance, reward history, withdrawal history.
// Prepared for future backend integration — no real payment processing.
import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";

export interface WalletTransaction {
  id: string;
  type: "reward" | "withdrawal" | "admin_adjustment" | "referral" | "event";
  description: string;
  amount: number; // positive = credit, negative = debit
  timestamp: number;
  status: "completed" | "pending" | "failed";
}

interface WalletState {
  balance: number; // in wallet currency (coins converted at 1:100000 ratio by default)
  transactions: WalletTransaction[];
  // actions
  addReward: (amount: number, description: string, type?: WalletTransaction["type"]) => void;
  requestWithdrawal: (amount: number, method: string) => boolean;
  adjustBalance: (newBalance: number, note: string) => void;
  getStats: () => {
    totalEarned: number;
    totalWithdrawn: number;
    pendingAmount: number;
    transactionCount: number;
  };
}

// Conversion: 1 wallet unit = 100,000 coins (configurable from admin)
export const WALLET_CONVERSION_RATE = 100000;

function genId(): string {
  return "tx_" + Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
}

export const useWalletStore = create<WalletState>()(
  persist(
    (set, get) => ({
      balance: 0,
      transactions: [],

      addReward: (amount, description, type = "reward") =>
        set((s) => ({
          balance: s.balance + amount,
          transactions: [
            {
              id: genId(),
              type: type as WalletTransaction["type"],
              description,
              amount,
              timestamp: Date.now(),
              status: "completed" as const,
            },
            ...s.transactions,
          ].slice(0, 100),
        })),

      requestWithdrawal: (amount, method) => {
        const s = get();
        if (amount > s.balance) return false;
        set({
          balance: s.balance - amount,
          transactions: [
            {
              id: genId(),
              type: "withdrawal" as const,
              description: `Withdrawal via ${method}`,
              amount: -amount,
              timestamp: Date.now(),
              status: "pending" as const,
            },
            ...s.transactions,
          ].slice(0, 100),
        });
        // Also submit to admin store for processing
        // (imported lazily to avoid circular dependency)
        import("./adminStore").then(({ useAdminStore }) => {
          useAdminStore.getState().submitWithdrawal({
            playerId: "self",
            playerName: "You",
            amount,
            method,
            note: "",
          });
        });
        return true;
      },

      adjustBalance: (newBalance, note) =>
        set((s) => ({
          balance: newBalance,
          transactions: [
            {
              id: genId(),
              type: "admin_adjustment" as const,
              description: note || "Admin adjustment",
              amount: newBalance - s.balance,
              timestamp: Date.now(),
              status: "completed" as const,
            },
            ...s.transactions,
          ].slice(0, 100),
        })),

      getStats: () => {
        const s = get();
        const rewards = s.transactions.filter((t) => t.amount > 0);
        const withdrawals = s.transactions.filter((t) => t.amount < 0);
        const pending = s.transactions.filter((t) => t.status === "pending" && t.amount < 0);
        return {
          totalEarned: rewards.reduce((a, t) => a + t.amount, 0),
          totalWithdrawn: Math.abs(withdrawals.reduce((a, t) => a + t.amount, 0)),
          pendingAmount: Math.abs(pending.reduce((a, t) => a + t.amount, 0)),
          transactionCount: s.transactions.length,
        };
      },
    }),
    {
      name: "idle-mining-wallet-v1",
      storage: createJSONStorage(() => localStorage),
      // NO skipHydration — auto-hydrate synchronously.
      partialize: (s) => ({
        balance: s.balance,
        transactions: s.transactions,
      }),
    }
  )
);
