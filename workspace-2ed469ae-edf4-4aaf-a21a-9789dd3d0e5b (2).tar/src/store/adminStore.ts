// Admin store: players DB (simulated local), analytics, withdrawal requests,
// anti-cheat logs. Prepared for future backend integration.
import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";

export interface AdminPlayer {
  id: string;
  name: string;
  email: string | null;
  coins: number;
  gems: number;
  walletBalance: number;
  createdAt: number;
  lastSeenAt: number;
  totalPlayTime: number;
  floorsUnlocked: number;
  managersHired: number;
  adsWatched: number;
  referralsActive: number;
  banned: boolean;
  isOnline: boolean;
}

export interface WithdrawalRequest {
  id: string;
  playerId: string;
  playerName: string;
  amount: number;
  method: string;
  status: "pending" | "approved" | "rejected" | "completed";
  requestedAt: number;
  processedAt: number | null;
  note: string;
}

export interface AntiCheatLog {
  id: string;
  playerId: string;
  playerName: string;
  type:
    | "duplicate_account"
    | "impossible_production"
    | "modified_data"
    | "ad_abuse"
    | "referral_abuse"
    | "suspicious_wallet";
  description: string;
  severity: "low" | "medium" | "high";
  timestamp: number;
  resolved: boolean;
}

export interface AdminAnalytics {
  totalPlayers: number;
  onlinePlayers: number;
  newPlayersToday: number;
  dailyActiveUsers: number;
  monthlyActiveUsers: number;
  averageSessionTime: number;
  totalRevenue: number;
  totalAdsWatched: number;
  totalReferrals: number;
  totalWithdrawals: number;
  pendingWithdrawals: number;
}

interface AdminState {
  isAdmin: boolean;
  players: AdminPlayer[];
  withdrawals: WithdrawalRequest[];
  antiCheatLogs: AntiCheatLog[];
  // actions
  loginAdmin: (password: string) => boolean;
  logoutAdmin: () => void;
  // players
  upsertPlayer: (player: AdminPlayer) => void;
  modifyPlayerCoins: (playerId: string, coins: number) => void;
  modifyPlayerGems: (playerId: string, gems: number) => void;
  modifyPlayerWallet: (playerId: string, balance: number) => void;
  unlockFloorForPlayer: (playerId: string, floorId: number) => void;
  banPlayer: (playerId: string) => void;
  unbanPlayer: (playerId: string) => void;
  resetPlayerProgress: (playerId: string) => void;
  // withdrawals
  submitWithdrawal: (req: Omit<WithdrawalRequest, "id" | "status" | "requestedAt" | "processedAt">) => void;
  approveWithdrawal: (id: string) => void;
  rejectWithdrawal: (id: string) => void;
  completeWithdrawal: (id: string) => void;
  // anti-cheat
  logSuspicious: (log: Omit<AntiCheatLog, "id" | "timestamp" | "resolved">) => void;
  resolveAntiCheatLog: (id: string) => void;
  // analytics
  getAnalytics: () => AdminAnalytics;
}

// Simple admin password — in production this would be server-side auth.
const ADMIN_PASSWORD = "admin123";

function genId(prefix: string): string {
  return prefix + "_" + Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
}

// Seed with demo players for the admin dashboard
function seedPlayers(): AdminPlayer[] {
  const now = Date.now();
  return [
    {
      id: "p_demo1",
      name: "Miner Alex",
      email: "alex@gmail.com",
      coins: 125000,
      gems: 45,
      walletBalance: 0,
      createdAt: now - 86400000 * 7,
      lastSeenAt: now - 300000,
      totalPlayTime: 3600 * 12,
      floorsUnlocked: 8,
      managersHired: 6,
      adsWatched: 23,
      referralsActive: 2,
      banned: false,
      isOnline: true,
    },
    {
      id: "p_demo2",
      name: "GoldDigger",
      email: "gold@yahoo.com",
      coins: 89000,
      gems: 30,
      walletBalance: 0,
      createdAt: now - 86400000 * 14,
      lastSeenAt: now - 3600000,
      totalPlayTime: 3600 * 24,
      floorsUnlocked: 6,
      managersHired: 4,
      adsWatched: 18,
      referralsActive: 1,
      banned: false,
      isOnline: false,
    },
    {
      id: "p_demo3",
      name: "DeepDiver",
      email: null,
      coins: 4500000,
      gems: 120,
      walletBalance: 0,
      createdAt: now - 86400000 * 30,
      lastSeenAt: now - 60000,
      totalPlayTime: 3600 * 48,
      floorsUnlocked: 20,
      managersHired: 15,
      adsWatched: 87,
      referralsActive: 5,
      banned: false,
      isOnline: true,
    },
  ];
}

export const useAdminStore = create<AdminState>()(
  persist(
    (set, get) => ({
      isAdmin: false,
      players: seedPlayers(),
      withdrawals: [],
      antiCheatLogs: [],

      loginAdmin: (password) => {
        if (password === ADMIN_PASSWORD) {
          set({ isAdmin: true });
          return true;
        }
        return false;
      },
      logoutAdmin: () => set({ isAdmin: false }),

      upsertPlayer: (player) =>
        set((s) => {
          const idx = s.players.findIndex((p) => p.id === player.id);
          if (idx >= 0) {
            const players = [...s.players];
            players[idx] = player;
            return { players };
          }
          return { players: [...s.players, player] };
        }),

      modifyPlayerCoins: (playerId, coins) =>
        set((s) => ({
          players: s.players.map((p) =>
            p.id === playerId ? { ...p, coins } : p
          ),
        })),

      modifyPlayerGems: (playerId, gems) =>
        set((s) => ({
          players: s.players.map((p) =>
            p.id === playerId ? { ...p, gems } : p
          ),
        })),

      modifyPlayerWallet: (playerId, balance) =>
        set((s) => ({
          players: s.players.map((p) =>
            p.id === playerId ? { ...p, walletBalance: balance } : p
          ),
        })),

      unlockFloorForPlayer: (playerId, _floorId) =>
        set((s) => ({
          players: s.players.map((p) =>
            p.id === playerId
              ? { ...p, floorsUnlocked: Math.max(p.floorsUnlocked, _floorId) }
              : p
          ),
        })),

      banPlayer: (playerId) =>
        set((s) => ({
          players: s.players.map((p) =>
            p.id === playerId ? { ...p, banned: true } : p
          ),
        })),

      unbanPlayer: (playerId) =>
        set((s) => ({
          players: s.players.map((p) =>
            p.id === playerId ? { ...p, banned: false } : p
          ),
        })),

      resetPlayerProgress: (playerId) =>
        set((s) => ({
          players: s.players.map((p) =>
            p.id === playerId
              ? {
                  ...p,
                  coins: 1500,
                  gems: 0,
                  walletBalance: 0,
                  floorsUnlocked: 1,
                  managersHired: 0,
                  adsWatched: 0,
                  referralsActive: 0,
                }
              : p
          ),
        })),

      submitWithdrawal: (req) =>
        set((s) => ({
          withdrawals: [
            {
              ...req,
              id: genId("w"),
              status: "pending",
              requestedAt: Date.now(),
              processedAt: null,
            },
            ...s.withdrawals,
          ],
        })),

      approveWithdrawal: (id) =>
        set((s) => ({
          withdrawals: s.withdrawals.map((w) =>
            w.id === id
              ? { ...w, status: "approved", processedAt: Date.now() }
              : w
          ),
        })),

      rejectWithdrawal: (id) =>
        set((s) => ({
          withdrawals: s.withdrawals.map((w) =>
            w.id === id
              ? { ...w, status: "rejected", processedAt: Date.now() }
              : w
          ),
        })),

      completeWithdrawal: (id) =>
        set((s) => ({
          withdrawals: s.withdrawals.map((w) =>
            w.id === id
              ? { ...w, status: "completed", processedAt: Date.now() }
              : w
          ),
        })),

      logSuspicious: (log) =>
        set((s) => ({
          antiCheatLogs: [
            {
              ...log,
              id: genId("ac"),
              timestamp: Date.now(),
              resolved: false,
            },
            ...s.antiCheatLogs,
          ].slice(0, 200), // keep last 200
        })),

      resolveAntiCheatLog: (id) =>
        set((s) => ({
          antiCheatLogs: s.antiCheatLogs.map((l) =>
            l.id === id ? { ...l, resolved: true } : l
          ),
        })),

      getAnalytics: () => {
        const s = get();
        const now = Date.now();
        const oneDay = 86400000;
        const todayStart = now - oneDay;
        const monthStart = now - oneDay * 30;
        const totalPlayers = s.players.length;
        const onlinePlayers = s.players.filter((p) => now - p.lastSeenAt < 300000).length;
        const newPlayersToday = s.players.filter((p) => p.createdAt > todayStart).length;
        const dailyActiveUsers = s.players.filter((p) => p.lastSeenAt > todayStart).length;
        const monthlyActiveUsers = s.players.filter((p) => p.lastSeenAt > monthStart).length;
        const avgSession =
          totalPlayers > 0
            ? Math.round(s.players.reduce((a, p) => a + p.totalPlayTime, 0) / totalPlayers)
            : 0;
        const totalWithdrawals = s.withdrawals.length;
        const pendingWithdrawals = s.withdrawals.filter((w) => w.status === "pending").length;
        return {
          totalPlayers,
          onlinePlayers,
          newPlayersToday,
          dailyActiveUsers,
          monthlyActiveUsers,
          averageSessionTime: avgSession,
          totalRevenue: s.players.reduce((a, p) => a + p.adsWatched, 0) * 0.01, // estimated $0.01/ad
          totalAdsWatched: s.players.reduce((a, p) => a + p.adsWatched, 0),
          totalReferrals: s.players.reduce((a, p) => a + p.referralsActive, 0),
          totalWithdrawals,
          pendingWithdrawals,
        };
      },
    }),
    {
      name: "idle-mining-admin-v1",
      storage: createJSONStorage(() => localStorage),
      // NO skipHydration — auto-hydrate synchronously.
      // isAdmin is intentionally NOT persisted (security: must re-login each session).
      partialize: (s) => ({
        players: s.players,
        withdrawals: s.withdrawals,
        antiCheatLogs: s.antiCheatLogs,
      }),
    }
  )
);
