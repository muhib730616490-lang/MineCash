"use client";
import { useMemo } from "react";
import { useMetaStore } from "@/store/metaStore";
import { translator, isRTL } from "./i18n";
import type { Language } from "./types";

export function useT() {
  const lang = useMetaStore((s) => s.settings.language);
  return useMemo(() => translator(lang as Language), [lang]);
}

export function useRTL() {
  const lang = useMetaStore((s) => s.settings.language);
  return useMemo(() => isRTL(lang as Language), [lang]);
}
