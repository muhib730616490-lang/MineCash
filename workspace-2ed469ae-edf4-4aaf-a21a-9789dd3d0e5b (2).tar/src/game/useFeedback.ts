"use client";
import { useCallback } from "react";
import { useMetaStore } from "@/store/metaStore";

/**
 * Provides haptic + sound feedback for button presses.
 * - Vibration (where supported, e.g. Android)
 * - Sound effect (if sound is enabled in settings)
 * Call the returned function inside any button onClick.
 */
export function useFeedback() {
  const soundOn = useMetaStore((s) => s.settings.soundOn);
  const hapticsOn = useMetaStore((s) => s.settings.hapticsOn);

  return useCallback(
    (type: "tap" | "upgrade" | "purchase" | "success" = "tap") => {
      // Haptic feedback (Android / supported devices)
      if (hapticsOn && typeof navigator !== "undefined" && navigator.vibrate) {
        const patterns: Record<string, number | number[]> = {
          tap: 8,
          upgrade: [10, 20, 10],
          purchase: [15, 30, 15, 30, 25],
          success: [10, 40, 20, 40, 30],
        };
        navigator.vibrate(patterns[type] ?? 8);
      }
      // Sound feedback — lightweight WebAudio beep (no asset loading)
      if (soundOn && typeof window !== "undefined") {
        try {
          const AudioCtx =
            window.AudioContext ||
            (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
          if (!AudioCtx) return;
          const ctx = new AudioCtx();
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.connect(gain);
          gain.connect(ctx.destination);
          const freqs: Record<string, number> = {
            tap: 440,
            upgrade: 660,
            purchase: 880,
            success: 1046,
          };
          osc.frequency.value = freqs[type] ?? 440;
          osc.type = "sine";
          gain.gain.setValueAtTime(0.08, ctx.currentTime);
          gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.12);
          osc.start();
          osc.stop(ctx.currentTime + 0.12);
          // close context to free resources
          osc.onended = () => ctx.close();
        } catch {
          // AudioContext not available — silently ignore
        }
      }
    },
    [soundOn, hapticsOn]
  );
}
