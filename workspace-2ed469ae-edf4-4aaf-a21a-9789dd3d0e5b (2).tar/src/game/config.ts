// Game configuration: mines, ore values, economy curves, helpers (Stage 3)
import type { MineId } from "./types";

export const FLOOR_COUNT = 20;

/* ------------------------------------------------------------------ */
/* Mine configs                                                        */
/* ------------------------------------------------------------------ */

export interface MineConfig {
  id: MineId;
  name: string;
  shortName: string;
  surfaceLabel: string;
  locked: boolean;
  /** base coin value per ore unit at floor 1 */
  baseOreValue: number;
  /** primary accent color (hex) */
  accent: string;
  /** ore vein color */
  oreColor: string;
  /** ore glow color */
  oreGlow: string;
  /** rock tint for this mine's floors */
  rockTint: string;
  rockTintDark: string;
  /** sky/surface palette */
  skyFrom: string;
  skyTo: string;
  groundColor: string;
  icon: string; // emoji fallback
}

export const MINES: MineConfig[] = [
  {
    id: "copper",
    name: "Copper Mine",
    shortName: "Copper",
    surfaceLabel: "COPPER MINE",
    locked: false,
    baseOreValue: 1,
    accent: "#ea580c",
    oreColor: "#c2410c",
    oreGlow: "#fb923c",
    rockTint: "#7c5a43",
    rockTintDark: "#4b3526",
    skyFrom: "#7dd3fc",
    skyTo: "#fef3c7",
    groundColor: "#65a30d",
    icon: "🟠",
  },
  {
    id: "gold",
    name: "Gold Mine",
    shortName: "Gold",
    surfaceLabel: "GOLD MINE",
    locked: true,
    baseOreValue: 7,
    accent: "#ca8a04",
    oreColor: "#a16207",
    oreGlow: "#fde047",
    rockTint: "#6b5b3a",
    rockTintDark: "#3f341f",
    skyFrom: "#fde68a",
    skyTo: "#fb923c",
    groundColor: "#a16207",
    icon: "🟡",
  },
  {
    id: "rawGold",
    name: "Raw Gold Mine",
    shortName: "Raw Gold",
    surfaceLabel: "RAW GOLD MINE",
    locked: true,
    baseOreValue: 49,
    accent: "#d97706",
    oreColor: "#92400e",
    oreGlow: "#fcd34d",
    rockTint: "#574033",
    rockTintDark: "#2e2018",
    skyFrom: "#fca5a5",
    skyTo: "#7c2d12",
    groundColor: "#78350f",
    icon: "⛏️",
  },
];

export function getMineConfig(id: MineId): MineConfig {
  return MINES.find((m) => m.id === id) ?? MINES[0];
}

/* ------------------------------------------------------------------ */
/* Miner system — single miner per floor, level 1..20                  */
/* Level 10 unlocks 2nd worker, Level 20 unlocks 3rd worker           */
/* ------------------------------------------------------------------ */

export const MAX_MINER_LEVEL = 20;

/** Number of workers based on miner level: 1 (L1-9), 2 (L10-19), 3 (L20) */
export function workerCountFromLevel(level: number): number {
  if (level >= 20) return 3;
  if (level >= 10) return 2;
  return 1;
}

/** Seconds for one mining cycle — faster at higher levels */
export function minerCycleTime(level: number): number {
  return Math.max(1.5, 8 - 0.35 * (level - 1));
}

/** Ore produced per completed cycle (fixed at 1) */
export const ORE_PER_BATCH = 1;

/** Miner upgrade cost — exponential growth per level, scaled by floor */
export function minerUpgradeCost(level: number, floorId: number): number {
  return Math.floor(50 * Math.pow(1.4, level - 1) * Math.pow(1.15, floorId - 1));
}

/** Miner Manager hire cost (per floor — enables auto-production) */
export function minerManagerCost(floorId: number): number {
  return Math.floor(200 * Math.pow(1.35, floorId - 1));
}

/** Elevator Manager hire cost (per mine — enables auto-dispatch) */
export const ELEVATOR_MANAGER_COST = 500;

/** Warehouse Manager hire cost (per mine — enables auto-sell) */
export const WAREHOUSE_MANAGER_COST = 500;

/* ------------------------------------------------------------------ */
/* Floor unlock economy — coins OR rewarded ads (floors 2-10 only)    */
/* ------------------------------------------------------------------ */

/** Coin cost to unlock a floor */
export function floorUnlockCostCoins(floorId: number): number {
  if (floorId <= 1) return 0;
  // Specified values for F2-F5, then 5x growth for F6+
  const table: Record<number, number> = {
    2: 5_000,
    3: 20_000,
    4: 100_000,
    5: 600_000,
  };
  if (table[floorId]) return table[floorId];
  // F6+: 600K * 5^(floor-5)
  return Math.floor(600_000 * Math.pow(5, floorId - 5));
}

/** Number of rewarded ads required to unlock a floor (0 = not available) */
export function floorUnlockAds(floorId: number): number {
  if (floorId < 2 || floorId > 10) return 0;
  const table: Record<number, number> = {
    2: 3,
    3: 6,
    4: 12,
    5: 20,
    6: 20,
    7: 20,
    8: 20,
    9: 20,
    10: 20,
  };
  return table[floorId] ?? 0;
}

/** Whether a floor can be unlocked via rewarded ads */
export function canUnlockFloorWithAds(floorId: number): boolean {
  return floorUnlockAds(floorId) > 0;
}

/* ------------------------------------------------------------------ */
/* Ore value — exponential growth per floor so each floor is          */
/* significantly more profitable than the previous                    */
/* ------------------------------------------------------------------ */

const ORE_GROWTH = 3.5;

/** Coin value of one ore unit from a given floor */
export function oreUnitValue(mineBaseValue: number, floorId: number): number {
  return Math.max(1, Math.round(mineBaseValue * Math.pow(ORE_GROWTH, floorId - 1)));
}

/**
 * Auto-production rate (progress per second) for a floor.
 * Returns 0 when no miner manager (manual production only).
 */
export function floorProgressRate(
  minerLevel: number,
  managerHired: boolean
): number {
  if (!managerHired) return 0;
  const cycle = minerCycleTime(minerLevel);
  const workers = workerCountFromLevel(minerLevel);
  return workers / cycle;
}

/* ------------------------------------------------------------------ */
/* Elevator upgrades                                                   */
/* ------------------------------------------------------------------ */

export const ELEVATOR_BASE_CAPACITY = 8;
export const ELEVATOR_CAP_PER_LEVEL = 4;
export const ELEVATOR_TRAVEL_PER_FLOOR = 0.32; // base seconds per floor
export const ELEVATOR_LOAD_TIME = 1.1;
export const ELEVATOR_UNLOAD_TIME = 1.1;

export function elevatorCapacity(level: number): number {
  return ELEVATOR_BASE_CAPACITY + level * ELEVATOR_CAP_PER_LEVEL;
}

/** Travel time per floor, reduced by speed level */
export function elevatorTravelPerFloor(speedLevel: number): number {
  return Math.max(0.12, ELEVATOR_TRAVEL_PER_FLOOR * Math.pow(0.82, speedLevel - 1));
}

export function elevatorCapacityUpgradeCost(level: number): number {
  return Math.floor(120 * Math.pow(1.5, level));
}

export function elevatorSpeedUpgradeCost(level: number): number {
  return Math.floor(90 * Math.pow(1.6, level));
}

/* ------------------------------------------------------------------ */
/* Cart / Warehouse upgrades                                           */
/* ------------------------------------------------------------------ */

export const CART_BASE_CAPACITY = 25;
export const CART_CAP_PER_LEVEL = 10;
export const CART_LOAD_TIME = 1.0;
export const CART_TRAVEL_TIME = 3.2;
export const CART_SELL_TIME = 1.0;
export const CART_IDLE_DELAY = 0.6;

export const WAREHOUSE_BASE_CAPACITY = 200;
export const WAREHOUSE_CAP_PER_LEVEL = 100;

export function cartCapacity(level: number): number {
  return CART_BASE_CAPACITY + level * CART_CAP_PER_LEVEL;
}

/** Cart load time, reduced by speed level */
export function cartLoadTime(speedLevel: number): number {
  return Math.max(0.3, CART_LOAD_TIME * Math.pow(0.8, speedLevel - 1));
}

export function warehouseCapacity(level: number): number {
  return WAREHOUSE_BASE_CAPACITY + level * WAREHOUSE_CAP_PER_LEVEL;
}

export function cartCapacityUpgradeCost(level: number): number {
  return Math.floor(100 * Math.pow(1.45, level));
}

export function cartSpeedUpgradeCost(level: number): number {
  return Math.floor(80 * Math.pow(1.55, level));
}

export function warehouseCapacityUpgradeCost(level: number): number {
  return Math.floor(70 * Math.pow(1.5, level));
}

/* ------------------------------------------------------------------ */
/* Currencies, ads, boost                                              */
/* ------------------------------------------------------------------ */

/** Gems awarded per coins earned (1 gem per this many coins) */
export const GEMS_PER_COIN_THRESHOLD = 2000;

/** Starting coins — enough to buy Floor 1 managers (miner + elevator + warehouse) */
export const STARTING_COINS = 1500;
export const STARTING_GEMS = 0;

/** Ad cooldown (ms) between rewarded ads (bonus coins / boost / gems) */
export const AD_COOLDOWN_MS = 20_000;

/** Boost duration (ms) for the 2x boost ad reward */
export const BOOST_DURATION_MS = 300_000; // 5 minutes
export const BOOST_MULTIPLIER = 2;

/** Instant cash ad reward = this many seconds of income (scales with economy) */
export const AD_CASH_SECONDS = 300; // 5 minutes of income
export const AD_CASH_MINIMUM = 50;

/** Gems from the gems ad reward */
export const AD_GEM_REWARD = 5;

/** Simulated ad duration for floor unlock ads (seconds) */
export const FLOOR_AD_DURATION = 5;

/**
 * Estimate the player's current coins/sec income (for ad rewards).
 * Sums theoretical mining output across all managed floors.
 */
export function estimateIncomeRate(
  mines: Record<MineId, { unlocked: boolean; floors: { id: number; unlocked: boolean; minerLevel: number; minerManagerHired: boolean }[] }>,
  activeBaseValue: number,
  _activeMineId: MineId
): number {
  let total = 0;
  for (const m of MINES) {
    const mr = mines[m.id];
    if (!mr || !mr.unlocked) continue;
    for (const f of mr.floors) {
      if (!f.unlocked || !f.minerManagerHired) continue;
      const cycle = minerCycleTime(f.minerLevel);
      const workers = workerCountFromLevel(f.minerLevel);
      const value = oreUnitValue(m.baseOreValue, f.id);
      total += (workers / cycle) * ORE_PER_BATCH * value;
    }
  }
  // If nothing managed yet, use the active mine's floor 1 as a baseline
  if (total === 0) {
    const cycle = minerCycleTime(1);
    const workers = workerCountFromLevel(1);
    const value = oreUnitValue(activeBaseValue, 1);
    total = (workers / cycle) * ORE_PER_BATCH * value;
  }
  return Math.round(total);
}

/* ================================================================== */
/* META SYSTEMS — referral, daily reward, missions, achievements      */
/* ================================================================== */

/* ---- Daily reward (7-day streak) ---- */
export const DAILY_REWARD_DAYS = 7;
/** coins for each consecutive day (index 0 = day 1) */
export const DAILY_REWARDS: { coins: number; gems: number }[] = [
  { coins: 200, gems: 0 },
  { coins: 500, gems: 1 },
  { coins: 1000, gems: 2 },
  { coins: 2500, gems: 3 },
  { coins: 5000, gems: 5 },
  { coins: 10000, gems: 8 },
  { coins: 25000, gems: 15 },
];

/** Returns YYYY-MM-DD in local time for a timestamp */
export function dateKey(ts: number): string {
  const d = new Date(ts);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

/** Difference in calendar days between two date keys (b - a) */
export function daysBetween(a: string, b: string): number {
  const da = new Date(a + "T00:00:00");
  const db = new Date(b + "T00:00:00");
  return Math.round((db.getTime() - da.getTime()) / 86_400_000);
}

/* ---- Referral rewards (configurable — admin panel would edit these) ---- */
export const REFERRAL_INVITER_REWARD = { coins: 5000, gems: 10 };
export const REFERRAL_INVITEE_REWARD = { coins: 2000, gems: 5 };
/** An invited friend becomes "active" after this many seconds of playtime */
export const REFERRAL_ACTIVE_THRESHOLD_SEC = 60;

/** Generate a unique referral code (8 chars) */
export function generateReferralCode(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for (let i = 0; i < 8; i++) code += chars[Math.floor(Math.random() * chars.length)];
  return code;
}

/** Generate a unique player ID */
export function generatePlayerId(): string {
  return "p_" + Math.random().toString(36).slice(2, 12) + Date.now().toString(36);
}

/* ---- Mission definitions ---- */
export interface MissionDef {
  type: "upgradeMiner" | "unlockFloor" | "collectCoins" | "watchAds" | "hireManager";
  description: string;
  descriptionAr: string;
  target: number;
  rewardCoins: number;
  rewardGems: number;
}

export const MISSION_POOL: MissionDef[] = [
  { type: "upgradeMiner", description: "Upgrade miners 3 times", descriptionAr: "قم بترقية المنقبين 3 مرات", target: 3, rewardCoins: 300, rewardGems: 1 },
  { type: "upgradeMiner", description: "Upgrade miners 5 times", descriptionAr: "قم بترقية المنقبين 5 مرات", target: 5, rewardCoins: 600, rewardGems: 2 },
  { type: "unlockFloor", description: "Unlock a new floor", descriptionAr: "افتح طابقاً جديداً", target: 1, rewardCoins: 500, rewardGems: 1 },
  { type: "collectCoins", description: "Collect 2,000 coins", descriptionAr: "اجمع 2000 عملة", target: 2000, rewardCoins: 400, rewardGems: 1 },
  { type: "collectCoins", description: "Collect 10,000 coins", descriptionAr: "اجمع 10000 عملة", target: 10000, rewardCoins: 1200, rewardGems: 3 },
  { type: "watchAds", description: "Watch 3 rewarded ads", descriptionAr: "شاهد 3 إعلانات بمكافأة", target: 3, rewardCoins: 500, rewardGems: 2 },
  { type: "hireManager", description: "Hire 2 managers", descriptionAr: "وظف مديرين", target: 2, rewardCoins: 800, rewardGems: 2 },
];

/** Pick N distinct missions from the pool for a given date seed */
export function generateDailyMissions(dateStr: string, count: number): MissionDef[] {
  // Simple deterministic shuffle based on date so all players on same day get same set
  const seed = dateStr.split("").reduce((a, c) => a + c.charCodeAt(0), 0);
  const pool = [...MISSION_POOL];
  // Fisher-Yates with seeded PRNG
  let s = seed;
  for (let i = pool.length - 1; i > 0; i--) {
    s = (s * 9301 + 49297) % 233280;
    const j = Math.floor((s / 233280) * (i + 1));
    [pool[i], pool[j]] = [pool[j], pool[i]];
  }
  return pool.slice(0, Math.min(count, pool.length));
}

/* ---- Achievement definitions ---- */
export interface AchievementDef {
  id: string;
  name: string;
  nameAr: string;
  description: string;
  descriptionAr: string;
  icon: string;
  rewardCoins: number;
  rewardGems: number;
  /** function key to evaluate unlock condition */
  check: "floorsUnlocked" | "managersHired" | "adsWatched" | "referralsActive" | "totalCoins" | "minerLevel";
  threshold: number;
}

export const ACHIEVEMENTS: AchievementDef[] = [
  { id: "floor5", name: "First Steps", nameAr: "الخطوات الأولى", description: "Unlock 5 floors", descriptionAr: "افتح 5 طوابق", icon: "⛏️", rewardCoins: 1000, rewardGems: 3, check: "floorsUnlocked", threshold: 5 },
  { id: "floor10", name: "Halfway Down", nameAr: "في منتصف الطريق", description: "Unlock 10 floors", descriptionAr: "افتح 10 طوابق", icon: "🏔️", rewardCoins: 5000, rewardGems: 8, check: "floorsUnlocked", threshold: 10 },
  { id: "floor20", name: "Deep Diver", nameAr: "الغواص العميق", description: "Unlock all 20 floors", descriptionAr: "افتح جميع الطوابق الـ20", icon: "💎", rewardCoins: 25000, rewardGems: 25, check: "floorsUnlocked", threshold: 20 },
  { id: "mgr3", name: "Delegator", nameAr: "المفوّض", description: "Hire 3 managers", descriptionAr: "وظف 3 مديرين", icon: "👨‍💼", rewardCoins: 2000, rewardGems: 5, check: "managersHired", threshold: 3 },
  { id: "mgr10", name: "Executive", nameAr: "المدير التنفيذي", description: "Hire 10 managers", descriptionAr: "وظف 10 مديرين", icon: "🎖️", rewardCoins: 8000, rewardGems: 12, check: "managersHired", threshold: 10 },
  { id: "ads10", name: "Ad Fan", nameAr: "محب الإعلانات", description: "Watch 10 rewarded ads", descriptionAr: "شاهد 10 إعلانات بمكافأة", icon: "📺", rewardCoins: 1500, rewardGems: 4, check: "adsWatched", threshold: 10 },
  { id: "ads50", name: "Ad Master", nameAr: "محترف الإعلانات", description: "Watch 50 rewarded ads", descriptionAr: "شاهد 50 إعلاناً بمكافأة", icon: "🎬", rewardCoins: 6000, rewardGems: 10, check: "adsWatched", threshold: 50 },
  { id: "ref1", name: "Recruiter", nameAr: "المجنّد", description: "Invite 1 active friend", descriptionAr: "ادعُ صديقاً نشطاً واحداً", icon: "👥", rewardCoins: 3000, rewardGems: 8, check: "referralsActive", threshold: 1 },
  { id: "ref5", name: "Influencer", nameAr: "المؤثر", description: "Invite 5 active friends", descriptionAr: "ادعُ 5 أصدقاء نشطين", icon: "🌟", rewardCoins: 15000, rewardGems: 20, check: "referralsActive", threshold: 5 },
  { id: "coins100k", name: "Coin Collector", nameAr: "جامع العملات", description: "Collect 100K coins total", descriptionAr: "اجمع 100 ألف عملة إجمالاً", icon: "💰", rewardCoins: 5000, rewardGems: 6, check: "totalCoins", threshold: 100000 },
  { id: "miner10", name: "Skilled Miner", nameAr: "منقب ماهر", description: "Reach miner level 10", descriptionAr: "صل إلى مستوى المنقب 10", icon: "🔨", rewardCoins: 2000, rewardGems: 4, check: "minerLevel", threshold: 10 },
  { id: "miner20", name: "Master Miner", nameAr: "المنقب المحترف", description: "Reach miner level 20", descriptionAr: "صل إلى مستوى المنقب 20", icon: "👑", rewardCoins: 10000, rewardGems: 15, check: "minerLevel", threshold: 20 },
];

