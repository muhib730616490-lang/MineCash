"use client";
import { useEffect, useRef } from "react";
import { useGameStore } from "@/store/gameStore";
import { useMetaStore } from "@/store/metaStore";
import {
  FLOOR_COUNT,
  MINES,
  dateKey,
} from "@/game/config";

/**
 * Bridges the game store and meta store:
 * - Tracks play time
 * - Tracks coins earned for missions/achievements
 * - Refreshes daily missions
 * - Checks achievements when game state changes
 * - Processes referral link from URL on mount
 */
export function useMetaBridge() {
  const coins = useGameStore((s) => s.coins);
  const mines = useGameStore((s) => s.mines);
  const addPlayTime = useMetaStore((s) => s.addPlayTime);
  const addCoinsEarned = useMetaStore((s) => s.addCoinsEarned);
  const refreshMissions = useMetaStore((s) => s.refreshMissionsIfNeeded);
  const checkAchievements = useMetaStore((s) => s.checkAchievements);
  const lastCoinsRef = useRef(coins);
  const lastCheckRef = useRef(0);

  // Process referral link + refresh missions on mount
  useEffect(() => {
    // processReferralLink is called in Game.tsx on mount to avoid SSR issues
    refreshMissions();
  }, [refreshMissions]);

  // Track play time every 5 seconds
  useEffect(() => {
    const id = setInterval(() => {
      addPlayTime(5);
    }, 5000);
    return () => clearInterval(id);
  }, [addPlayTime]);

  // Track coins earned (for missions + achievements)
  useEffect(() => {
    const diff = coins - lastCoinsRef.current;
    if (diff > 0) {
      addCoinsEarned(diff);
      useMetaStore.getState().trackMission("collectCoins", diff);
    }
    lastCoinsRef.current = coins;
  }, [coins, addCoinsEarned]);

  // Check achievements periodically (every 3s) — cheap computation
  useEffect(() => {
    const id = setInterval(() => {
      const now = Date.now();
      if (now - lastCheckRef.current < 3000) return;
      lastCheckRef.current = now;
      // gather context
      let floorsUnlocked = 0;
      let managersHired = 0;
      let maxMinerLevel = 0;
      for (const m of MINES) {
        const mr = mines[m.id];
        if (!mr || !mr.unlocked) continue;
        for (const f of mr.floors) {
          if (f.unlocked) floorsUnlocked++;
          if (f.minerManagerHired) managersHired++;
          if (f.minerLevel > maxMinerLevel) maxMinerLevel = f.minerLevel;
        }
        if (mr.elevator.managerHired) managersHired++;
        if (mr.cart.managerHired) managersHired++;
      }
      const stats = useMetaStore.getState().stats;
      const referral = useMetaStore.getState().referral;
      checkAchievements({
        floorsUnlocked,
        managersHired,
        adsWatched: stats.totalAdsWatched,
        referralsActive: referral.activeInvited,
        totalCoins: stats.totalCoinsEarned,
        maxMinerLevel,
      });
    }, 3000);
    return () => clearInterval(id);
  }, [mines, checkAchievements]);
}

/** Date key helper re-export for convenience */
export { dateKey };
