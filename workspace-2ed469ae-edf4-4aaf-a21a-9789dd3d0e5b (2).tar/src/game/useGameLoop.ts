"use client";
import { useEffect, useRef } from "react";
import { useGameStore } from "@/store/gameStore";
import { useMetaStore } from "@/store/metaStore";
import { useRTL } from "./useT";

/** Game loop + RTL direction management. */
export function useGameLoop() {
  const tick = useGameStore((s) => s.tick);
  const hydrated = useGameStore((s) => s.hydrated);
  const lastRef = useRef(0);
  const isRTL = useRTL();
  const metaLanguage = useMetaStore((s) => s.settings.language);
  const setGameLanguage = useGameStore((s) => s.setLanguage);

  // Set document direction based on language + sync to game store.
  useEffect(() => {
    document.documentElement.dir = isRTL ? "rtl" : "ltr";
    document.documentElement.lang = isRTL ? "ar" : "en";
    setGameLanguage(metaLanguage);
  }, [isRTL, metaLanguage, setGameLanguage]);

  useEffect(() => {
    if (!hydrated) return;
    lastRef.current = performance.now();
    const id = window.setInterval(() => {
      const now = performance.now();
      const dt = Math.min((now - lastRef.current) / 1000, 5);
      lastRef.current = now;
      if (dt > 0) tick(dt);
    }, 120);
    return () => window.clearInterval(id);
  }, [tick, hydrated]);
}
