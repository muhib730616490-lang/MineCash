"use client";
import { useGameStore } from "@/store/gameStore";
import { getMineConfig } from "./config";

/** Returns the active mine's static config (stable ref; only changes when mine changes). */
export function useActiveMineConfig() {
  const id = useGameStore((s) => s.activeMine);
  return getMineConfig(id);
}
