// Core game types for Idle Mining Tycoon (Stage 4: meta systems)

export type MineId = "copper" | "gold" | "rawGold";

export type WorkerState = "mining" | "walking" | "carrying" | "idle";

export interface FloorState {
  id: number;
  unlocked: boolean;
  minerLevel: number;
  progress: number;
  pendingOre: number;
  minerManagerHired: boolean;
  adsWatched: number;
}

export type ElevatorPhase =
  | "descending"
  | "loading"
  | "ascending"
  | "unloading"
  | "idle";

export interface ElevatorState {
  phase: ElevatorPhase;
  targetFloor: number;
  currentFloor: number;
  cargo: number;
  cargoValue: number;
  capacityLevel: number;
  speedLevel: number;
  managerHired: boolean;
  timer: number;
  phaseDuration: number;
}

export type CartPhase =
  | "idle"
  | "loading"
  | "departing"
  | "selling"
  | "returning";

export interface CartState {
  phase: CartPhase;
  cargo: number;
  cargoValue: number;
  capacityLevel: number;
  speedLevel: number;
  managerHired: boolean;
  position: number;
  timer: number;
  phaseDuration: number;
}

export interface WarehouseState {
  ore: number;
  value: number;
  capacityLevel: number;
}

export interface MineRuntime {
  unlocked: boolean;
  floors: FloorState[];
  elevator: ElevatorState;
  cart: CartState;
  warehouse: WarehouseState;
}

export type Language = "en" | "ar";
export type AdRewardType = "cash" | "boost" | "gems";

/* ------------------------------------------------------------------ */
/* Player account                                                      */
/* ------------------------------------------------------------------ */

export type AccountType = "local" | "google";

export interface AccountInfo {
  type: AccountType;
  id: string; // unique player id
  name: string;
  googleEmail?: string | null;
  createdAt: number;
  linkedAt?: number | null; // when google linked to local
}

/* ------------------------------------------------------------------ */
/* Referral system                                                     */
/* ------------------------------------------------------------------ */

export interface ReferralFriend {
  id: string;
  name: string;
  joinedAt: number;
  active: boolean; // became active (completed first session)
  inviterRewarded: boolean;
  inviteeRewarded: boolean;
}

export interface ReferralState {
  code: string;
  link: string;
  friends: ReferralFriend[];
  totalInvited: number;
  activeInvited: number;
  pendingRewards: number; // unclaimed reward count
}

/* ------------------------------------------------------------------ */
/* Daily reward (7-day streak)                                         */
/* ------------------------------------------------------------------ */

export interface DailyRewardState {
  /** day 1..7 of current streak (0 = no streak) */
  streak: number;
  lastClaimDate: string; // YYYY-MM-DD
  totalClaimed: number;
}

/* ------------------------------------------------------------------ */
/* Missions (daily)                                                    */
/* ------------------------------------------------------------------ */

export type MissionType =
  | "upgradeMiner"
  | "unlockFloor"
  | "collectCoins"
  | "watchAds"
  | "hireManager";

export interface Mission {
  id: string;
  type: MissionType;
  description: string;
  target: number;
  progress: number;
  completed: boolean;
  claimed: boolean;
  rewardCoins: number;
  rewardGems: number;
  /** YYYY-MM-DD — missions regenerate daily */
  date: string;
}

/* ------------------------------------------------------------------ */
/* Achievements                                                        */
/* ------------------------------------------------------------------ */

export interface AchievementState {
  id: string;
  unlocked: boolean;
  unlockedAt: number | null;
  claimed: boolean;
}

/* ------------------------------------------------------------------ */
/* Extended settings                                                   */
/* ------------------------------------------------------------------ */

export interface SettingsState {
  language: Language;
  musicOn: boolean;
  soundOn: boolean;
  notificationsOn: boolean;
  graphicsQuality: "low" | "medium" | "high";
  hapticsOn: boolean;
}

/* ------------------------------------------------------------------ */
/* Profile data                                                        */
/* ------------------------------------------------------------------ */

export interface ProfileData {
  name: string;
  createdAt: number;
  totalPlayTime: number; // seconds
  lastSeenAt: number;
  /** Wallet is permanently unlocked when the player first reaches Gold Mine */
  walletUnlocked: boolean;
  /** Pending offline earnings (coins) calculated on return */
  offlineEarnings: number;
  /** Timestamp when offline earnings were calculated (for "time away" display) */
  offlineCalculatedAt: number;
  /** Seconds the player was away */
  offlineSecondsAway: number;
}
