import type { CSSProperties } from 'react'

export type WorkerState = 'mining' | 'walking' | 'carrying' | 'idle'

export interface WorkerProps {
  state?: WorkerState
  direction?: 'left' | 'right'
  size?: number
  variant?: number
  speed?: number
  className?: string
}

interface Palette {
  helmet: string
  helmetDark: string
  shirt: string
  shirtDark: string
  shirtLight: string
}

const PALETTES: Palette[] = [
  { helmet: '#ff9d2e', helmetDark: '#cf7414', shirt: '#5b7a99', shirtDark: '#3f5a78', shirtLight: '#809dbb' },
  { helmet: '#e8423b', helmetDark: '#b32620', shirt: '#2a9d8f', shirtDark: '#1d7a6e', shirtLight: '#52bbaf' },
  { helmet: '#ffd23f', helmetDark: '#dca81c', shirt: '#8b5a3c', shirtDark: '#6b4226', shirtLight: '#a87a5c' },
  { helmet: '#42b35a', helmetDark: '#2c8244', shirt: '#6b7d3a', shirtDark: '#525e2a', shirtLight: '#8c9d58' },
]

function paletteFor(variant: number): { pal: Palette; idx: number } {
  const idx = ((Math.trunc(variant) % 4) + 4) % 4
  return { pal: PALETTES[idx], idx }
}

const SKIN = '#f4c6a0'
const SKIN_DARK = '#e0a680'
const OVERALLS = '#3a5d8f'
const OVERALLS_DARK = '#26406a'
const OVERALLS_LIGHT = '#5074a8'
const BOOT = '#33210f'
const BOOT_LIGHT = '#5a3a26'
const BELT = '#3e2715'
const BUCKLE = '#e4b85a'
const WOOD = '#9a5e2b'
const WOOD_DARK = '#6e4218'
const METAL = '#aeb5bd'
const METAL_DARK = '#6a7178'
const METAL_LIGHT = '#dde2e8'
const LAMP_CORE = '#fffbe0'
const LAMP_GLOW = '#ffe88a'
const ORE_GLOW = '#5ce0d8'
const ORE_MID = '#2bb8b0'
const ORE_DARK = '#1f7a76'

const STYLES = `
.mw-root{display:inline-block;line-height:0;--mw-speed:1}
.mw-svg{display:block;overflow:visible}
.mw-body{transform-box:view-box}
.mw-body-mining{transform-origin:32px 78px;animation:mw-mine-bob calc(.9s / var(--mw-speed)) ease-in-out infinite}
@keyframes mw-mine-bob{0%,100%{transform:translateY(0)}50%{transform:translateY(-.9px)}}
.mw-arm-mining{transform-box:view-box;transform-origin:41px 36px;animation:mw-swing calc(.9s / var(--mw-speed)) ease-in-out infinite}
@keyframes mw-swing{0%,100%{transform:rotate(-30deg)}45%,55%{transform:rotate(26deg)}}
.mw-body-walking{transform-origin:32px 78px;animation:mw-walk-bob calc(.6s / var(--mw-speed)) ease-in-out infinite}
.mw-body-carrying{transform-origin:32px 78px;animation:mw-walk-bob calc(.78s / var(--mw-speed)) ease-in-out infinite}
@keyframes mw-walk-bob{0%,100%{transform:translateY(0)}25%,75%{transform:translateY(-1.6px)}50%{transform:translateY(0)}}
.mw-leg{transform-box:view-box}
.mw-leg-left.mw-leg-walk{transform-origin:28px 52px;animation:mw-walk-leg calc(.6s / var(--mw-speed)) ease-in-out infinite}
.mw-leg-right.mw-leg-walk{transform-origin:36px 52px;animation:mw-walk-leg calc(.6s / var(--mw-speed)) ease-in-out infinite;animation-delay:calc(-.3s / var(--mw-speed))}
.mw-body-carrying .mw-leg-left.mw-leg-walk{animation-duration:calc(.78s / var(--mw-speed))}
.mw-body-carrying .mw-leg-right.mw-leg-walk{animation-duration:calc(.78s / var(--mw-speed));animation-delay:calc(-.39s / var(--mw-speed))}
@keyframes mw-walk-leg{0%,100%{transform:rotate(17deg)}50%{transform:rotate(-17deg)}}
.mw-arm-walk{transform-box:view-box;transform-origin:41px 36px;animation:mw-arm-sway calc(.6s / var(--mw-speed)) ease-in-out infinite}
@keyframes mw-arm-sway{0%,100%{transform:rotate(-13deg)}50%{transform:rotate(13deg)}}
.mw-arm-back{transform-box:view-box;transform-origin:23px 37px}
.mw-body-walking .mw-arm-back{animation:mw-arm-sway-back calc(.6s / var(--mw-speed)) ease-in-out infinite;animation-delay:calc(-.3s / var(--mw-speed))}
@keyframes mw-arm-sway-back{0%,100%{transform:rotate(11deg)}50%{transform:rotate(-11deg)}}
.mw-body-idle{transform-origin:32px 78px;animation:mw-breathe calc(2.8s / var(--mw-speed)) ease-in-out infinite}
@keyframes mw-breathe{0%,100%{transform:translateY(0) scale(1)}50%{transform:translateY(-.7px) scale(1.01)}}
.mw-lamp{transform-box:view-box;transform-origin:43px 19.5px;animation:mw-lamp-pulse calc(2.2s / var(--mw-speed)) ease-in-out infinite}
@keyframes mw-lamp-pulse{0%,100%{opacity:.65;transform:scale(.95)}50%{opacity:1;transform:scale(1.18)}}
.mw-eye{transform-box:fill-box;transform-origin:center;animation:mw-blink calc(5.2s / var(--mw-speed)) ease-in-out infinite}
.mw-eye.r{animation-delay:calc(-.04s / var(--mw-speed))}
@keyframes mw-blink{0%,91%,100%{transform:scaleY(1)}95%{transform:scaleY(.08)}}
.mw-crate-glow{animation:mw-crate-glow calc(1.6s / var(--mw-speed)) ease-in-out infinite}
@keyframes mw-crate-glow{0%,100%{opacity:.3}50%{opacity:.9}}
.mw-ore-shine{transform-box:fill-box;transform-origin:center;animation:mw-ore-shine calc(2.4s / var(--mw-speed)) ease-in-out infinite}
@keyframes mw-ore-shine{0%,100%{opacity:.5}50%{opacity:1}}
@media (prefers-reduced-motion:reduce){
  .mw-body-mining,.mw-body-walking,.mw-body-carrying,.mw-body-idle,
  .mw-arm-mining,.mw-arm-walk,.mw-leg-walk,.mw-arm-back,
  .mw-lamp,.mw-eye,.mw-crate-glow,.mw-ore-shine{animation:none!important}
}
`

export function Worker({
  state = 'mining',
  direction = 'right',
  size = 72,
  variant = 0,
  speed = 1,
  className,
}: WorkerProps) {
  const { pal, idx } = paletteFor(variant)
  const safeSpeed = speed > 0 ? speed : 1
  const flip = direction === 'left'
  const rootStyle = { '--mw-speed': String(safeSpeed) } as CSSProperties

  const g = {
    helmet: `mw-helmet-${idx}`,
    shirt: `mw-shirt-${idx}`,
    overall: 'mw-overall',
    skin: 'mw-skin',
    metal: 'mw-metal',
    wood: 'mw-wood',
    boot: 'mw-boot',
    lamp: `mw-lamp-g-${idx}`,
    ore: 'mw-ore',
  }

  const bodyClass =
    state === 'mining' ? 'mw-body mw-body-mining' :
    state === 'walking' ? 'mw-body mw-body-walking' :
    state === 'carrying' ? 'mw-body mw-body-carrying' :
    'mw-body mw-body-idle'

  const legWalk = state === 'walking' || state === 'carrying' ? ' mw-leg-walk' : ''
  const showStowed = state === 'walking' || state === 'carrying'

  return (
    <div className={`mw-root${className ? ' ' + className : ''}`} style={rootStyle}>
      <style>{STYLES}</style>
      <svg
        viewBox="0 0 64 80"
        height={size}
        width={size * 0.8}
        shapeRendering="geometricPrecision"
        className="mw-svg"
        style={{ transform: flip ? 'scaleX(-1)' : undefined }}
        aria-hidden="true"
      >
        <defs>
          <linearGradient id={g.helmet} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={pal.helmet} />
            <stop offset="100%" stopColor={pal.helmetDark} />
          </linearGradient>
          <linearGradient id={g.shirt} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={pal.shirtLight} />
            <stop offset="55%" stopColor={pal.shirt} />
            <stop offset="100%" stopColor={pal.shirtDark} />
          </linearGradient>
          <linearGradient id={g.overall} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={OVERALLS_LIGHT} />
            <stop offset="50%" stopColor={OVERALLS} />
            <stop offset="100%" stopColor={OVERALLS_DARK} />
          </linearGradient>
          <radialGradient id={g.skin} cx="0.4" cy="0.35" r="0.75">
            <stop offset="0%" stopColor={SKIN} />
            <stop offset="100%" stopColor={SKIN_DARK} />
          </radialGradient>
          <linearGradient id={g.metal} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={METAL_LIGHT} />
            <stop offset="50%" stopColor={METAL} />
            <stop offset="100%" stopColor={METAL_DARK} />
          </linearGradient>
          <linearGradient id={g.wood} x1="0" y1="0" x2="1" y2="0">
            <stop offset="0%" stopColor={WOOD_DARK} />
            <stop offset="50%" stopColor={WOOD} />
            <stop offset="100%" stopColor={WOOD_DARK} />
          </linearGradient>
          <linearGradient id={g.boot} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={BOOT_LIGHT} />
            <stop offset="100%" stopColor={BOOT} />
          </linearGradient>
          <radialGradient id={g.lamp} cx="0.5" cy="0.5" r="0.5">
            <stop offset="0%" stopColor={LAMP_CORE} />
            <stop offset="45%" stopColor={LAMP_GLOW} />
            <stop offset="100%" stopColor="rgba(255,232,138,0)" />
          </radialGradient>
          <radialGradient id={g.ore} cx="0.5" cy="0.35" r="0.65">
            <stop offset="0%" stopColor="#bff7f1" />
            <stop offset="45%" stopColor={ORE_GLOW} />
            <stop offset="80%" stopColor={ORE_MID} />
            <stop offset="100%" stopColor={ORE_DARK} />
          </radialGradient>
        </defs>

        {/* ground shadow */}
        <ellipse cx="32" cy="77" rx="15" ry="2.2" fill="rgba(18,10,4,0.28)" />

        <g className={bodyClass}>
          {/* stowed pickaxe on back (walking / carrying) */}
          {showStowed && (
            <g className="mw-pickaxe-stowed">
              <line x1="22" y1="34" x2="44" y2="56" stroke={WOOD} strokeWidth="2.8" strokeLinecap="round" />
              <line x1="22" y1="34" x2="44" y2="56" stroke={WOOD_DARK} strokeWidth="0.9" strokeLinecap="round" opacity="0.55" />
              <path d="M 12 32 L 22 28 L 26 36 L 16 40 Z" fill={`url(#${g.metal})`} stroke={METAL_DARK} strokeWidth="0.5" />
              <path d="M 14 33 L 20 30 L 23 35 L 17 38 Z" fill={METAL_LIGHT} opacity="0.65" />
            </g>
          )}

          {/* back arm (hidden behind torso) */}
          {state !== 'carrying' && (
            <g className="mw-arm-back">
              <path d="M 23 37 Q 20 43 19 50" stroke={pal.shirtDark} strokeWidth="5" strokeLinecap="round" fill="none" />
              <circle cx="19" cy="50" r="3" fill={`url(#${g.skin})`} />
            </g>
          )}

          {/* legs */}
          <g className="mw-legs">
            <g className={`mw-leg mw-leg-left${legWalk}`}>
              <rect x="25" y="52" width="6" height="18" rx="2.5" fill={`url(#${g.overall})`} />
              <path d="M 23 68 L 33 68 L 34 76 Q 34 77.5 32.5 77.5 L 23.5 77.5 Q 22 77.5 22 76 Z" fill={`url(#${g.boot})`} />
              <rect x="21.5" y="75.5" width="12.5" height="1.6" rx="0.5" fill={BOOT} />
            </g>
            <g className={`mw-leg mw-leg-right${legWalk}`}>
              <rect x="33" y="52" width="6" height="18" rx="2.5" fill={`url(#${g.overall})`} />
              <path d="M 31 68 L 41 68 L 42 76 Q 42 77.5 40.5 77.5 L 31.5 77.5 Q 30 77.5 30 76 Z" fill={`url(#${g.boot})`} />
              <rect x="29.5" y="75.5" width="12.5" height="1.6" rx="0.5" fill={BOOT} />
            </g>
          </g>

          {/* torso */}
          <g className="mw-torso">
            {/* shirt base */}
            <path d="M 22 36 Q 22 34 24 34 L 40 34 Q 42 34 42 36 L 43 52 L 21 52 Z" fill={`url(#${g.shirt})`} />
            {/* collar shadow */}
            <path d="M 24 34 L 40 34 L 40 36 L 24 36 Z" fill={pal.shirtDark} opacity="0.4" />
            {/* overalls bib */}
            <path d="M 25 42 L 39 42 L 40 54 L 24 54 Z" fill={`url(#${g.overall})`} />
            {/* overall side seams */}
            <path d="M 25 42 L 24 54" stroke={OVERALLS_DARK} strokeWidth="0.6" opacity="0.6" />
            <path d="M 39 42 L 40 54" stroke={OVERALLS_DARK} strokeWidth="0.6" opacity="0.6" />
            {/* straps */}
            <rect x="25" y="35.5" width="2.4" height="9" fill={OVERALLS_DARK} />
            <rect x="36.6" y="35.5" width="2.4" height="9" fill={OVERALLS_DARK} />
            {/* strap highlights */}
            <rect x="25.3" y="35.5" width="0.8" height="9" fill={OVERALLS_LIGHT} opacity="0.5" />
            <rect x="36.9" y="35.5" width="0.8" height="9" fill={OVERALLS_LIGHT} opacity="0.5" />
            {/* strap buckles */}
            <rect x="24.3" y="41.3" width="3.4" height="2.5" rx="0.5" fill={BUCKLE} />
            <rect x="36.3" y="41.3" width="3.4" height="2.5" rx="0.5" fill={BUCKLE} />
            <rect x="24.6" y="41.6" width="2.8" height="0.6" fill="#a07c2e" opacity="0.6" />
            <rect x="36.6" y="41.6" width="2.8" height="0.6" fill="#a07c2e" opacity="0.6" />
            {/* belt */}
            <rect x="21" y="50" width="22" height="4" rx="1" fill={BELT} />
            <rect x="21" y="50" width="22" height="1" fill="#5a3a20" opacity="0.7" />
            {/* buckle */}
            <rect x="29.5" y="50.4" width="5" height="3.2" rx="0.6" fill={BUCKLE} />
            <rect x="30.6" y="51" width="2.8" height="2" rx="0.3" fill={METAL_DARK} />
          </g>

          {/* head */}
          <g className="mw-head">
            {/* neck */}
            <rect x="29.5" y="31" width="5" height="5" fill={SKIN_DARK} />
            {/* ears */}
            <circle cx="21.5" cy="24" r="2.5" fill={`url(#${g.skin})`} />
            <circle cx="42.5" cy="24" r="2.5" fill={`url(#${g.skin})`} />
            <circle cx="21.5" cy="24" r="1.2" fill={SKIN_DARK} opacity="0.5" />
            <circle cx="42.5" cy="24" r="1.2" fill={SKIN_DARK} opacity="0.5" />
            {/* face */}
            <circle cx="32" cy="23" r="10" fill={`url(#${g.skin})`} />
            {/* face shadow under brim */}
            <path d="M 22.5 22 Q 32 25 41.5 22 L 41.5 24 Q 32 26.5 22.5 24 Z" fill="rgba(120,70,40,0.16)" />
            {/* helmet dome */}
            <path d="M 20 22 Q 20 9 32 9 Q 44 9 44 22 Z" fill={`url(#${g.helmet})`} />
            {/* helmet ridge */}
            <path d="M 32 9.5 L 32 22" stroke={pal.helmetDark} strokeWidth="0.6" opacity="0.45" />
            {/* helmet highlight */}
            <path d="M 24.5 14 Q 27.5 11 31 10.5" stroke="rgba(255,255,255,0.55)" strokeWidth="1.6" fill="none" strokeLinecap="round" />
            {/* helmet brim */}
            <path d="M 18 20 L 46 20 L 46 23.6 L 18 23.6 Z" fill={pal.helmetDark} />
            <rect x="18" y="20" width="28" height="1.2" fill={pal.helmet} />
            <rect x="18" y="22.8" width="28" height="0.8" fill="#000" opacity="0.15" />
            {/* headlamp housing */}
            <rect x="40.5" y="17.6" width="5" height="4" rx="1" fill={pal.helmetDark} />
            <rect x="41" y="18" width="4" height="0.8" fill={pal.helmet} opacity="0.7" />
            {/* headlamp glow */}
            <circle className="mw-lamp" cx="43" cy="19.6" r="5.5" fill={`url(#${g.lamp})`} />
            <circle cx="43" cy="19.6" r="1.7" fill={LAMP_CORE} />
            {/* eyebrows (determined) */}
            <path d="M 27.3 22.4 L 30.3 22.7" stroke="#5a3a1a" strokeWidth="0.95" strokeLinecap="round" />
            <path d="M 33.7 22.7 L 36.7 22.4" stroke="#5a3a1a" strokeWidth="0.95" strokeLinecap="round" />
            {/* eyes */}
            <ellipse className="mw-eye" cx="29" cy="25" rx="1.35" ry="1.75" fill="#3a2410" />
            <ellipse className="mw-eye r" cx="35" cy="25" rx="1.35" ry="1.75" fill="#3a2410" />
            <circle cx="29.4" cy="24.4" r="0.42" fill="#fff" />
            <circle cx="35.4" cy="24.4" r="0.42" fill="#fff" />
            {/* smile */}
            <path d="M 28.8 28.4 Q 32 31 35.2 28.4" stroke="#8a3a1a" strokeWidth="1.1" strokeLinecap="round" fill="none" />
            {/* blush */}
            <circle cx="26.5" cy="27.4" r="1.25" fill="rgba(232,118,90,0.32)" />
            <circle cx="37.5" cy="27.4" r="1.25" fill="rgba(232,118,90,0.32)" />
          </g>

          {/* === STATE-SPECIFIC FRONT ARM === */}

          {/* mining: swinging pickaxe */}
          {state === 'mining' && (
            <g className="mw-arm-mining">
              {/* pickaxe (rotates with the arm group) */}
              <line x1="47" y1="46" x2="56" y2="35" stroke={WOOD} strokeWidth="3.2" strokeLinecap="round" />
              <line x1="47" y1="46" x2="56" y2="35" stroke={WOOD_DARK} strokeWidth="0.9" strokeLinecap="round" opacity="0.55" />
              <line x1="48" y1="44.5" x2="55" y2="36.5" stroke="#c08550" strokeWidth="0.5" strokeLinecap="round" opacity="0.5" />
              <path d="M 51.5 32 L 61 29 L 63 35 L 56 39 Z" fill={`url(#${g.metal})`} stroke={METAL_DARK} strokeWidth="0.6" />
              <path d="M 56.5 31 L 61 29 L 62 32 Z" fill={METAL_LIGHT} opacity="0.85" />
              <path d="M 52 33 L 56 39" stroke={METAL_DARK} strokeWidth="0.4" opacity="0.5" />
              {/* sleeve */}
              <path d="M 41 36 Q 43 41 47 46" stroke={pal.shirt} strokeWidth="5.6" strokeLinecap="round" fill="none" />
              <path d="M 41 36 Q 43 41 47 46" stroke={pal.shirtDark} strokeWidth="5.6" strokeLinecap="round" fill="none" opacity="0.35" />
              {/* cuff */}
              <circle cx="47" cy="46" r="2.9" fill={pal.shirtDark} opacity="0.4" />
              {/* hand */}
              <circle cx="47" cy="46" r="3.3" fill={`url(#${g.skin})`} />
            </g>
          )}

          {/* walking: arm swinging at side */}
          {state === 'walking' && (
            <g className="mw-arm-walk">
              <path d="M 41 36 Q 44 41 44 48" stroke={pal.shirt} strokeWidth="5.6" strokeLinecap="round" fill="none" />
              <path d="M 41 36 Q 44 41 44 48" stroke={pal.shirtDark} strokeWidth="5.6" strokeLinecap="round" fill="none" opacity="0.35" />
              <circle cx="44" cy="48" r="3.2" fill={`url(#${g.skin})`} />
            </g>
          )}

          {/* carrying: both arms holding ore crate */}
          {state === 'carrying' && (
            <g className="mw-carry">
              {/* arms reaching to crate (rendered behind crate) */}
              <path d="M 23 37 Q 25 39 28 41" stroke={pal.shirtDark} strokeWidth="5" strokeLinecap="round" fill="none" />
              <path d="M 41 37 Q 43 39 45 41" stroke={pal.shirt} strokeWidth="5" strokeLinecap="round" fill="none" />
              {/* crate */}
              <g className="mw-crate">
                <rect x="27" y="40" width="20" height="13" rx="1.2" fill={WOOD} stroke={WOOD_DARK} strokeWidth="1" />
                <rect x="27" y="40" width="20" height="3" fill="#7a4a1e" opacity="0.5" />
                <line x1="27" y1="44.3" x2="47" y2="44.3" stroke={WOOD_DARK} strokeWidth="0.5" opacity="0.7" />
                <line x1="27" y1="48.6" x2="47" y2="48.6" stroke={WOOD_DARK} strokeWidth="0.5" opacity="0.7" />
                {/* plank seams */}
                <line x1="34" y1="40" x2="34" y2="53" stroke={WOOD_DARK} strokeWidth="0.4" opacity="0.4" />
                <line x1="40" y1="40" x2="40" y2="53" stroke={WOOD_DARK} strokeWidth="0.4" opacity="0.4" />
                {/* ore crystals */}
                <polygon points="32.5,49 35,44 37.5,49 36.2,52 33.8,52" fill={`url(#${g.ore})`} />
                <polygon points="38.5,49 41.5,45 44,49 42.5,52 40,52" fill={`url(#${g.ore})`} opacity="0.88" />
                <polygon className="mw-ore-shine" points="34,46 35.2,44.5 35.8,46.5" fill="#e6fffb" />
                {/* glow halo */}
                <rect className="mw-crate-glow" x="25" y="38" width="24" height="17" rx="2" fill="none" stroke={ORE_GLOW} strokeWidth="0.7" />
              </g>
              {/* hands on crate top corners */}
              <circle cx="28" cy="41" r="2.8" fill={`url(#${g.skin})`} />
              <circle cx="46" cy="41" r="2.8" fill={`url(#${g.skin})`} />
            </g>
          )}

          {/* idle: pickaxe resting on ground */}
          {state === 'idle' && (
            <g className="mw-arm-idle">
              {/* resting pickaxe */}
              <line x1="50" y1="42" x2="50" y2="76" stroke={WOOD} strokeWidth="2.9" strokeLinecap="round" />
              <line x1="50" y1="42" x2="50" y2="76" stroke={WOOD_DARK} strokeWidth="0.9" strokeLinecap="round" opacity="0.5" />
              <path d="M 45.5 38 L 54.5 36 L 56 42 L 47.5 44 Z" fill={`url(#${g.metal})`} stroke={METAL_DARK} strokeWidth="0.5" />
              <path d="M 49.5 37 L 54.5 36 L 55 39 Z" fill={METAL_LIGHT} opacity="0.7" />
              {/* sleeve */}
              <path d="M 41 36 Q 45 39 49.5 42" stroke={pal.shirt} strokeWidth="5.6" strokeLinecap="round" fill="none" />
              <path d="M 41 36 Q 45 39 49.5 42" stroke={pal.shirtDark} strokeWidth="5.6" strokeLinecap="round" fill="none" opacity="0.35" />
              {/* hand resting on handle */}
              <circle cx="50" cy="42" r="3.2" fill={`url(#${g.skin})`} />
            </g>
          )}
        </g>
      </svg>
    </div>
  )
}

export default Worker
