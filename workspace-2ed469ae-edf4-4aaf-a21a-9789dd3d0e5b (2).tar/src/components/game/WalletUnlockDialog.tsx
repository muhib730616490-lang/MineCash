"use client";
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useT } from "@/game/useT";
import { Wallet, Sparkles, Bitcoin, Coins } from "lucide-react";

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
}

/** Beautiful congratulations screen shown when the wallet is first unlocked
 * (triggered when the player reaches the Gold Mine). */
export function WalletUnlockDialog({ open, onOpenChange }: Props) {
  const t = useT();
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="border-amber-500/50 bg-gradient-to-b from-stone-900 to-stone-950 text-amber-50 sm:max-w-md" showCloseButton={false}>
        <DialogTitle className="sr-only">Wallet Unlocked!</DialogTitle>
        <DialogDescription className="sr-only">Your wallet is now available</DialogDescription>

        <div className="flex flex-col items-center gap-4 py-6 text-center">
          {/* Wallet icon with glow */}
          <div className="relative flex size-20 items-center justify-center rounded-full bg-gradient-to-br from-amber-400 to-orange-600 shadow-[0_0_30px_8px_rgba(251,146,60,0.5)]">
            <Wallet className="size-10 text-amber-50" />
            <Sparkles className="absolute -right-2 -top-2 size-6 text-amber-300 animate-pulse" />
          </div>

          <div>
            <h2 className="text-2xl font-extrabold text-amber-200">Wallet Unlocked!</h2>
            <p className="mt-2 text-sm text-amber-200/70">
              Congratulations on reaching the Gold Mine! Your wallet is now permanently unlocked.
            </p>
          </div>

          {/* Crypto currencies preview */}
          <div className="w-full rounded-xl border border-amber-700/40 bg-stone-800/40 p-3">
            <div className="mb-2 text-[10px] font-bold uppercase tracking-wider text-amber-300/70">
              Supported Currencies
            </div>
            <div className="flex items-center justify-around">
              <CryptoBadge icon={<span className="text-lg">₮</span>} label="USDT" color="bg-emerald-600" />
              <CryptoBadge icon={<Bitcoin className="size-4" />} label="BTC" color="bg-orange-500" />
              <CryptoBadge icon={<span className="text-sm font-bold">Ξ</span>} label="ETH" color="bg-indigo-500" />
              <CryptoBadge icon={<span className="text-lg">bnb</span>} label="BNB" color="bg-yellow-500" />
            </div>
          </div>

          <Button
            className="w-full bg-amber-600 text-stone-950 hover:bg-amber-500"
            size="lg"
            onClick={() => onOpenChange(false)}
          >
            Awesome!
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function CryptoBadge({ icon, label, color }: { icon: React.ReactNode; label: string; color: string }) {
  return (
    <div className="flex flex-col items-center gap-1">
      <div className={`flex size-8 items-center justify-center rounded-full text-white ${color}`}>
        {icon}
      </div>
      <span className="text-[9px] font-bold text-amber-200/70">{label}</span>
    </div>
  );
}
