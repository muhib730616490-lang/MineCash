"use client";
import { useState } from "react";
import { PanelDialog } from "./PanelDialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useWalletStore } from "@/store/walletStore";
import { useAdminConfig } from "@/store/adminConfig";
import { useMetaStore } from "@/store/metaStore";
import { useT } from "@/game/useT";
import { formatNumber } from "@/lib/format";
import { Wallet, ArrowDownToLine, ArrowUpFromLine, History, TrendingUp, Clock, CheckCircle, AlertCircle, Lock, Bitcoin } from "lucide-react";
import { toast } from "sonner";

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
}

export function WalletDialog({ open, onOpenChange }: Props) {
  const t = useT();
  const balance = useWalletStore((s) => s.balance);
  const transactions = useWalletStore((s) => s.transactions);
  const requestWithdrawal = useWalletStore((s) => s.requestWithdrawal);
  const withdrawalConfig = useAdminConfig((s) => s.withdrawal);
  const walletUnlocked = useMetaStore((s) => s.profile.walletUnlocked);

  const [showWithdraw, setShowWithdraw] = useState(false);
  const [amount, setAmount] = useState("");
  const [method, setMethod] = useState("USDT");
  const rewards = transactions.filter((t) => t.amount > 0);
  const withdrawalsTx = transactions.filter((t) => t.amount < 0);
  const pendingTx = transactions.filter((t) => t.status === "pending" && t.amount < 0);
  const stats = {
    totalEarned: rewards.reduce((a, t) => a + t.amount, 0),
    totalWithdrawn: Math.abs(withdrawalsTx.reduce((a, t) => a + t.amount, 0)),
    pendingAmount: Math.abs(pendingTx.reduce((a, t) => a + t.amount, 0)),
    transactionCount: transactions.length,
  };

  const minWithdrawal = withdrawalConfig.minimumWithdrawal;
  const canWithdraw = withdrawalConfig.enabled && balance >= minWithdrawal;

  const handleWithdraw = () => {
    const amt = parseFloat(amount);
    if (!amt || amt <= 0) {
      toast.error("Invalid amount");
      return;
    }
    if (amt < minWithdrawal) {
      toast.error(`Minimum withdrawal is ${minWithdrawal}`);
      return;
    }
    if (amt > balance) {
      toast.error("Insufficient balance");
      return;
    }
    const ok = requestWithdrawal(amt, method);
    if (ok) {
      toast.success("Withdrawal requested!", {
        description: `${amt} via ${method} — pending review`,
      });
      setShowWithdraw(false);
      setAmount("");
    }
  };

  // ---- LOCKED STATE: wallet not yet unlocked ----
  if (!walletUnlocked) {
    return (
      <PanelDialog
        open={open}
        onOpenChange={onOpenChange}
        title="Wallet"
        icon={<Wallet className="size-5" />}
      >
        <div className="flex flex-col items-center gap-4 py-6 text-center">
          <div className="relative flex size-16 items-center justify-center rounded-full bg-stone-800 shadow-lg">
            <Lock className="size-8 text-stone-500" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-amber-200">Wallet Locked</h3>
            <p className="mt-2 text-sm text-amber-200/60">
              Unlock the Wallet after reaching the Gold Mine.
            </p>
          </div>
          <div className="rounded-lg border border-amber-900/30 bg-stone-800/40 p-3 text-[10px] text-amber-200/50">
            Complete all 20 floors of the Copper Mine to unlock the Gold Mine and your wallet.
          </div>
        </div>
      </PanelDialog>
    );
  }

  // ---- UNLOCKED STATE: full wallet UI ----
  return (
    <PanelDialog
      open={open}
      onOpenChange={onOpenChange}
      title="Wallet"
      icon={<Wallet className="size-5" />}
      description="Your earnings and withdrawals"
    >
      {/* Balance card */}
      <div className="rounded-xl border border-amber-700/40 bg-gradient-to-br from-amber-900/30 to-stone-900 p-4">
        <div className="text-xs text-amber-300/70">Current Balance</div>
        <div className="mt-1 text-3xl font-extrabold text-amber-200">
          {formatNumber(balance)}
        </div>
        <div className="mt-1 text-[10px] text-amber-300/50">
          ≈ {formatNumber(balance * 100000)} coins
        </div>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 gap-2">
        <StatBox icon={<TrendingUp className="size-3 text-emerald-400" />} label="Total Earned" value={formatNumber(stats.totalEarned)} />
        <StatBox icon={<ArrowUpFromLine className="size-3 text-red-400" />} label="Total Withdrawn" value={formatNumber(stats.totalWithdrawn)} />
        <StatBox icon={<Clock className="size-3 text-amber-400" />} label="Pending" value={formatNumber(stats.pendingAmount)} />
        <StatBox icon={<History className="size-3 text-sky-400" />} label="Transactions" value={String(stats.transactionCount)} />
      </div>

      {/* Supported crypto currencies */}
      <div className="rounded-xl border border-amber-900/40 bg-stone-800/40 p-3">
        <div className="mb-2 text-[10px] font-bold uppercase tracking-wider text-amber-300/70">
          Supported Currencies
        </div>
        <div className="flex items-center justify-around">
          {withdrawalConfig.cryptoCurrencies.map((cc) => (
            <CryptoIcon key={cc} currency={cc} />
          ))}
        </div>
      </div>

      {/* Withdrawal section */}
      {!showWithdraw ? (
        <Button
          className="w-full bg-amber-600 text-stone-950 hover:bg-amber-500"
          disabled={!withdrawalConfig.enabled}
          onClick={() => setShowWithdraw(true)}
        >
          <ArrowDownToLine className="size-4" />
          Request Withdrawal
        </Button>
      ) : (
        <div className="space-y-2 rounded-xl border border-amber-700/40 bg-stone-800/40 p-3">
          <div className="text-xs font-bold text-amber-200">Withdrawal Request</div>
          <div>
            <Label className="text-[10px] text-stone-400">Amount (min: {minWithdrawal})</Label>
            <Input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder={String(minWithdrawal)}
              className="border-amber-900/40 bg-stone-900 text-amber-50"
            />
          </div>
          <div>
            <Label className="text-[10px] text-stone-400">Currency / Method</Label>
            <Select value={method} onValueChange={setMethod}>
              <SelectTrigger className="border-amber-900/40 bg-stone-900 text-amber-50">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="border-amber-900/40 bg-stone-900">
                {withdrawalConfig.cryptoCurrencies.map((cc) => (
                  <SelectItem key={cc} value={cc}>{cc}</SelectItem>
                ))}
                {withdrawalConfig.methods.filter((m) => !withdrawalConfig.cryptoCurrencies.includes(m)).map((m) => (
                  <SelectItem key={m} value={m} className="capitalize">{m}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" className="flex-1 border-stone-600" onClick={() => setShowWithdraw(false)}>
              Cancel
            </Button>
            <Button className="flex-1 bg-amber-600 text-stone-950 hover:bg-amber-500" onClick={handleWithdraw}>
              Submit
            </Button>
          </div>
        </div>
      )}

      {/* Withdrawal limits info */}
      <div className="flex items-center gap-2 rounded-lg border border-stone-700/50 bg-stone-800/30 p-2 text-[10px] text-stone-400">
        <AlertCircle className="size-3 shrink-0 text-amber-400" />
        Min withdrawal: {minWithdrawal} · Processing: {withdrawalConfig.processingTimeHours}h
      </div>

      {/* Transaction history */}
      <div>
        <div className="mb-2 text-xs font-bold text-amber-200">Transaction History</div>
        {transactions.length === 0 ? (
          <div className="rounded-lg border border-stone-700/50 bg-stone-800/30 p-4 text-center text-xs text-stone-500">
            No transactions yet. Earn wallet rewards from events and referrals!
          </div>
        ) : (
          <div className="space-y-1.5 max-h-48 overflow-y-auto mine-scroll">
            {transactions.map((tx) => (
              <div key={tx.id} className="flex items-center gap-2 rounded-lg border border-stone-700/50 bg-stone-800/40 p-2">
                <div className={[
                  "flex size-7 shrink-0 items-center justify-center rounded-full",
                  tx.amount > 0 ? "bg-emerald-900/40" : "bg-red-900/40",
                ].join(" ")}>
                  {tx.amount > 0 ? <ArrowDownToLine className="size-3 text-emerald-400" /> : <ArrowUpFromLine className="size-3 text-red-400" />}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="truncate text-xs font-medium text-amber-100">{tx.description}</div>
                  <div className="text-[9px] text-stone-400">{new Date(tx.timestamp).toLocaleString()}</div>
                </div>
                <div className="text-end">
                  <div className={[
                    "text-xs font-bold",
                    tx.amount > 0 ? "text-emerald-400" : "text-red-400",
                  ].join(" ")}>
                    {tx.amount > 0 ? "+" : ""}{formatNumber(tx.amount)}
                  </div>
                  {tx.status !== "completed" && (
                    <div className="flex items-center gap-0.5 text-[8px] text-amber-400">
                      <Clock className="size-2" />
                      {tx.status}
                    </div>
                  )}
                  {tx.status === "completed" && (
                    <CheckCircle className="ml-auto size-3 text-emerald-500" />
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </PanelDialog>
  );
}

function StatBox({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="rounded-lg border border-stone-700/50 bg-stone-800/40 p-2.5">
      <div className="flex items-center gap-1 text-[10px] text-stone-400">{icon}{label}</div>
      <div className="mt-0.5 text-sm font-bold text-amber-200">{value}</div>
    </div>
  );
}

function CryptoIcon({ currency }: { currency: string }) {
  const icons: Record<string, React.ReactNode> = {
    USDT: <span className="text-base font-bold">₮</span>,
    BTC: <Bitcoin className="size-4" />,
    ETH: <span className="text-xs font-bold">Ξ</span>,
    BNB: <span className="text-xs font-bold">bnb</span>,
  };
  const colors: Record<string, string> = {
    USDT: "bg-emerald-600",
    BTC: "bg-orange-500",
    ETH: "bg-indigo-500",
    BNB: "bg-yellow-500",
  };
  return (
    <div className="flex flex-col items-center gap-1">
      <div className={`flex size-8 items-center justify-center rounded-full text-white ${colors[currency] ?? "bg-stone-600"}`}>
        {icons[currency] ?? <span className="text-xs">{currency.slice(0, 3)}</span>}
      </div>
      <span className="text-[9px] font-bold text-amber-200/70">{currency}</span>
    </div>
  );
}
