"use client";

/**
 * A floor manager — distinct from workers. Wears a white hard hat, an orange
 * safety vest over a shirt, holds a clipboard, and supervises. Idle bob +
 * occasional clipboard check. Appears only after being hired.
 */
export function Manager({ size = 70 }: { size?: number }) {
  return (
    <div className="imt-bob inline-block" style={{ animationDelay: "0.4s" }}>
      <svg
        viewBox="0 0 60 86"
        width={size * 0.7}
        height={size}
        className="crisp"
        aria-hidden
      >
        <defs>
          <linearGradient id="mgr-vest" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#fb923c" />
            <stop offset="1" stopColor="#c2410c" />
          </linearGradient>
          <linearGradient id="mgr-hat" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#f8fafc" />
            <stop offset="1" stopColor="#cbd5e1" />
          </linearGradient>
        </defs>

        {/* shadow */}
        <ellipse cx="30" cy="83" rx="14" ry="2.5" fill="rgba(0,0,0,0.25)" />

        {/* legs */}
        <rect x="22" y="58" width="7" height="22" rx="2.5" fill="#1e293b" />
        <rect x="31" y="58" width="7" height="22" rx="2.5" fill="#1e293b" />
        <rect x="20" y="78" width="11" height="4" rx="1.5" fill="#0f172a" />
        <rect x="29" y="78" width="11" height="4" rx="1.5" fill="#0f172a" />

        {/* torso (vest over shirt) */}
        <path d="M16 36 L44 36 L46 62 L14 62 Z" fill="url(#mgr-vest)" stroke="#7c2d12" strokeWidth="1.5" />
        {/* shirt collar */}
        <path d="M24 36 L30 44 L36 36 Z" fill="#e2e8f0" stroke="#94a3b8" strokeWidth="1" />
        {/* vest reflective stripes */}
        <rect x="15" y="48" width="30" height="3" fill="#fde68a" opacity="0.85" />
        <rect x="15" y="54" width="30" height="3" fill="#fde68a" opacity="0.85" />

        {/* arms holding clipboard */}
        <rect x="11" y="38" width="6" height="18" rx="3" fill="url(#mgr-vest)" stroke="#7c2d12" strokeWidth="1.2" />
        <rect x="43" y="38" width="6" height="18" rx="3" fill="url(#mgr-vest)" stroke="#7c2d12" strokeWidth="1.2" />
        {/* clipboard */}
        <rect x="20" y="44" width="20" height="16" rx="1.5" fill="#fef3c7" stroke="#92400e" strokeWidth="1.5" />
        <rect x="26" y="42" width="8" height="3" rx="1" fill="#92400e" />
        <line x1="23" y1="50" x2="37" y2="50" stroke="#92400e" strokeWidth="0.8" />
        <line x1="23" y1="54" x2="35" y2="54" stroke="#92400e" strokeWidth="0.8" />
        <line x1="23" y1="58" x2="36" y2="58" stroke="#92400e" strokeWidth="0.8" />

        {/* head */}
        <circle cx="30" cy="26" r="10" fill="#f4c6a0" stroke="#e0a680" strokeWidth="1" />
        {/* mustache */}
        <path d="M24 30 Q27 32 30 30 Q33 32 36 30" stroke="#3a2410" strokeWidth="1.6" fill="none" strokeLinecap="round" />
        {/* eyes */}
        <circle cx="26.5" cy="25" r="1.2" fill="#1f2937" />
        <circle cx="33.5" cy="25" r="1.2" fill="#1f2937" />

        {/* white hard hat */}
        <path d="M18 22 Q18 12 30 12 Q42 12 42 22 L42 24 L18 24 Z" fill="url(#mgr-hat)" stroke="#94a3b8" strokeWidth="1.2" />
        <rect x="17" y="22" width="26" height="3" rx="1.5" fill="#e2e8f0" stroke="#94a3b8" strokeWidth="1" />
        {/* hat lamp */}
        <circle cx="30" cy="14" r="1.8" fill="#fde047" className="imt-lantern" />
      </svg>
    </div>
  );
}
