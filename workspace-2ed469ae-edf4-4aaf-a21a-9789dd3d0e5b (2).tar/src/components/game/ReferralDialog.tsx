"use client";
import { useState } from "react";
import { PanelDialog } from "./PanelDialog";
import { Button } from "@/components/ui/button";
import { useMetaStore } from "@/store/metaStore";
import { useGameStore } from "@/store/gameStore";
import { useT } from "@/game/useT";
import { formatNumber } from "@/lib/format";
import { CoinIcon, GemIcon } from "./icons";
import { Share2, Copy, Check, Users, Gift, MessageCircle, Send, Facebook } from "lucide-react";
import { toast } from "sonner";
import {
  REFERRAL_INVITER_REWARD,
  REFERRAL_INVITEE_REWARD,
} from "@/game/config";

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
}

export function ReferralDialog({ open, onOpenChange }: Props) {
  const t = useT();
  const referral = useMetaStore((s) => s.referral);
  const claimReferralRewards = useMetaStore((s) => s.claimReferralRewards);
  const grantReward = useGameStore((s) => s.grantReward);
  const [copied, setCopied] = useState(false);

  const link = referral.link;
  const shareText = `${t("welcomeBody")} ${link}`;

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(link);
      setCopied(true);
      toast.success(t("copied"));
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // fallback
      const ta = document.createElement("textarea");
      ta.value = link;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
      setCopied(true);
      toast.success(t("copied"));
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleShare = (platform: "whatsapp" | "telegram" | "facebook" | "messenger") => {
    const encoded = encodeURIComponent(shareText);
    const encodedLink = encodeURIComponent(link);
    let url = "";
    switch (platform) {
      case "whatsapp":
        url = `https://wa.me/?text=${encoded}`;
        break;
      case "telegram":
        url = `https://t.me/share/url?url=${encodedLink}&text=${encodeURIComponent(t("welcomeBody"))}`;
        break;
      case "facebook":
        url = `https://www.facebook.com/sharer/sharer.php?u=${encodedLink}`;
        break;
      case "messenger":
        url = `https://www.facebook.com/dialog/send?link=${encodedLink}&app_id=0&redirect_uri=${encodedLink}`;
        break;
    }
    window.open(url, "_blank", "noopener,noreferrer");
  };

  const handleClaimAll = () => {
    const reward = claimReferralRewards();
    if (reward.coins > 0 || reward.gems > 0) {
      grantReward(reward.coins, reward.gems);
      toast.success(`+${formatNumber(reward.coins)} coins, +${reward.gems} gems!`, {
        description: "Referral rewards claimed",
      });
    }
  };

  return (
    <PanelDialog
      open={open}
      onOpenChange={onOpenChange}
      title={t("referral")}
      icon={<Share2 className="size-5" />}
      description={t("referralDesc")}
    >
      {/* Referral link */}
      <div className="rounded-xl border border-amber-900/40 bg-stone-800/40 p-3">
        <div className="mb-1 text-xs font-bold text-amber-200">{t("referralLink")}</div>
        <div className="flex items-center gap-2">
          <div className="min-w-0 flex-1 truncate rounded-lg border border-stone-600 bg-stone-900/70 px-2 py-1.5 text-xs text-amber-100">
            {link}
          </div>
          <button
            onClick={handleCopy}
            className="flex size-8 shrink-0 items-center justify-center rounded-lg border border-amber-700/50 bg-amber-800/70 text-amber-100 transition hover:bg-amber-700 active:scale-95"
            aria-label={t("copyLink")}
          >
            {copied ? <Check className="size-4 text-emerald-300" /> : <Copy className="size-4" />}
          </button>
        </div>
        <div className="mt-2 text-[10px] text-amber-200/50">
          {t("referralCode")}: <span className="font-bold text-amber-300">{referral.code}</span>
        </div>
      </div>

      {/* Share buttons */}
      <div>
        <div className="mb-2 text-xs font-bold text-amber-200">{t("shareVia")}</div>
        <div className="grid grid-cols-5 gap-2">
          <ShareBtn icon={<MessageCircle className="size-5" />} label="WhatsApp" color="bg-[#25D366]" onClick={() => handleShare("whatsapp")} />
          <ShareBtn icon={<Send className="size-5" />} label="Telegram" color="bg-[#0088cc]" onClick={() => handleShare("telegram")} />
          <ShareBtn icon={<Facebook className="size-5" />} label="Facebook" color="bg-[#1877F2]" onClick={() => handleShare("facebook")} />
          <ShareBtn icon={<MessageCircle className="size-5" />} label="Messenger" color="bg-[#0084FF]" onClick={() => handleShare("messenger")} />
          <ShareBtn icon={copied ? <Check className="size-5" /> : <Copy className="size-5" />} label="Copy" color="bg-stone-600" onClick={handleCopy} />
        </div>
      </div>

      {/* Rewards info */}
      <div className="grid grid-cols-2 gap-2">
        <div className="rounded-lg border border-emerald-700/40 bg-emerald-900/20 p-2.5 text-center">
          <div className="text-[10px] text-emerald-300/70">{t("inviteFriends")}</div>
          <div className="mt-1 flex items-center justify-center gap-1 text-sm font-bold text-emerald-300">
            <CoinIcon className="size-3" /> {formatNumber(REFERRAL_INVITEE_REWARD.coins)}
            <GemIcon className="size-3" /> {REFERRAL_INVITEE_REWARD.gems}
          </div>
        </div>
        <div className="rounded-lg border border-amber-700/40 bg-amber-900/20 p-2.5 text-center">
          <div className="text-[10px] text-amber-300/70">{t("reward")}</div>
          <div className="mt-1 flex items-center justify-center gap-1 text-sm font-bold text-amber-300">
            <CoinIcon className="size-3" /> {formatNumber(REFERRAL_INVITER_REWARD.coins)}
            <GemIcon className="size-3" /> {REFERRAL_INVITER_REWARD.gems}
          </div>
        </div>
      </div>

      {/* Pending rewards + claim */}
      {referral.pendingRewards > 0 && (
        <Button
          className="w-full bg-emerald-600 text-white hover:bg-emerald-500"
          onClick={handleClaimAll}
        >
          <Gift className="size-4" />
          {t("claimAll")} ({referral.pendingRewards})
        </Button>
      )}

      {/* Invited friends list */}
      <div>
        <div className="mb-2 flex items-center gap-2 text-xs font-bold text-amber-200">
          <Users className="size-4" /> {t("invitedFriends")} ({referral.totalInvited})
        </div>
        {referral.friends.length === 0 ? (
          <div className="rounded-lg border border-stone-700/50 bg-stone-800/30 p-4 text-center text-xs text-stone-400">
            {t("noFriendsYet")}
          </div>
        ) : (
          <div className="space-y-1.5">
            {referral.friends.map((f) => (
              <div key={f.id} className="flex items-center gap-2 rounded-lg border border-stone-700/50 bg-stone-800/40 p-2">
                <div className="flex size-8 items-center justify-center rounded-full bg-stone-700 text-xs font-bold text-amber-200">
                  {f.name.charAt(0)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="truncate text-xs font-medium text-amber-100">{f.name}</div>
                  <div className="text-[9px] text-stone-400">
                    {new Date(f.joinedAt).toLocaleDateString()}
                  </div>
                </div>
                <span className={[
                  "rounded-full px-1.5 py-0.5 text-[9px] font-bold",
                  f.active
                    ? f.inviterRewarded
                      ? "bg-stone-700 text-stone-400"
                      : "bg-emerald-700 text-emerald-100"
                    : "bg-amber-800 text-amber-200",
                ].join(" ")}>
                  {f.active ? (f.inviterRewarded ? t("rewardClaimed") : t("rewardPending")) : t("pending")}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </PanelDialog>
  );
}

function ShareBtn({ icon, label, color, onClick }: { icon: React.ReactNode; label: string; color: string; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="flex flex-col items-center gap-1 rounded-lg border border-stone-700/50 bg-stone-800/40 p-2 transition active:scale-95 hover:bg-stone-800/60"
    >
      <div className={`flex size-9 items-center justify-center rounded-lg text-white ${color}`}>
        {icon}
      </div>
      <span className="text-[8px] font-medium text-amber-200/70">{label}</span>
    </button>
  );
}
