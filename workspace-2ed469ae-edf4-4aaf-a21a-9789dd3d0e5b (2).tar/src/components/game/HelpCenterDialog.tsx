"use client";
import { useState } from "react";
import { PanelDialog } from "./PanelDialog";
import { useMetaStore } from "@/store/metaStore";
import { useT } from "@/game/useT";
import {
  HelpCircle,
  Pickaxe,
  UserCog,
  ArrowUpCircle,
  Tv,
  Wallet,
  Share2,
  Banknote,
  CalendarDays,
  ChevronDown,
} from "lucide-react";

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
}

interface HelpSection {
  icon: React.ReactNode;
  titleKey: string;
  descKey: string;
}

interface FaqItem {
  qKey: string;
  aKey: string;
}

export function HelpCenterDialog({ open, onOpenChange }: Props) {
  const t = useT();
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const sections: HelpSection[] = [
    { icon: <Pickaxe className="size-4 text-orange-400" />, titleKey: "helpMining", descKey: "helpMiningDesc" },
    { icon: <UserCog className="size-4 text-sky-400" />, titleKey: "helpManagers", descKey: "helpManagersDesc" },
    { icon: <ArrowUpCircle className="size-4 text-amber-400" />, titleKey: "helpUpgrades", descKey: "helpUpgradesDesc" },
    { icon: <Tv className="size-4 text-fuchsia-400" />, titleKey: "helpAds", descKey: "helpAdsDesc" },
    { icon: <Wallet className="size-4 text-teal-400" />, titleKey: "helpWallet", descKey: "helpWalletDesc" },
    { icon: <Share2 className="size-4 text-emerald-400" />, titleKey: "helpReferral", descKey: "helpReferralDesc" },
    { icon: <Banknote className="size-4 text-green-400" />, titleKey: "helpWithdrawals", descKey: "helpWithdrawalsDesc" },
    { icon: <CalendarDays className="size-4 text-purple-400" />, titleKey: "helpEvents", descKey: "helpEventsDesc" },
  ];

  const faqs: FaqItem[] = [
    { qKey: "faq1", aKey: "faq1a" },
    { qKey: "faq2", aKey: "faq2a" },
    { qKey: "faq3", aKey: "faq3a" },
    { qKey: "faq4", aKey: "faq4a" },
    { qKey: "faq5", aKey: "faq5a" },
    { qKey: "faq6", aKey: "faq6a" },
  ];

  return (
    <PanelDialog
      open={open}
      onOpenChange={onOpenChange}
      title={t("helpCenter")}
      icon={<HelpCircle className="size-5" />}
      description={t("aboutDesc")}
    >
      {/* Game systems */}
      <div className="space-y-2">
        {sections.map((s, i) => (
          <div key={i} className="rounded-lg border border-amber-900/30 bg-stone-800/40 p-3">
            <div className="mb-1 flex items-center gap-2">
              {s.icon}
              <span className="text-xs font-bold text-amber-200">{t(s.titleKey)}</span>
            </div>
            <p className="text-[11px] leading-relaxed text-amber-200/60">{t(s.descKey)}</p>
          </div>
        ))}
      </div>

      {/* FAQ */}
      <div>
        <div className="mb-2 text-xs font-bold text-amber-200">{t("faq")}</div>
        <div className="space-y-1.5">
          {faqs.map((f, i) => (
            <div key={i} className="overflow-hidden rounded-lg border border-stone-700/50 bg-stone-800/40">
              <button
                onClick={() => setOpenFaq(openFaq === i ? null : i)}
                className="flex w-full items-center justify-between gap-2 p-2.5 text-start"
              >
                <span className="text-xs font-medium text-amber-100">{t(f.qKey)}</span>
                <ChevronDown
                  className={`size-4 shrink-0 text-stone-400 transition-transform ${openFaq === i ? "rotate-180" : ""}`}
                />
              </button>
              {openFaq === i && (
                <div className="border-t border-stone-700/50 bg-stone-900/40 p-2.5 text-[11px] leading-relaxed text-amber-200/70">
                  {t(f.aKey)}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </PanelDialog>
  );
}
