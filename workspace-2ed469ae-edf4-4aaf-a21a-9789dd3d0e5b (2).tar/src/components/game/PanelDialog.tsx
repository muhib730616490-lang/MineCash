"use client";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { X } from "lucide-react";
import type { ReactNode } from "react";

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  title: string;
  description?: string;
  icon?: ReactNode;
  children: ReactNode;
  className?: string;
}

/** Shared dialog shell for all meta-system panels with consistent styling + scroll. */
export function PanelDialog({ open, onOpenChange, title, description, icon, children, className }: Props) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className={`border-amber-900/50 bg-gradient-to-b from-stone-900 to-stone-950 text-amber-50 sm:max-w-lg ${className ?? ""}`}>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-lg font-bold text-amber-200">
            {icon}
            {title}
          </DialogTitle>
          {description && <DialogDescription className="text-amber-200/60">{description}</DialogDescription>}
        </DialogHeader>
        <ScrollArea className="max-h-[60vh] pr-2">
          <div className="space-y-3 py-2">{children}</div>
        </ScrollArea>
        <div className="pt-2">
          <Button
            className="w-full bg-amber-600 text-stone-950 hover:bg-amber-500"
            onClick={() => onOpenChange(false)}
          >
            <X className="size-4" /> Close
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
