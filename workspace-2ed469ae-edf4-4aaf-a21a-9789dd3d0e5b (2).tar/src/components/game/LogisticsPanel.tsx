"use client";
import { useState } from "react";
import { useGameStore } from "@/store/gameStore";
import { useMetaStore } from "@/store/metaStore";
import { useActiveMineConfig } from "@/game/useMine";
import { useT } from "@/game/useT";
import {
  elevatorCapacity,
  elevatorTravelPerFloor,
  elevatorCapacityUpgradeCost,
  elevatorSpeedUpgradeCost,
  ELEVATOR_MANAGER_COST,
  cartCapacity,
  cartLoadTime,
  cartCapacityUpgradeCost,
  cartSpeedUpgradeCost,
  warehouseCapacity,
  warehouseCapacityUpgradeCost,
  WAREHOUSE_MANAGER_COST,
} from "@/game/config";
import { formatNumber } from "@/lib/format";
import { CoinIcon } from "./icons";
import {
  ArrowUpDown,
  Truck,
  Plus,
  Gauge,
  Package,
  Warehouse,
  UserCheck,
  UserPlus,
  Send,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import { toast } from "sonner";

/** Floating HUD for elevator + cart/warehouse upgrades, managers, and dispatch. */
export function LogisticsPanel() {
  const t = useT();
  const cfg = useActiveMineConfig();
  const coins = useGameStore((s) => s.coins);
  const mine = useGameStore((s) => s.mines[s.activeMine]);

  const upgradeElevCap = useGameStore((s) => s.upgradeElevatorCapacity);
  const upgradeElevSpd = useGameStore((s) => s.upgradeElevatorSpeed);
  const hireElevMgr = useGameStore((s) => s.hireElevatorManager);
  const dispatchElevator = useGameStore((s) => s.dispatchElevator);

  const upgradeCartCap = useGameStore((s) => s.upgradeCartCapacity);
  const upgradeCartSpd = useGameStore((s) => s.upgradeCartSpeed);
  const upgradeWhCap = useGameStore((s) => s.upgradeWarehouseCapacity);
  const hireWhMgr = useGameStore((s) => s.hireWarehouseManager);
  const dispatchCart = useGameStore((s) => s.dispatchCart);

  const [expanded, setExpanded] = useState(false);

  const elevCap = elevatorCapacity(mine.elevator.capacityLevel);
  const elevTravel = elevatorTravelPerFloor(mine.elevator.speedLevel);
  const elevCapCost = elevatorCapacityUpgradeCost(mine.elevator.capacityLevel);
  const elevSpdCost = elevatorSpeedUpgradeCost(mine.elevator.speedLevel);

  const cCap = cartCapacity(mine.cart.capacityLevel);
  const cLoad = cartLoadTime(mine.cart.speedLevel);
  const cartCapCost = cartCapacityUpgradeCost(mine.cart.capacityLevel);
  const cartSpdCost = cartSpeedUpgradeCost(mine.cart.speedLevel);
  const whCap = warehouseCapacity(mine.warehouse.capacityLevel);
  const whCapCost = warehouseCapacityUpgradeCost(mine.warehouse.capacityLevel);

  const elevMgrHired = mine.elevator.managerHired;
  const whMgrHired = mine.cart.managerHired;

  return (
    <div className="pointer-events-none fixed bottom-3 right-3 z-40 flex flex-col items-end gap-2">
      {expanded && (
        <>
          {/* Elevator card */}
          <div className="pointer-events-auto w-72 rounded-xl border border-amber-900/50 bg-stone-900/90 p-2.5 shadow-xl backdrop-blur-md imt-pop-in">
            <div className="mb-2 flex items-center gap-2">
              <div className="flex size-7 items-center justify-center rounded-lg text-white shadow" style={{ background: `linear-gradient(135deg, ${cfg.accent}, #4a2c10)` }}>
                <ArrowUpDown className="size-4" />
              </div>
              <div className="flex-1 text-xs font-bold uppercase tracking-wide text-amber-300/70">{t("elevator")}</div>
              <div className="rounded bg-stone-800 px-1.5 py-0.5 text-[10px] font-bold text-amber-200">
                {elevCap} cap · {elevTravel.toFixed(2)}s/fl
              </div>
            </div>
            <div className="grid grid-cols-2 gap-1.5">
              <UpgradeBtn icon={<Package className="size-3" />} label={t("elevatorCapacity")} sub={`Lv${mine.elevator.capacityLevel}`} cost={elevCapCost} coins={coins} onClick={upgradeElevCap} />
              <UpgradeBtn icon={<Gauge className="size-3" />} label={t("elevatorSpeed")} sub={`Lv${mine.elevator.speedLevel}`} cost={elevSpdCost} coins={coins} onClick={upgradeElevSpd} />
            </div>
            {!elevMgrHired ? (
              <div className="mt-1.5 flex gap-1.5">
                <ManagerBtn cost={ELEVATOR_MANAGER_COST} coins={coins} onClick={() => { hireElevMgr(); useMetaStore.getState().trackMission("hireManager", 1); useMetaStore.getState().incrementManagersHired(); toast.success(t("hireElevatorManager")); }} label={t("hireElevatorManager")} />
                <DispatchBtn onClick={dispatchElevator} label={t("dispatch")} disabled={mine.elevator.phase !== "idle"} />
              </div>
            ) : (
              <div className="mt-1.5 flex items-center gap-1.5 rounded-lg border border-emerald-600/40 bg-emerald-900/30 px-2 py-1 text-[10px] font-bold text-emerald-300">
                <UserCheck className="size-3" /> {t("autoOn")} · {t("elevatorManager")}
              </div>
            )}
          </div>

          {/* Cart / Warehouse card */}
          <div className="pointer-events-auto w-72 rounded-xl border border-amber-900/50 bg-stone-900/90 p-2.5 shadow-xl backdrop-blur-md imt-pop-in">
            <div className="mb-2 flex items-center gap-2">
              <div className="flex size-7 items-center justify-center rounded-lg text-white shadow" style={{ background: `linear-gradient(135deg, ${cfg.accent}, #4a2c10)` }}>
                <Truck className="size-4" />
              </div>
              <div className="flex-1 text-xs font-bold uppercase tracking-wide text-amber-300/70">{t("cart")} / {t("warehouse")}</div>
              <div className="rounded bg-stone-800 px-1.5 py-0.5 text-[10px] font-bold text-amber-200">
                {cCap} · {whCap} st
              </div>
            </div>
            <div className="grid grid-cols-3 gap-1">
              <UpgradeBtn icon={<Package className="size-3" />} label={t("capacity")} sub={`Lv${mine.cart.capacityLevel}`} cost={cartCapCost} coins={coins} onClick={upgradeCartCap} compact />
              <UpgradeBtn icon={<Gauge className="size-3" />} label={t("loadingSpeed")} sub={`Lv${mine.cart.speedLevel}`} cost={cartSpdCost} coins={coins} onClick={upgradeCartSpd} compact />
              <UpgradeBtn icon={<Warehouse className="size-3" />} label={t("storageCapacity")} sub={`Lv${mine.warehouse.capacityLevel}`} cost={whCapCost} coins={coins} onClick={upgradeWhCap} compact />
            </div>
            {!whMgrHired ? (
              <div className="mt-1.5 flex gap-1.5">
                <ManagerBtn cost={WAREHOUSE_MANAGER_COST} coins={coins} onClick={() => { hireWhMgr(); useMetaStore.getState().trackMission("hireManager", 1); useMetaStore.getState().incrementManagersHired(); toast.success(t("hireWarehouseManager")); }} label={t("hireWarehouseManager")} />
                <DispatchBtn onClick={() => { dispatchCart(); }} label={t("sell")} disabled={mine.cart.phase !== "idle" || mine.warehouse.ore <= 0} />
              </div>
            ) : (
              <div className="mt-1.5 flex items-center gap-1.5 rounded-lg border border-emerald-600/40 bg-emerald-900/30 px-2 py-1 text-[10px] font-bold text-emerald-300">
                <UserCheck className="size-3" /> {t("autoOn")} · {t("warehouseManager")}
              </div>
            )}
          </div>
        </>
      )}

      {/* Toggle button */}
      <button
        onClick={() => setExpanded((v) => !v)}
        className="pointer-events-auto flex items-center gap-1.5 rounded-full border border-amber-700/50 bg-stone-900/90 px-3 py-1.5 text-xs font-bold text-amber-200 shadow-xl backdrop-blur-md transition hover:bg-stone-800 active:scale-95"
      >
        {expanded ? <ChevronDown className="size-3.5" /> : <ChevronUp className="size-3.5" />}
        {t("logistics")}
      </button>
    </div>
  );
}

function UpgradeBtn({
  icon,
  label,
  sub,
  cost,
  coins,
  onClick,
  compact,
}: {
  icon: React.ReactNode;
  label: string;
  sub: string;
  cost: number;
  coins: number;
  onClick: () => void;
  compact?: boolean;
}) {
  const can = coins >= cost;
  return (
    <button
      onClick={onClick}
      disabled={!can}
      className={[
        "flex flex-col items-center justify-center rounded-lg border px-1 py-1 text-[9px] font-bold leading-none transition active:scale-95",
        compact ? "min-w-0" : "",
        can
          ? "border-amber-400/60 bg-amber-600 text-stone-950 hover:bg-amber-500"
          : "cursor-not-allowed border-stone-700 bg-stone-800/70 text-stone-500",
      ].join(" ")}
    >
      <span className="flex items-center gap-0.5">
        {icon}
        <span className="truncate">{compact ? "" : label}</span>
      </span>
      <span className="mt-0.5 truncate text-[8px] opacity-80">{compact ? label.slice(0, 8) : sub}</span>
      {compact && <span className="mt-0.5 text-[8px] opacity-80">{sub}</span>}
      <span className="mt-0.5 flex items-center gap-0.5 tabular-nums">
        <CoinIcon className="size-2.5" />
        {formatNumber(cost)}
      </span>
    </button>
  );
}

function ManagerBtn({
  cost,
  coins,
  onClick,
  label,
}: {
  cost: number;
  coins: number;
  onClick: () => void;
  label: string;
}) {
  const can = coins >= cost;
  return (
    <button
      onClick={onClick}
      disabled={!can}
      className={[
        "flex flex-1 items-center justify-center gap-1 rounded-lg border px-1.5 py-1.5 text-[10px] font-bold leading-none transition active:scale-95",
        can
          ? "border-fuchsia-400/60 bg-fuchsia-700 text-fuchsia-50 hover:bg-fuchsia-600"
          : "cursor-not-allowed border-stone-700 bg-stone-800/70 text-stone-500",
      ].join(" ")}
    >
      <UserPlus className="size-3" />
      <span className="flex flex-col items-start">
        <span className="text-[9px]">{label}</span>
        <span className="flex items-center gap-0.5 tabular-nums">
          <CoinIcon className="size-2.5" />
          {formatNumber(cost)}
        </span>
      </span>
    </button>
  );
}

function DispatchBtn({
  onClick,
  label,
  disabled,
}: {
  onClick: () => void;
  label: string;
  disabled?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={[
        "flex items-center justify-center gap-1 rounded-lg border px-2 py-1.5 text-[10px] font-bold transition active:scale-95",
        disabled
          ? "cursor-not-allowed border-stone-700 bg-stone-800/70 text-stone-600"
          : "border-sky-400/60 bg-sky-700 text-sky-50 hover:bg-sky-600",
      ].join(" ")}
    >
      <Send className="size-3" />
      {label}
    </button>
  );
}
