"use client";
import { useActiveMineConfig } from "@/game/useMine";

/**
 * The mine entrance on the surface: a wooden headframe tower over a cave mouth
 * with a sign board, glowing interior, and cables descending into the shaft.
 * Aligned with the elevator shaft below.
 */
export function MineEntrance() {
  const m = useActiveMineConfig();
  return (
    <div className="relative h-full w-full">
      <svg
        viewBox="0 0 160 300"
        className="crisp h-full w-full"
        preserveAspectRatio="xMidYMax meet"
        aria-hidden
      >
        <defs>
          <radialGradient id="ent-cave" cx="0.5" cy="0.7" r="0.7">
            <stop offset="0" stopColor={m.oreGlow} stopOpacity="0.9" />
            <stop offset="0.35" stopColor={m.oreColor} stopOpacity="0.55" />
            <stop offset="0.7" stopColor="#1a0f08" stopOpacity="0.9" />
            <stop offset="1" stopColor="#0a0604" />
          </radialGradient>
          <linearGradient id="ent-rock" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor={m.rockTint} />
            <stop offset="1" stopColor={m.rockTintDark} />
          </linearGradient>
          <linearGradient id="ent-wood" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0" stopColor="#8a5a2b" />
            <stop offset="0.5" stopColor="#a86a33" />
            <stop offset="1" stopColor="#6e4218" />
          </linearGradient>
        </defs>

        {/* rocky hill around the entrance */}
        <path
          d="M-10 300 L-10 230 Q10 200 30 205 Q40 175 60 178 Q80 168 100 182 Q120 172 140 190 Q160 200 170 220 L170 300 Z"
          fill="url(#ent-rock)"
        />
        <path
          d="M20 235 Q45 215 70 220 Q95 210 120 230"
          fill="none"
          stroke={m.rockTintDark}
          strokeWidth="3"
          opacity="0.5"
        />

        {/* cave mouth */}
        <path
          d="M48 300 L48 250 Q48 218 80 218 Q112 218 112 250 L112 300 Z"
          fill="url(#ent-cave)"
        />
        {/* ore sparkle inside */}
        <circle cx="70" cy="258" r="3" fill={m.oreGlow} className="imt-sparkle" />
        <circle cx="92" cy="266" r="2.4" fill={m.oreGlow} className="imt-sparkle" style={{ animationDelay: "0.8s" }} />
        <circle cx="80" cy="278" r="2" fill={m.oreGlow} className="imt-sparkle" style={{ animationDelay: "1.4s" }} />

        {/* wooden frame (lintel + posts) */}
        <rect x="42" y="214" width="76" height="10" rx="2" fill="url(#ent-wood)" stroke="#4a2c10" strokeWidth="1.5" />
        <rect x="42" y="222" width="10" height="78" rx="2" fill="url(#ent-wood)" stroke="#4a2c10" strokeWidth="1.5" />
        <rect x="108" y="222" width="10" height="78" rx="2" fill="url(#ent-wood)" stroke="#4a2c10" strokeWidth="1.5" />

        {/* headframe A-frame tower */}
        <g stroke="#5a3416" strokeWidth="2.5" strokeLinecap="round">
          <line x1="52" y1="214" x2="80" y2="70" />
          <line x1="108" y1="214" x2="80" y2="70" />
          <line x1="64" y1="160" x2="96" y2="160" />
          <line x1="58" y1="190" x2="102" y2="190" />
          <line x1="70" y1="120" x2="90" y2="120" />
        </g>
        <g fill="url(#ent-wood)" stroke="#4a2c10" strokeWidth="1.5">
          <rect x="52" y="210" width="56" height="6" rx="2" />
        </g>

        {/* pulley wheel */}
        <circle cx="80" cy="64" r="9" fill="#3a2a18" stroke="#7a5230" strokeWidth="2.5" />
        <circle cx="80" cy="64" r="3" fill="#caa15a" className="imt-spin-slow" style={{ transformOrigin: "80px 64px" }} />

        {/* cables from pulley into shaft */}
        <line x1="76" y1="72" x2="74" y2="214" stroke="#cbd5e1" strokeWidth="1.6" opacity="0.8" />
        <line x1="84" y1="72" x2="86" y2="214" stroke="#cbd5e1" strokeWidth="1.6" opacity="0.8" />

        {/* sign board */}
        <g>
          <rect x="40" y="168" width="80" height="22" rx="4" fill="#6e4218" stroke="#3a2410" strokeWidth="2" />
          <rect x="44" y="171" width="72" height="16" rx="3" fill="#caa15a" />
          <text
            x="80"
            y="183"
            textAnchor="middle"
            fontSize="9"
            fontWeight="800"
            fill="#3a2410"
            fontFamily="ui-sans-serif, system-ui, sans-serif"
            letterSpacing="0.5"
          >
            {m.surfaceLabel}
          </text>
          <line x1="80" y1="160" x2="80" y2="168" stroke="#3a2410" strokeWidth="2" />
        </g>

        {/* mine cart tracks leading in */}
        <line x1="60" y1="300" x2="64" y2="286" stroke="#6b4226" strokeWidth="2" />
        <line x1="100" y1="300" x2="96" y2="286" stroke="#6b4226" strokeWidth="2" />
      </svg>
    </div>
  );
}
