"use client";
import { useActiveMineConfig } from "@/game/useMine";
import { Sun } from "./decor/Sun";
import { Clouds } from "./decor/Clouds";
import { Mountains } from "./decor/Mountains";
import { Trees } from "./decor/Trees";
import { Bushes } from "./decor/Bushes";
import { MineEntrance } from "./MineEntrance";
import { Warehouse } from "./Warehouse";
import { TransportCart } from "./TransportCart";

/** The above-ground area: sky, sun, clouds, mountains, trees, mine entrance, warehouse, cart track. */
export function Surface() {
  const m = useActiveMineConfig();
  return (
    <div
      className="relative w-full overflow-hidden"
      style={{
        height: "var(--imt-surf-h)",
        background: `linear-gradient(180deg, ${m.skyFrom} 0%, ${m.skyFrom} 40%, ${m.skyTo} 100%)`,
      }}
    >
      {/* Sun */}
      <div className="absolute left-3 top-3 h-16 w-16 sm:h-20 sm:w-20">
        <Sun className="h-full w-full" />
      </div>

      {/* Clouds */}
      <div className="absolute left-0 top-6 h-24 w-full opacity-90 sm:top-4 sm:h-28">
        <Clouds className="h-full w-full" />
      </div>

      {/* Mountains (horizon) */}
      <div className="absolute bottom-[88px] left-0 h-32 w-full sm:h-40">
        <Mountains className="h-full w-full" />
      </div>

      {/* Distant trees on the horizon */}
      <div className="absolute bottom-[96px] left-[8%] h-16 w-24 opacity-80">
        <Trees className="h-full w-full" />
      </div>
      <div className="absolute bottom-[92px] right-[6%] h-14 w-20 opacity-70">
        <Trees className="h-full w-full" />
      </div>

      {/* Ground / grass strip */}
      <div
        className="absolute bottom-0 left-0 h-[104px] w-full"
        style={{
          background: `linear-gradient(180deg, ${m.groundColor} 0%, ${m.groundColor} 55%, #3f2818 100%)`,
        }}
      >
        {/* grassy top edge */}
        <svg viewBox="0 0 1200 30" preserveAspectRatio="none" className="absolute -top-3 left-0 h-4 w-full" aria-hidden>
          <path d="M0 30 L0 18 Q40 6 80 14 Q120 2 160 12 Q200 0 240 10 Q300 4 360 12 Q420 2 480 10 Q540 0 600 12 Q660 4 720 10 Q780 0 840 12 Q900 4 960 10 Q1020 0 1080 12 Q1140 4 1200 10 L1200 30 Z" fill={m.groundColor} />
        </svg>
        {/* ground texture dots */}
        <div className="absolute inset-0 opacity-30" style={{ backgroundImage: `radial-gradient(${m.rockTintDark}22 1px, transparent 1px)`, backgroundSize: "24px 24px" }} />
      </div>

      {/* Mine entrance (aligned with elevator shaft below) */}
      <div className="absolute bottom-0 left-[1%] h-[94%] w-[26%] sm:w-[22%]">
        <MineEntrance />
      </div>

      {/* Conveyor belt from entrance hopper to warehouse */}
      <div
        className="absolute bottom-[40%] left-[24%] h-3 w-[10%] overflow-hidden rounded-full border border-stone-700 bg-stone-800/80 shadow sm:bottom-[42%]"
        aria-hidden
      >
        <div
          className="h-full w-[200%]"
          style={{
            backgroundImage: `repeating-linear-gradient(90deg, ${m.oreGlow} 0 6px, transparent 6px 14px)`,
            animation: "imt-shimmer 1s linear infinite",
          }}
        />
      </div>

      {/* Warehouse */}
      <div className="absolute bottom-0 left-[33%] h-[82%] w-[30%] sm:w-[27%]">
        <Warehouse />
      </div>

      {/* Cart track (from warehouse to off-screen right) */}
      <div className="absolute bottom-3 left-[60%] h-12 w-[42%]">
        {/* rails */}
        <svg viewBox="0 0 200 40" preserveAspectRatio="none" className="absolute bottom-0 left-0 h-8 w-full" aria-hidden>
          <rect x="0" y="20" width="200" height="4" fill="#6b4226" />
          <rect x="0" y="30" width="200" height="4" fill="#6b4226" />
          {/* sleepers */}
          {Array.from({ length: 10 }).map((_, i) => (
            <rect key={i} x={i * 20 + 2} y="18" width="6" height="20" fill="#4a2c10" />
          ))}
        </svg>
        <TransportCart />
      </div>

      {/* Foreground bushes */}
      <div className="absolute bottom-1 left-[30%] h-8 w-20 opacity-90">
        <Bushes className="h-full w-full" />
      </div>
      <div className="absolute bottom-1 right-[44%] h-7 w-16 opacity-80">
        <Bushes className="h-full w-full" />
      </div>
    </div>
  );
}
