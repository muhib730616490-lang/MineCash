"use client";
import { useGameStore } from "@/store/gameStore";
import { useActiveMineConfig } from "@/game/useMine";
import { useT } from "@/game/useT";
import { warehouseCapacity } from "@/game/config";
import { formatNumber } from "@/lib/format";
import { CoinIcon } from "./icons";

/** Surface warehouse building with an ore pile, stored counter, and coin float on sale. */
export function Warehouse() {
  const m = useActiveMineConfig();
  const t = useT();
  const ore = useGameStore((s) => s.mines[s.activeMine].warehouse.ore);
  const capLevel = useGameStore((s) => s.mines[s.activeMine].warehouse.capacityLevel);
  const lastSaleValue = useGameStore((s) => s.lastSaleValue);
  const lastSaleAt = useGameStore((s) => s.lastSaleAt);

  const cap = warehouseCapacity(capLevel);

  return (
    <div className="relative h-full w-full">
      <svg viewBox="0 0 150 170" className="crisp h-full w-full" preserveAspectRatio="xMidYMax meet" aria-hidden>
        <defs>
          <linearGradient id="wh-body" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#9a6a3a" />
            <stop offset="1" stopColor="#6e4218" />
          </linearGradient>
          <linearGradient id="wh-roof" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#b91c1c" />
            <stop offset="1" stopColor="#7f1d1d" />
          </linearGradient>
          <radialGradient id="wh-ore" cx="0.5" cy="0.3" r="0.8">
            <stop offset="0" stopColor={m.oreGlow} />
            <stop offset="1" stopColor={m.oreColor} />
          </radialGradient>
        </defs>

        <ellipse cx="75" cy="162" rx="62" ry="8" fill="rgba(0,0,0,0.25)" />

        {/* ore pile out front (left) */}
        <g>
          <path d="M8 162 Q14 130 34 132 Q44 122 56 130 Q66 124 72 140 L72 162 Z" fill="url(#wh-ore)" stroke={m.rockTintDark} strokeWidth="1.5" />
          <circle cx="26" cy="140" r="3.4" fill={m.oreGlow} className="imt-ore-pulse" style={{ color: m.oreGlow }} />
          <circle cx="44" cy="134" r="2.8" fill={m.oreGlow} className="imt-ore-pulse" style={{ color: m.oreGlow, animationDelay: "0.6s" }} />
          <circle cx="58" cy="146" r="2.4" fill={m.oreGlow} className="imt-ore-pulse" style={{ color: m.oreGlow, animationDelay: "1.1s" }} />
        </g>

        <rect x="52" y="78" width="86" height="80" rx="3" fill="url(#wh-body)" stroke="#4a2c10" strokeWidth="2" />
        <g stroke="#4a2c10" strokeWidth="1" opacity="0.5">
          <line x1="52" y1="100" x2="138" y2="100" />
          <line x1="52" y1="120" x2="138" y2="120" />
          <line x1="52" y1="140" x2="138" y2="140" />
        </g>

        <path d="M46 80 L95 48 L144 80 Z" fill="url(#wh-roof)" stroke="#5b1414" strokeWidth="2" strokeLinejoin="round" />
        <rect x="46" y="78" width="98" height="6" rx="2" fill="#7f1d1d" stroke="#5b1414" strokeWidth="1.5" />
        <path d="M52 70 L70 70 L66 80 L56 80 Z" fill="#6b7280" stroke="#374151" strokeWidth="1.5" />
        <rect x="58" y="64" width="6" height="8" fill="#4a2c10" />

        <rect x="84" y="116" width="22" height="42" rx="2" fill="#4a2c10" stroke="#2a1808" strokeWidth="1.5" />
        <circle cx="102" cy="138" r="1.6" fill="#e4b85a" />

        <rect x="60" y="100" width="16" height="14" rx="1.5" fill="#fde68a" stroke="#4a2c10" strokeWidth="1.5" />
        <line x1="68" y1="100" x2="68" y2="114" stroke="#4a2c10" strokeWidth="1" />
        <line x1="60" y1="107" x2="76" y2="107" stroke="#4a2c10" strokeWidth="1" />
        <rect x="112" y="100" width="16" height="14" rx="1.5" fill="#fde68a" stroke="#4a2c10" strokeWidth="1.5" />
        <line x1="120" y1="100" x2="120" y2="114" stroke="#4a2c10" strokeWidth="1" />
        <line x1="112" y1="107" x2="128" y2="107" stroke="#4a2c10" strokeWidth="1" />

        <rect x="70" y="86" width="50" height="12" rx="2" fill="#3a2410" />
        <text x="95" y="95" textAnchor="middle" fontSize="7" fontWeight="800" fill="#e4b85a" fontFamily="ui-sans-serif, system-ui, sans-serif" letterSpacing="0.5">
          STORAGE
        </text>
      </svg>

      {/* floating coin text on sale — keyed by sale time so each sale remounts the animation */}
      {lastSaleValue > 0 && lastSaleAt > 0 && (
        <div
          key={lastSaleAt}
          className="imt-float-up pointer-events-none absolute left-1/2 top-1/2 z-30 -translate-x-1/2 rounded-full border border-amber-300/60 bg-stone-900/90 px-2 py-0.5 text-xs font-bold text-amber-300 shadow-lg"
        >
          <CoinIcon className="mr-0.5 inline size-3" />+{formatNumber(lastSaleValue)}
        </div>
      )}

      {/* stored counter badge */}
      <div className="absolute -top-1 left-1/2 -translate-x-1/2 rounded-full border border-amber-300/40 bg-stone-900/85 px-2 py-0.5 text-[10px] font-bold text-amber-200 shadow sm:text-xs">
        <span className="text-amber-400/70">{t("stored")}: </span>
        <span className="tabular-nums">{formatNumber(ore)}</span>
        <span className="text-amber-400/50">/{formatNumber(cap)}</span>
      </div>
    </div>
  );
}
