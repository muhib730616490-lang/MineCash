"use client";
import { useState } from "react";
import { useAdminStore } from "@/store/adminStore";
import { useAdminConfig } from "@/store/adminConfig";
import { useT } from "@/game/useT";
import { formatNumber } from "@/lib/format";
import { formatTime } from "@/lib/format";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  LayoutDashboard,
  Users,
  DollarSign,
  Tv,
  CalendarDays,
  Share2,
  Banknote,
  ShieldAlert,
  BarChart3,
  Settings,
  LogOut,
  Search,
  Ban,
  CheckCircle,
  Plus,
  Trash2,
  AlertTriangle,
} from "lucide-react";
import { toast } from "sonner";

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
}

type Tab =
  | "overview"
  | "players"
  | "economy"
  | "ads"
  | "events"
  | "referral"
  | "withdrawal"
  | "anticheat"
  | "analytics"
  | "settings";

const TABS: { id: Tab; label: string; icon: React.ReactNode }[] = [
  { id: "overview", label: "Overview", icon: <LayoutDashboard className="size-4" /> },
  { id: "players", label: "Players", icon: <Users className="size-4" /> },
  { id: "economy", label: "Economy", icon: <DollarSign className="size-4" /> },
  { id: "ads", label: "Ads", icon: <Tv className="size-4" /> },
  { id: "events", label: "Events", icon: <CalendarDays className="size-4" /> },
  { id: "referral", label: "Referral", icon: <Share2 className="size-4" /> },
  { id: "withdrawal", label: "Withdrawal", icon: <Banknote className="size-4" /> },
  { id: "anticheat", label: "Anti-Cheat", icon: <ShieldAlert className="size-4" /> },
  { id: "analytics", label: "Analytics", icon: <BarChart3 className="size-4" /> },
  { id: "settings", label: "Settings", icon: <Settings className="size-4" /> },
];

export function AdminPanel({ open, onOpenChange }: Props) {
  const t = useT();
  const isAdmin = useAdminStore((s) => s.isAdmin);
  const loginAdmin = useAdminStore((s) => s.loginAdmin);
  const logoutAdmin = useAdminStore((s) => s.logoutAdmin);
  const [password, setPassword] = useState("");
  const [tab, setTab] = useState<Tab>("overview");

  if (!open) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="h-[92dvh] max-w-5xl border-amber-900/50 bg-stone-950 p-0 text-amber-50 sm:h-[88dvh]" showCloseButton={false} aria-label="Admin Dashboard">
        <DialogTitle className="sr-only">Admin Dashboard</DialogTitle>
        <DialogDescription className="sr-only">Administrator control panel</DialogDescription>
        {!isAdmin ? (
          <AdminLogin password={password} setPassword={setPassword} onLogin={() => { if (loginAdmin(password)) { toast.success("Admin logged in"); } else { toast.error("Wrong password"); } }} />
        ) : (
          <div className="flex h-full flex-col">
            {/* Header */}
            <div className="flex items-center justify-between border-b border-amber-900/40 bg-stone-900 px-4 py-2">
              <div className="flex items-center gap-2">
                <ShieldAlert className="size-5 text-amber-400" />
                <span className="text-sm font-bold text-amber-200">Admin Dashboard</span>
              </div>
              <Button variant="ghost" size="sm" className="text-amber-300" onClick={() => { logoutAdmin(); onOpenChange(false); }}>
                <LogOut className="size-4" /> Logout
              </Button>
            </div>

            {/* Tab bar */}
            <div className="no-scrollbar flex gap-1 overflow-x-auto border-b border-amber-900/40 bg-stone-900/60 px-2 py-1.5">
              {TABS.map((tb) => (
                <button
                  key={tb.id}
                  type="button"
                  onClick={(e) => { e.stopPropagation(); setTab(tb.id); }}
                  className={[
                    "flex shrink-0 items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-semibold transition",
                    tab === tb.id
                      ? "bg-amber-700 text-stone-950"
                      : "text-amber-200/70 hover:bg-stone-800 hover:text-amber-100",
                  ].join(" ")}
                >
                  {tb.icon}
                  {tb.label}
                </button>
              ))}
            </div>

            {/* Content */}
            <div className="mine-scroll flex-1 overflow-y-auto p-4">
              {tab === "overview" && <OverviewTab />}
              {tab === "players" && <PlayersTab />}
              {tab === "economy" && <EconomyTab />}
              {tab === "ads" && <AdsTab />}
              {tab === "events" && <EventsTab />}
              {tab === "referral" && <ReferralTab />}
              {tab === "withdrawal" && <WithdrawalTab />}
              {tab === "anticheat" && <AntiCheatTab />}
              {tab === "analytics" && <AnalyticsTab />}
              {tab === "settings" && <SettingsTab />}
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

/* ---- Admin Login ---- */
function AdminLogin({ password, setPassword, onLogin }: { password: string; setPassword: (v: string) => void; onLogin: () => void }) {
  return (
    <div className="flex h-full flex-col items-center justify-center gap-4 p-8">
      <ShieldAlert className="size-12 text-amber-400" />
      <h2 className="text-xl font-bold text-amber-200">Admin Access</h2>
      <p className="text-center text-xs text-stone-400">Enter admin password to continue</p>
      <Input
        type="password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        placeholder="Password"
        className="max-w-xs border-amber-900/40 bg-stone-900 text-center"
        onKeyDown={(e) => e.key === "Enter" && onLogin()}
      />
      <Button className="bg-amber-600 text-stone-950 hover:bg-amber-500" onClick={onLogin}>
        Login
      </Button>
      <p className="text-[10px] text-stone-500">Demo password: admin123</p>
    </div>
  );
}

/* ---- Overview Tab ---- */
function OverviewTab() {
  const players = useAdminStore((s) => s.players);
  const withdrawals = useAdminStore((s) => s.withdrawals);
  const analytics = useAdminStore.getState().getAnalytics();
  const mines = [
    { name: "Copper Mine", players: players.filter(p => p.floorsUnlocked >= 1).length, revenue: players.filter(p => p.floorsUnlocked >= 1).reduce((a,p) => a + p.adsWatched, 0) * 0.01 },
    { name: "Gold Mine", players: players.filter(p => p.floorsUnlocked >= 20).length, revenue: 0 },
    { name: "Raw Gold Mine", players: 0, revenue: 0 },
  ];
  const mostProfitable = mines.reduce((a, b) => (b.revenue > a.revenue ? b : a), mines[0]);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        <MetricCard label="Total Players" value={String(analytics.totalPlayers)} />
        <MetricCard label="Online Now" value={String(analytics.onlinePlayers)} accent="text-emerald-400" />
        <MetricCard label="New Today" value={String(analytics.newPlayersToday)} accent="text-sky-400" />
        <MetricCard label="Daily Active" value={String(analytics.dailyActiveUsers)} />
        <MetricCard label="Monthly Active" value={String(analytics.monthlyActiveUsers)} />
        <MetricCard label="Avg Session" value={formatTime(analytics.averageSessionTime)} />
      </div>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <div className="rounded-xl border border-amber-900/40 bg-stone-900/60 p-3">
          <div className="mb-2 text-xs font-bold text-amber-300">Revenue Estimation</div>
          <div className="text-2xl font-bold text-emerald-400">${analytics.totalRevenue.toFixed(2)}</div>
          <div className="text-[10px] text-stone-400">From {analytics.totalAdsWatched} ad views</div>
        </div>
        <div className="rounded-xl border border-amber-900/40 bg-stone-900/60 p-3">
          <div className="mb-2 text-xs font-bold text-amber-300">Most Profitable Mine</div>
          <div className="text-lg font-bold text-amber-200">{mostProfitable?.name}</div>
          <div className="text-[10px] text-stone-400">${(mostProfitable?.revenue ?? 0).toFixed(2)} est. revenue</div>
        </div>
      </div>

      <div className="rounded-xl border border-amber-900/40 bg-stone-900/60 p-3">
        <div className="mb-2 text-xs font-bold text-amber-300">Most Active Players</div>
        <div className="space-y-1">
          {[...players].sort((a, b) => b.totalPlayTime - a.totalPlayTime).slice(0, 5).map((p, i) => (
            <div key={p.id} className="flex items-center gap-2 text-xs">
              <span className="w-4 text-stone-500">#{i + 1}</span>
              <span className="flex-1 truncate font-medium text-amber-100">{p.name}</span>
              <span className="text-stone-400">{formatTime(p.totalPlayTime)}</span>
              <span className="text-amber-300">{formatNumber(p.coins)} coins</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function MetricCard({ label, value, accent }: { label: string; value: string; accent?: string }) {
  return (
    <div className="rounded-xl border border-amber-900/40 bg-stone-900/60 p-3">
      <div className="text-[10px] text-stone-400">{label}</div>
      <div className={`mt-1 text-xl font-bold ${accent ?? "text-amber-200"}`}>{value}</div>
    </div>
  );
}

/* ---- Players Tab ---- */
function PlayersTab() {
  const players = useAdminStore((s) => s.players);
  const modifyPlayerCoins = useAdminStore((s) => s.modifyPlayerCoins);
  const modifyPlayerGems = useAdminStore((s) => s.modifyPlayerGems);
  const modifyPlayerWallet = useAdminStore((s) => s.modifyPlayerWallet);
  const banPlayer = useAdminStore((s) => s.banPlayer);
  const unbanPlayer = useAdminStore((s) => s.unbanPlayer);
  const resetPlayerProgress = useAdminStore((s) => s.resetPlayerProgress);
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<string | null>(null);

  const filtered = players.filter(p =>
    p.name.toLowerCase().includes(search.toLowerCase()) ||
    p.id.toLowerCase().includes(search.toLowerCase())
  );
  const selectedPlayer = players.find(p => p.id === selected);

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        <Search className="size-4 text-stone-400" />
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search players..."
          className="border-amber-900/40 bg-stone-900"
        />
      </div>

      <div className="space-y-1.5">
        {filtered.map(p => (
          <div key={p.id} className="flex items-center gap-2 rounded-lg border border-stone-700/50 bg-stone-900/60 p-2">
            <div className="flex size-8 items-center justify-center rounded-full bg-amber-700 text-xs font-bold text-stone-950">
              {p.name.charAt(0)}
            </div>
            <div className="min-w-0 flex-1">
              <div className="truncate text-xs font-bold text-amber-100">
                {p.name} {p.banned && <span className="text-red-400">(banned)</span>}
              </div>
              <div className="text-[9px] text-stone-400">
                {formatNumber(p.coins)} coins · {p.floorsUnlocked} floors · {p.adsWatched} ads
              </div>
            </div>
            <Button size="sm" variant="outline" className="h-7 border-amber-900/40 text-xs" onClick={() => setSelected(p.id)}>
              Manage
            </Button>
          </div>
        ))}
      </div>

      {selectedPlayer && (
        <div className="rounded-xl border border-amber-700/50 bg-stone-900/80 p-3">
          <div className="mb-2 flex items-center justify-between">
            <span className="text-sm font-bold text-amber-200">{selectedPlayer.name}</span>
            <Button size="sm" variant="ghost" className="h-6 text-xs" onClick={() => setSelected(null)}>Close</Button>
          </div>
          <div className="grid grid-cols-3 gap-2">
            <PlayerField label="Coins" value={selectedPlayer.coins} onChange={(v) => modifyPlayerCoins(selectedPlayer.id, v)} />
            <PlayerField label="Gems" value={selectedPlayer.gems} onChange={(v) => modifyPlayerGems(selectedPlayer.id, v)} />
            <PlayerField label="Wallet" value={selectedPlayer.walletBalance} onChange={(v) => modifyPlayerWallet(selectedPlayer.id, v)} />
          </div>
          <div className="mt-2 flex gap-2">
            <Button size="sm" variant="outline" className="flex-1 border-red-900/50 text-red-300" onClick={() => { resetPlayerProgress(selectedPlayer.id); toast.success("Progress reset"); }}>
              Reset
            </Button>
            {selectedPlayer.banned ? (
              <Button size="sm" variant="outline" className="flex-1 border-emerald-900/50 text-emerald-300" onClick={() => { unbanPlayer(selectedPlayer.id); toast.success("Unbanned"); }}>
                <CheckCircle className="size-3" /> Unban
              </Button>
            ) : (
              <Button size="sm" variant="outline" className="flex-1 border-red-900/50 text-red-300" onClick={() => { banPlayer(selectedPlayer.id); toast.success("Banned"); }}>
                <Ban className="size-3" /> Ban
              </Button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function PlayerField({ label, value, onChange }: { label: string; value: number; onChange: (v: number) => void }) {
  return (
    <div>
      <Label className="text-[9px] text-stone-400">{label}</Label>
      <Input
        type="number"
        defaultValue={value}
        onBlur={(e) => onChange(parseInt(e.target.value) || 0)}
        className="h-8 border-amber-900/40 bg-stone-900 text-xs"
      />
    </div>
  );
}

/* ---- Economy Tab ---- */
function EconomyTab() {
  const economy = useAdminConfig((s) => s.economy);
  const updateEconomy = useAdminConfig((s) => s.updateEconomy);
  const [values, setValues] = useState(economy);

  const save = () => {
    updateEconomy(values);
    toast.success("Economy config saved");
  };

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-2">
        <ConfigField label="Starting Coins" value={values.startingCoins} onChange={(v) => setValues({ ...values, startingCoins: v })} />
        <ConfigField label="Starting Gems" value={values.startingGems} onChange={(v) => setValues({ ...values, startingGems: v })} />
        <ConfigField label="Ore Growth Multiplier" value={values.oreGrowthMultiplier} step={0.1} onChange={(v) => setValues({ ...values, oreGrowthMultiplier: v })} />
        <ConfigField label="Gems per Coin Threshold" value={values.gemsPerCoinThreshold} onChange={(v) => setValues({ ...values, gemsPerCoinThreshold: v })} />
        <ConfigField label="Miner Upgrade Base" value={values.minerUpgradeBase} onChange={(v) => setValues({ ...values, minerUpgradeBase: v })} />
        <ConfigField label="Miner Upgrade Growth" value={values.minerUpgradeGrowth} step={0.01} onChange={(v) => setValues({ ...values, minerUpgradeGrowth: v })} />
        <ConfigField label="Miner Manager Base" value={values.minerManagerBase} onChange={(v) => setValues({ ...values, minerManagerBase: v })} />
        <ConfigField label="Miner Manager Growth" value={values.minerManagerGrowth} step={0.01} onChange={(v) => setValues({ ...values, minerManagerGrowth: v })} />
        <ConfigField label="Elevator Manager Cost" value={values.elevatorManagerCost} onChange={(v) => setValues({ ...values, elevatorManagerCost: v })} />
        <ConfigField label="Warehouse Manager Cost" value={values.warehouseManagerCost} onChange={(v) => setValues({ ...values, warehouseManagerCost: v })} />
        <ConfigField label="Ad Cash Seconds" value={values.adCashSeconds} onChange={(v) => setValues({ ...values, adCashSeconds: v })} />
        <ConfigField label="Ad Cash Minimum" value={values.adCashMinimum} onChange={(v) => setValues({ ...values, adCashMinimum: v })} />
        <ConfigField label="Ad Gem Reward" value={values.adGemReward} onChange={(v) => setValues({ ...values, adGemReward: v })} />
        <ConfigField label="Ad Cooldown (ms)" value={values.adCooldownMs} onChange={(v) => setValues({ ...values, adCooldownMs: v })} />
        <ConfigField label="Boost Multiplier" value={values.boostMultiplier} step={0.5} onChange={(v) => setValues({ ...values, boostMultiplier: v })} />
        <ConfigField label="Boost Duration (ms)" value={values.boostDurationMs} onChange={(v) => setValues({ ...values, boostDurationMs: v })} />
      </div>

      {/* Offline earnings config */}
      <OfflineConfigSection />

      <Button className="w-full bg-amber-600 text-stone-950 hover:bg-amber-500" onClick={save}>
        Save Economy Config
      </Button>
    </div>
  );
}

function OfflineConfigSection() {
  const offline = useAdminConfig((s) => s.offline);
  const updateOffline = useAdminConfig((s) => s.updateOffline);
  return (
    <div className="rounded-xl border border-amber-900/40 bg-stone-900/60 p-3">
      <div className="mb-2 text-xs font-bold text-amber-300">Offline Earnings</div>
      <div className="grid grid-cols-2 gap-2">
        <ConfigField label="Efficiency (0..1, e.g. 0.10 = 10%)" value={offline.efficiency} step={0.01} onChange={(v) => updateOffline({ efficiency: v })} />
        <ConfigField label="Max Hours" value={offline.maxHours} step={1} onChange={(v) => updateOffline({ maxHours: v })} />
      </div>
    </div>
  );
}

function ConfigField({ label, value, onChange, step }: { label: string; value: number; onChange: (v: number) => void; step?: number }) {
  return (
    <div>
      <Label className="text-[9px] text-stone-400">{label}</Label>
      <Input
        type="number"
        step={step ?? 1}
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value) || 0)}
        className="h-8 border-amber-900/40 bg-stone-900 text-xs"
      />
    </div>
  );
}

/* ---- Ads Tab ---- */
function AdsTab() {
  const ads = useAdminConfig((s) => s.ads);
  const updateAds = useAdminConfig((s) => s.updateAds);
  return (
    <div className="space-y-3">
      <ToggleRow label="Rewarded Ads" checked={ads.rewardedAdsEnabled} onChange={(v) => updateAds({ rewardedAdsEnabled: v })} />
      <ToggleRow label="Interstitial Ads" checked={ads.interstitialAdsEnabled} onChange={(v) => updateAds({ interstitialAdsEnabled: v })} />
      <ToggleRow label="Banner Ads" checked={ads.bannerAdsEnabled} onChange={(v) => updateAds({ bannerAdsEnabled: v })} />
      <div>
        <Label className="text-[10px] text-stone-400">Max Ads Per Hour</Label>
        <Input type="number" value={ads.adFrequency} onChange={(e) => updateAds({ adFrequency: parseInt(e.target.value) || 0 })} className="border-amber-900/40 bg-stone-900" />
      </div>
      <div>
        <Label className="text-[10px] text-stone-400">Ad Network Provider</Label>
        <Input value={ads.networkProvider} onChange={(e) => updateAds({ networkProvider: e.target.value })} placeholder="none | admob | unity | ironsource" className="border-amber-900/40 bg-stone-900" />
      </div>
      <div className="rounded-lg border border-sky-900/40 bg-sky-950/30 p-3 text-[10px] text-sky-300">
        Architecture supports connecting any ad network later via the networkProvider field. No provider is locked in.
      </div>
    </div>
  );
}

function ToggleRow({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <div className="flex items-center justify-between rounded-lg border border-amber-900/30 bg-stone-900/60 p-3">
      <Label className="text-sm font-medium">{label}</Label>
      <Switch checked={checked} onCheckedChange={onChange} />
    </div>
  );
}

/* ---- Events Tab ---- */
function EventsTab() {
  const events = useAdminConfig((s) => s.events);
  const addEvent = useAdminConfig((s) => s.addEvent);
  const updateEvent = useAdminConfig((s) => s.updateEvent);
  const deleteEvent = useAdminConfig((s) => s.deleteEvent);

  const handleCreate = () => {
    try {
      addEvent({
        id: "evt_" + Date.now().toString(36),
        name: "New Event",
        description: "Event description",
        startDate: Date.now(),
        endDate: Date.now() + 86400000 * 7,
        enabled: true,
        rewardType: "coins",
        rewardValue: 1000,
        winnerSelection: "random",
        winnerCount: 10,
        manualWinners: [],
      });
      toast.success("Event created");
    } catch (err) {
      toast.error("Failed to create event");
    }
  };

  return (
    <div className="space-y-3">
      <Button className="w-full bg-amber-600 text-stone-950 hover:bg-amber-500" onClick={() => {
        addEvent({
          id: "evt_" + Date.now().toString(36),
          name: "New Event",
          description: "Event description",
          startDate: Date.now(),
          endDate: Date.now() + 86400000 * 7,
          enabled: true,
          rewardType: "coins",
          rewardValue: 1000,
          winnerSelection: "random",
          winnerCount: 10,
          manualWinners: [],
        });
        toast.success("Event created");
      }}>
        <Plus className="size-4" /> Create Event
      </Button>
      {events.length === 0 ? (
        <div className="rounded-lg border border-stone-700/50 bg-stone-900/40 p-4 text-center text-xs text-stone-500">
          No events yet. Create one to engage players!
        </div>
      ) : (
        <div className="space-y-2">
          {events.map(e => (
            <div key={e.id} className="rounded-xl border border-amber-900/40 bg-stone-900/60 p-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-amber-200">{e.name}</span>
                <div className="flex gap-1">
                  <Button size="sm" variant="ghost" className="h-6 text-xs" onClick={() => updateEvent(e.id, { enabled: !e.enabled })}>
                    {e.enabled ? "Disable" : "Enable"}
                  </Button>
                  <Button size="sm" variant="ghost" className="h-6 text-red-400" onClick={() => { deleteEvent(e.id); toast.success("Deleted"); }}>
                    <Trash2 className="size-3" />
                  </Button>
                </div>
              </div>
              <div className="mt-1 text-[10px] text-stone-400">{e.description}</div>
              <div className="mt-1 flex gap-2 text-[10px]">
                <span className="rounded bg-amber-900/40 px-1.5 py-0.5 text-amber-300">{e.rewardType}: {formatNumber(e.rewardValue)}</span>
                <span className="rounded bg-stone-800 px-1.5 py-0.5 text-stone-400">{e.winnerSelection} · {e.winnerCount} winners</span>
                <span className="rounded bg-stone-800 px-1.5 py-0.5 text-stone-400">{e.enabled ? "Active" : "Disabled"}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ---- Referral Tab ---- */
function ReferralTab() {
  const referral = useAdminConfig((s) => s.referral);
  const updateReferral = useAdminConfig((s) => s.updateReferral);
  const analytics = useAdminStore.getState().getAnalytics();
  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-2">
        <ConfigField label="Inviter Reward (Coins)" value={referral.inviterRewardCoins} onChange={(v) => updateReferral({ inviterRewardCoins: v })} />
        <ConfigField label="Inviter Reward (Gems)" value={referral.inviterRewardGems} onChange={(v) => updateReferral({ inviterRewardGems: v })} />
        <ConfigField label="Invitee Reward (Coins)" value={referral.inviteeRewardCoins} onChange={(v) => updateReferral({ inviteeRewardCoins: v })} />
        <ConfigField label="Invitee Reward (Gems)" value={referral.inviteeRewardGems} onChange={(v) => updateReferral({ inviteeRewardGems: v })} />
        <ConfigField label="Active Threshold (sec)" value={referral.activeThresholdSec} onChange={(v) => updateReferral({ activeThresholdSec: v })} />
        <ConfigField label="Max Referrals (0=unlimited)" value={referral.maxReferrals} onChange={(v) => updateReferral({ maxReferrals: v })} />
      </div>
      <div className="rounded-xl border border-amber-900/40 bg-stone-900/60 p-3">
        <div className="text-xs font-bold text-amber-300">Referral Statistics</div>
        <div className="mt-1 text-sm text-amber-200">{analytics.totalReferrals} active referrals</div>
      </div>
    </div>
  );
}

/* ---- Withdrawal Tab ---- */
function WithdrawalTab() {
  const withdrawals = useAdminStore((s) => s.withdrawals);
  const approveWithdrawal = useAdminStore((s) => s.approveWithdrawal);
  const rejectWithdrawal = useAdminStore((s) => s.rejectWithdrawal);
  const completeWithdrawal = useAdminStore((s) => s.completeWithdrawal);
  const withdrawalConfig = useAdminConfig((s) => s.withdrawal);
  const updateWithdrawal = useAdminConfig((s) => s.updateWithdrawal);

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-2">
        <ConfigField label="Minimum Withdrawal" value={withdrawalConfig.minimumWithdrawal} onChange={(v) => updateWithdrawal({ minimumWithdrawal: v })} />
        <ConfigField label="Processing Time (hours)" value={withdrawalConfig.processingTimeHours} onChange={(v) => updateWithdrawal({ processingTimeHours: v })} />
      </div>
      <ToggleRow label="Withdrawals Enabled" checked={withdrawalConfig.enabled} onChange={(v) => updateWithdrawal({ enabled: v })} />

      {/* Crypto currencies configuration */}
      <div className="rounded-xl border border-amber-900/40 bg-stone-900/60 p-3">
        <div className="mb-2 text-xs font-bold text-amber-300">Supported Crypto Currencies</div>
        <Input
          value={withdrawalConfig.cryptoCurrencies.join(", ")}
          onChange={(e) => updateWithdrawal({ cryptoCurrencies: e.target.value.split(",").map(s => s.trim()).filter(Boolean) })}
          placeholder="USDT, BTC, ETH, BNB"
          className="border-amber-900/40 bg-stone-900 text-xs"
        />
        <div className="mt-1 text-[9px] text-stone-400">Comma-separated currency codes</div>
      </div>

      <div className="text-xs font-bold text-amber-300">Withdrawal Requests ({withdrawals.length})</div>
      {withdrawals.length === 0 ? (
        <div className="rounded-lg border border-stone-700/50 bg-stone-900/40 p-4 text-center text-xs text-stone-500">
          No withdrawal requests yet.
        </div>
      ) : (
        <div className="space-y-2">
          {withdrawals.map(w => (
            <div key={w.id} className="rounded-xl border border-stone-700/50 bg-stone-900/60 p-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm font-bold text-amber-200">{w.playerName}</div>
                  <div className="text-[10px] text-stone-400">{formatNumber(w.amount)} via {w.method}</div>
                </div>
                <span className={[
                  "rounded-full px-2 py-0.5 text-[9px] font-bold",
                  w.status === "pending" ? "bg-amber-800 text-amber-200" :
                  w.status === "approved" ? "bg-sky-800 text-sky-200" :
                  w.status === "completed" ? "bg-emerald-800 text-emerald-200" :
                  "bg-red-800 text-red-200",
                ].join(" ")}>{w.status}</span>
              </div>
              {w.status === "pending" && (
                <div className="mt-2 flex gap-1">
                  <Button size="sm" className="h-7 flex-1 bg-emerald-600 text-white" onClick={() => { approveWithdrawal(w.id); toast.success("Approved"); }}>Approve</Button>
                  <Button size="sm" variant="outline" className="h-7 flex-1 border-red-900/50 text-red-300" onClick={() => { rejectWithdrawal(w.id); toast.success("Rejected"); }}>Reject</Button>
                </div>
              )}
              {w.status === "approved" && (
                <Button size="sm" className="mt-2 h-7 w-full bg-emerald-600 text-white" onClick={() => { completeWithdrawal(w.id); toast.success("Completed"); }}>
                  <CheckCircle className="size-3" /> Mark Completed
                </Button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ---- Anti-Cheat Tab ---- */
function AntiCheatTab() {
  const logs = useAdminStore((s) => s.antiCheatLogs);
  const resolveAntiCheatLog = useAdminStore((s) => s.resolveAntiCheatLog);
  return (
    <div className="space-y-3">
      <div className="rounded-lg border border-amber-900/40 bg-stone-900/60 p-3 text-[10px] text-amber-300">
        <AlertTriangle className="mr-1 inline size-3" />
        Anti-cheat system monitors: duplicate accounts, impossible production, modified data, ad abuse, referral abuse, suspicious wallet activity.
      </div>
      {logs.length === 0 ? (
        <div className="rounded-lg border border-stone-700/50 bg-stone-900/40 p-4 text-center text-xs text-stone-500">
          No suspicious activity detected. System is monitoring.
        </div>
      ) : (
        <div className="space-y-2">
          {logs.map(l => (
            <div key={l.id} className={[
              "rounded-xl border p-3",
              l.severity === "high" ? "border-red-700/50 bg-red-950/20" :
              l.severity === "medium" ? "border-amber-700/50 bg-amber-950/20" :
              "border-stone-700/50 bg-stone-900/60",
            ].join(" ")}>
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs font-bold text-amber-200">{l.type.replace(/_/g, " ")}</div>
                  <div className="text-[10px] text-stone-400">{l.playerName}: {l.description}</div>
                </div>
                <span className={[
                  "rounded-full px-2 py-0.5 text-[9px] font-bold",
                  l.severity === "high" ? "bg-red-800 text-red-200" :
                  l.severity === "medium" ? "bg-amber-800 text-amber-200" :
                  "bg-stone-700 text-stone-300",
                ].join(" ")}>{l.severity}</span>
              </div>
              {!l.resolved && (
                <Button size="sm" variant="outline" className="mt-2 h-6 text-xs" onClick={() => { resolveAntiCheatLog(l.id); toast.success("Resolved"); }}>
                  Resolve
                </Button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ---- Analytics Tab ---- */
function AnalyticsTab() {
  const players = useAdminStore((s) => s.players);
  const analytics = useAdminStore.getState().getAnalytics();

  const totalCoins = players.reduce((a, p) => a + p.coins, 0);
  const totalGems = players.reduce((a, p) => a + p.gems, 0);
  const avgFloors = players.length > 0 ? (players.reduce((a, p) => a + p.floorsUnlocked, 0) / players.length).toFixed(1) : "0";

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        <MetricCard label="Est. Revenue" value={`$${analytics.totalRevenue.toFixed(2)}`} accent="text-emerald-400" />
        <MetricCard label="Total Ads" value={String(analytics.totalAdsWatched)} />
        <MetricCard label="Total Referrals" value={String(analytics.totalReferrals)} />
        <MetricCard label="Total Coins" value={formatNumber(totalCoins)} />
        <MetricCard label="Total Gems" value={formatNumber(totalGems)} />
        <MetricCard label="Avg Floors" value={avgFloors} />
        <MetricCard label="Withdrawals" value={String(analytics.totalWithdrawals)} />
        <MetricCard label="Pending Withdrawals" value={String(analytics.pendingWithdrawals)} />
        <MetricCard label="Avg Session" value={formatTime(analytics.averageSessionTime)} />
      </div>

      <div className="rounded-xl border border-amber-900/40 bg-stone-900/60 p-3">
        <div className="mb-2 text-xs font-bold text-amber-300">Player Retention</div>
        <div className="space-y-1 text-[10px]">
          <div className="flex justify-between"><span className="text-stone-400">Day 1 Retention</span><span className="text-amber-200">{analytics.dailyActiveUsers}/{analytics.totalPlayers} ({analytics.totalPlayers > 0 ? Math.round(analytics.dailyActiveUsers / analytics.totalPlayers * 100) : 0}%)</span></div>
          <div className="flex justify-between"><span className="text-stone-400">Month 1 Retention</span><span className="text-amber-200">{analytics.monthlyActiveUsers}/{analytics.totalPlayers} ({analytics.totalPlayers > 0 ? Math.round(analytics.monthlyActiveUsers / analytics.totalPlayers * 100) : 0}%)</span></div>
        </div>
      </div>

      <div className="rounded-xl border border-amber-900/40 bg-stone-900/60 p-3">
        <div className="mb-2 text-xs font-bold text-amber-300">Daily Growth</div>
        <div className="text-2xl font-bold text-sky-400">+{analytics.newPlayersToday}</div>
        <div className="text-[10px] text-stone-400">New players today</div>
      </div>
    </div>
  );
}

/* ---- Settings Tab ---- */
function SettingsTab() {
  const settings = useAdminConfig((s) => s.settings);
  const updateSettings = useAdminConfig((s) => s.updateSettings);
  return (
    <div className="space-y-3">
      <ToggleRow label="Maintenance Mode" checked={settings.maintenanceMode} onChange={(v) => updateSettings({ maintenanceMode: v })} />
      <div>
        <Label className="text-[10px] text-stone-400">Maintenance Message</Label>
        <Input value={settings.maintenanceMessage} onChange={(e) => updateSettings({ maintenanceMessage: e.target.value })} className="border-amber-900/40 bg-stone-900" />
      </div>
      <ToggleRow label="Global Announcement" checked={settings.announcementEnabled} onChange={(v) => updateSettings({ announcementEnabled: v })} />
      <div>
        <Label className="text-[10px] text-stone-400">Announcement Text</Label>
        <Input value={settings.globalAnnouncement} onChange={(e) => updateSettings({ globalAnnouncement: e.target.value })} placeholder="Special event running!" className="border-amber-900/40 bg-stone-900" />
      </div>
      <div>
        <Label className="text-[10px] text-stone-400">Supported Languages (comma-separated)</Label>
        <Input value={settings.supportedLanguages.join(", ")} onChange={(e) => updateSettings({ supportedLanguages: e.target.value.split(",").map(s => s.trim()) })} className="border-amber-900/40 bg-stone-900" />
      </div>
    </div>
  );
}
