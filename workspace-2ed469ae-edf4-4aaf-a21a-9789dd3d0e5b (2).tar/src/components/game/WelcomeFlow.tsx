"use client";
import { useState } from "react";
import {
  Dialog,
  DialogContent,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useMetaStore } from "@/store/metaStore";
import { useGameStore } from "@/store/gameStore";
import { useT } from "@/game/useT";
import { useRTL } from "@/game/useT";
import { LANGUAGES } from "@/game/i18n";
import type { Language } from "@/game/types";
import { PickaxeIcon } from "./icons";
import { Check, ChevronRight, Zap, Tv, Truck, ArrowUpDown } from "lucide-react";

type Step = "welcome" | "language" | "account" | "intro" | "tutorial";

/** Multi-step welcome flow shown on first launch only. Replaces FirstLaunchDialog. */
export function WelcomeFlow() {
  const t = useT();
  const isRTL = useRTL();
  const welcomeCompleted = useMetaStore((s) => s.welcomeCompleted);
  const hydrated = useGameStore((s) => s.hydrated);
  const language = useMetaStore((s) => s.settings.language);
  const setMetaLanguage = useMetaStore((s) => s.setLanguage);
  const setGameLanguage = useGameStore((s) => s.setLanguage);
  const completeFirstLaunch = useGameStore((s) => s.completeFirstLaunch);
  const quickStart = useMetaStore((s) => s.quickStart);
  const linkGoogle = useMetaStore((s) => s.linkGoogle);
  const completeWelcome = useMetaStore((s) => s.completeWelcome);
  const [step, setStep] = useState<Step>("welcome");
  const [selectedLang, setSelectedLang] = useState<Language>(language);

  const open = hydrated && !welcomeCompleted;

  const handleSelectLanguage = (l: Language) => {
    setSelectedLang(l);
    setMetaLanguage(l);
    setGameLanguage(l);
  };

  const handleQuickStart = () => {
    quickStart();
    completeFirstLaunch(selectedLang);
    setStep("intro");
  };

  const handleGoogle = () => {
    // Simulated Google sign-in — in production this would use Google Identity
    const email = "miner@gmail.com";
    linkGoogle(email);
    completeFirstLaunch(selectedLang);
    setStep("intro");
  };

  const finish = () => {
    completeWelcome();
  };

  const skipAll = () => {
    if (!welcomeCompleted) {
      quickStart();
      completeFirstLaunch(selectedLang);
      completeWelcome();
    }
  };

  if (!open) return null;

  return (
    <Dialog open={open}>
      <DialogContent
        className="border-amber-900/50 bg-gradient-to-b from-stone-900 to-stone-950 text-amber-50 sm:max-w-md"
        showCloseButton={false}
      >
        {step === "welcome" && (
          <div className="flex flex-col items-center gap-4 py-4 text-center">
            <div className="flex size-20 items-center justify-center rounded-full bg-gradient-to-br from-amber-600 to-amber-800 shadow-lg">
              <PickaxeIcon className="size-10 text-amber-100" />
            </div>
            <div>
              <h2 className="text-2xl font-extrabold text-amber-200">{t("welcomeTitle")}</h2>
              <p className="mt-2 text-sm text-amber-200/70">{t("welcomeBody")}</p>
            </div>
            <Button
              className="w-full bg-amber-600 text-stone-950 hover:bg-amber-500"
              size="lg"
              onClick={() => setStep("language")}
            >
              {t("next")} <ChevronRight className="size-4" style={{ transform: isRTL ? "scaleX(-1)" : "" }} />
            </Button>
            <button onClick={skipAll} className="text-xs text-stone-500 hover:text-stone-400">
              {t("skip")}
            </button>
          </div>
        )}

        {step === "language" && (
          <div className="flex flex-col gap-4 py-4">
            <div className="text-center">
              <h3 className="text-lg font-bold text-amber-100">{t("chooseLanguage")}</h3>
              <p className="mt-1 text-xs text-amber-200/60">{t("chooseLanguageDesc")}</p>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {LANGUAGES.map((l) => (
                <button
                  key={l.id}
                  onClick={() => handleSelectLanguage(l.id)}
                  className={[
                    "flex flex-col items-center gap-2 rounded-xl border-2 p-4 transition active:scale-95",
                    selectedLang === l.id
                      ? "border-amber-400 bg-amber-900/40 shadow-lg"
                      : "border-stone-700 bg-stone-800/50 hover:border-amber-700/50 hover:bg-stone-800",
                  ].join(" ")}
                >
                  <span className="text-4xl">{l.flag}</span>
                  <span className="text-base font-bold text-amber-100">{l.nativeLabel}</span>
                  {selectedLang === l.id && (
                    <span className="flex size-5 items-center justify-center rounded-full bg-amber-500 text-stone-950">
                      <Check className="size-3" />
                    </span>
                  )}
                </button>
              ))}
            </div>
            <Button
              className="w-full bg-amber-600 text-stone-950 hover:bg-amber-500"
              size="lg"
              onClick={() => setStep("account")}
            >
              {t("next")} <ChevronRight className="size-4" style={{ transform: isRTL ? "scaleX(-1)" : "" }} />
            </Button>
            <button onClick={skipAll} className="text-center text-xs text-stone-500 hover:text-stone-400">
              {t("skip")}
            </button>
          </div>
        )}

        {step === "account" && (
          <div className="flex flex-col gap-4 py-4">
            <div className="text-center">
              <h3 className="text-lg font-bold text-amber-100">{t("player")}</h3>
              <p className="mt-1 text-xs text-amber-200/60">{t("chooseLanguageDesc")}</p>
            </div>
            <button
              onClick={handleQuickStart}
              className="flex items-center gap-3 rounded-xl border-2 border-amber-500/50 bg-amber-900/30 p-4 transition hover:bg-amber-900/50 active:scale-95"
            >
              <div className="flex size-10 items-center justify-center rounded-lg bg-amber-600 text-stone-950">
                <Zap className="size-5" />
              </div>
              <div className="flex-1 text-start">
                <div className="text-sm font-bold text-amber-100">{t("quickStart")}</div>
                <div className="text-xs text-amber-200/60">{t("welcomeBody")}</div>
              </div>
              <ChevronRight className="size-4 text-amber-400" style={{ transform: isRTL ? "scaleX(-1)" : "" }} />
            </button>
            <button
              onClick={handleGoogle}
              className="flex items-center gap-3 rounded-xl border-2 border-stone-700 bg-stone-800/50 p-4 transition hover:bg-stone-800 active:scale-95"
            >
              <div className="flex size-10 items-center justify-center rounded-lg bg-white">
                <GoogleIcon className="size-5" />
              </div>
              <div className="flex-1 text-start">
                <div className="text-sm font-bold text-amber-100">{t("continueWithGoogle")}</div>
                <div className="text-xs text-amber-200/60">{t("linkGoogleDesc")}</div>
              </div>
              <ChevronRight className="size-4 text-stone-400" style={{ transform: isRTL ? "scaleX(-1)" : "" }} />
            </button>
            <button onClick={skipAll} className="text-center text-xs text-stone-500 hover:text-stone-400">
              {t("skip")}
            </button>
          </div>
        )}

        {step === "intro" && (
          <div className="flex flex-col items-center gap-4 py-4 text-center">
            <div className="flex size-20 items-center justify-center rounded-full bg-gradient-to-br from-orange-600 to-amber-800 shadow-lg">
              <PickaxeIcon className="size-10 text-amber-100" />
            </div>
            <h3 className="text-xl font-bold text-amber-100">{t("welcomeTitle")}</h3>
            <div className="space-y-3 text-start">
              <FeatureRow icon={<PickaxeIcon className="size-5 text-orange-400" />} title={t("production")} desc={t("helpMiningDesc")} />
              <FeatureRow icon={<ArrowUpDown className="size-5 text-sky-400" />} title={t("elevator")} desc={t("helpManagersDesc")} />
              <FeatureRow icon={<Truck className="size-5 text-emerald-400" />} title={t("cart")} desc={t("helpUpgradesDesc")} />
            </div>
            <Button
              className="w-full bg-amber-600 text-stone-950 hover:bg-amber-500"
              size="lg"
              onClick={() => setStep("tutorial")}
            >
              {t("next")} <ChevronRight className="size-4" style={{ transform: isRTL ? "scaleX(-1)" : "" }} />
            </Button>
            <button onClick={finish} className="text-xs text-stone-500 hover:text-stone-400">
              {t("skipTutorial")}
            </button>
          </div>
        )}

        {step === "tutorial" && (
          <div className="flex flex-col gap-4 py-4">
            <h3 className="text-center text-lg font-bold text-amber-100">{t("tutorialTitle")}</h3>
            <div className="space-y-3">
              <TutorialStep num={1} text={t("tutorial1")} />
              <TutorialStep num={2} text={t("tutorial2")} />
              <TutorialStep num={3} text={t("tutorial3")} />
              <TutorialStep num={4} text={t("tutorial4")} />
            </div>
            <Button
              className="w-full bg-amber-600 text-stone-950 hover:bg-amber-500"
              size="lg"
              onClick={finish}
            >
              {t("getStarted")}
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

function FeatureRow({ icon, title, desc }: { icon: React.ReactNode; title: string; desc: string }) {
  return (
    <div className="flex gap-3 rounded-lg border border-stone-700/50 bg-stone-800/30 p-3">
      <div className="mt-0.5 shrink-0">{icon}</div>
      <div className="min-w-0 flex-1">
        <div className="text-xs font-bold text-amber-200">{title}</div>
        <div className="mt-0.5 line-clamp-2 text-[10px] text-amber-200/50">{desc}</div>
      </div>
    </div>
  );
}

function TutorialStep({ num, text }: { num: number; text: string }) {
  return (
    <div className="flex items-center gap-3 rounded-lg border border-amber-900/30 bg-stone-800/40 p-3">
      <div className="flex size-7 shrink-0 items-center justify-center rounded-full bg-amber-600 text-xs font-bold text-stone-950">
        {num}
      </div>
      <div className="flex-1 text-xs text-amber-100">{text}</div>
    </div>
  );
}

function GoogleIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden>
      <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
      <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
      <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
      <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
    </svg>
  );
}
