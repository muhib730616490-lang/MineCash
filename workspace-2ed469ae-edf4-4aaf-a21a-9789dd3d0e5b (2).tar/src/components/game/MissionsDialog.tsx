"use client";
import { PanelDialog } from "./PanelDialog";
import { Button } from "@/components/ui/button";
import { useMetaStore } from "@/store/metaStore";
import { useGameStore } from "@/store/gameStore";
import { useT } from "@/game/useT";
import { formatNumber } from "@/lib/format";
import { CoinIcon, GemIcon } from "./icons";
import { Target, Check, Gift } from "lucide-react";
import { toast } from "sonner";

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
}

export function MissionsDialog({ open, onOpenChange }: Props) {
  const t = useT();
  const missions = useMetaStore((s) => s.missions);
  const claimMission = useMetaStore((s) => s.claimMission);
  const grantReward = useGameStore((s) => s.grantReward);

  const handleClaim = (missionId: string) => {
    const reward = claimMission(missionId);
    if (reward) {
      grantReward(reward.coins, reward.gems);
      toast.success(`+${formatNumber(reward.coins)} coins, +${reward.gems} gems!`, {
        description: t("missions") + " " + t("claim"),
      });
    }
  };

  const completedCount = missions.filter((m) => m.completed).length;

  return (
    <PanelDialog
      open={open}
      onOpenChange={onOpenChange}
      title={t("dailyMissions")}
      icon={<Target className="size-5" />}
      description={`${completedCount}/${missions.length} ${t("completed" as string) || "completed"} · ${t("missionsDesc")}`}
    >
      {missions.length === 0 ? (
        <div className="rounded-lg border border-stone-700/50 bg-stone-800/30 p-4 text-center text-xs text-stone-400">
          {t("noMissions")}
        </div>
      ) : (
        <div className="space-y-2">
          {missions.map((m) => {
            const pct = Math.min(100, (m.progress / m.target) * 100);
            return (
              <div
                key={m.id}
                className={[
                  "rounded-xl border p-3 transition",
                  m.claimed
                    ? "border-stone-700/50 bg-stone-800/20 opacity-60"
                    : m.completed
                      ? "border-emerald-600/50 bg-emerald-900/20"
                      : "border-amber-900/40 bg-stone-800/40",
                ].join(" ")}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <div className="text-xs font-bold text-amber-100">{m.description}</div>
                    <div className="mt-1 text-[10px] text-stone-400">
                      {formatNumber(m.progress)} / {formatNumber(m.target)}
                    </div>
                  </div>
                  <div className="flex shrink-0 items-center gap-1">
                    <span className="flex items-center gap-0.5 rounded bg-amber-900/40 px-1.5 py-0.5 text-[9px] font-bold text-amber-300">
                      <CoinIcon className="size-2.5" />
                      {formatNumber(m.rewardCoins)}
                    </span>
                    {m.rewardGems > 0 && (
                      <span className="flex items-center gap-0.5 rounded bg-teal-900/40 px-1.5 py-0.5 text-[9px] font-bold text-teal-300">
                        <GemIcon className="size-2.5" />
                        {m.rewardGems}
                      </span>
                    )}
                  </div>
                </div>
                {/* progress bar */}
                <div className="mt-2 h-2 overflow-hidden rounded-full bg-stone-900">
                  <div
                    className={[
                      "h-full transition-all",
                      m.completed ? "bg-emerald-500" : "bg-gradient-to-r from-amber-500 to-amber-400",
                    ].join(" ")}
                    style={{ width: `${pct}%` }}
                  />
                </div>
                {/* claim button */}
                {m.completed && !m.claimed && (
                  <Button
                    className="mt-2 w-full bg-emerald-600 text-white hover:bg-emerald-500"
                    size="sm"
                    onClick={() => handleClaim(m.id)}
                  >
                    <Gift className="size-3" />
                    {t("claim")}
                  </Button>
                )}
                {m.claimed && (
                  <div className="mt-2 flex items-center justify-center gap-1 text-[10px] font-bold text-stone-500">
                    <Check className="size-3" /> {t("rewardClaimed")}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </PanelDialog>
  );
}
