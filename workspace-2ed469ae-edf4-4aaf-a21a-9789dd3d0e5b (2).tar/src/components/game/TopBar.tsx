"use client";
import { useState } from "react";
import { useGameStore } from "@/store/gameStore";
import { useMetaStore } from "@/store/metaStore";
import { useT } from "@/game/useT";
import { getMineConfig, MINES, FLOOR_COUNT } from "@/game/config";
import { formatNumber } from "@/lib/format";
import { CoinIcon, GemIcon } from "./icons";
import { SettingsDialog } from "./SettingsDialog";
import { RewardedAdDialog } from "./RewardedAdDialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { LANGUAGES } from "@/game/i18n";
import { Settings2, Globe, Lock, Tv, Zap, Clock } from "lucide-react";
import type { MineId, Language } from "@/game/types";
import { useEffect, useState as useReactState } from "react";
import { toast } from "sonner";

export function TopBar({ onOpenHelp, onOpenAdmin }: { onOpenHelp: () => void; onOpenAdmin: () => void }) {
  const t = useT();
  const coins = useGameStore((s) => s.coins);
  const gems = useGameStore((s) => s.gems);
  const activeMine = useGameStore((s) => s.activeMine);
  const mines = useGameStore((s) => s.mines);
  const setActiveMine = useGameStore((s) => s.setActiveMine);
  const setGameLanguage = useGameStore((s) => s.setLanguage);
  const metaLanguage = useMetaStore((s) => s.settings.language);
  const setMetaLanguage = useMetaStore((s) => s.setLanguage);
  const canWatchAd = useGameStore((s) => s.canWatchAd);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [adOpen, setAdOpen] = useState(false);
  const [mineBadgeTaps, setMineBadgeTaps] = useState(0);

  // Secret admin access: tap mine badge 5 times rapidly
  const handleMineBadgeTap = () => {
    const newTaps = mineBadgeTaps + 1;
    setMineBadgeTaps(newTaps);
    if (newTaps >= 5) {
      setMineBadgeTaps(0);
      onOpenAdmin();
    }
    setTimeout(() => setMineBadgeTaps(0), 1500);
  };

  const language = metaLanguage;
  const setLanguage = (l: Language) => { setMetaLanguage(l); setGameLanguage(l); };

  const cfg = getMineConfig(activeMine);

  // Boost countdown
  const boostUntil = useGameStore((s) => s.boostUntil);
  const [now, setNow] = useReactState(Date.now());
  useEffect(() => {
    if (boostUntil <= now) return;
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, [boostUntil, now]);
  const boostActive = boostUntil > now;
  const boostSeconds = Math.max(0, Math.ceil((boostUntil - now) / 1000));

  const handleTabClick = (id: MineId) => {
    const mr = mines[id];
    if (mr && mr.unlocked) {
      setActiveMine(id);
    }
    // Locked mines unlock automatically when previous mine is completed (floor 20 unlocked).
    // No gem cost — progression-based.
  };

  // Check which mines are unlocked via progression
  const copperComplete = mines.copper.floors[FLOOR_COUNT - 1]?.unlocked ?? false;
  const goldComplete = mines.gold.floors[FLOOR_COUNT - 1]?.unlocked ?? false;

  return (
    <header className="sticky top-0 z-30 border-b-2 border-amber-950/70 bg-gradient-to-b from-stone-900 via-stone-900 to-stone-950 shadow-[0_4px_18px_rgba(0,0,0,0.5)]">
      <div className="mx-auto flex max-w-5xl items-center gap-2 px-2 py-2 sm:px-3">
        {/* Mine badge — tap 5× rapidly for admin access */}
        <div className="flex min-w-0 items-center gap-2">
          <button
            onClick={handleMineBadgeTap}
            className="flex size-9 shrink-0 items-center justify-center rounded-lg text-lg shadow-inner ring-1 ring-black/40 transition active:scale-95 sm:size-10"
            style={{ background: `linear-gradient(135deg, ${cfg.accent}, ${cfg.rockTintDark})` }}
            aria-label={cfg.name}
          >
            <span className="drop-shadow">{cfg.icon}</span>
          </button>
          <div className="hidden min-w-0 sm:block">
            <div className="truncate text-[11px] font-semibold uppercase tracking-wider text-amber-300/70">
              {t("mine")}
            </div>
            <div className="truncate text-sm font-bold leading-tight text-amber-50">
              {cfg.name}
            </div>
          </div>
        </div>

        {/* Boost indicator */}
        {boostActive && (
          <div className="flex items-center gap-1 rounded-full border border-fuchsia-400/50 bg-fuchsia-900/40 px-2 py-1 text-[10px] font-bold text-fuchsia-200 shadow-md">
            <Zap className="size-3 animate-pulse" />
            2×
            <Clock className="size-2.5" />
            {Math.floor(boostSeconds / 60)}:{(boostSeconds % 60).toString().padStart(2, "0")}
          </div>
        )}

        <div className="flex-1" />

        {/* Currencies */}
        <div className="flex items-center gap-1.5">
          <CurrencyPill
            icon={<CoinIcon className="size-4" />}
            value={coins}
            className="from-amber-500 to-amber-700 ring-amber-300/30"
          />
          <CurrencyPill
            icon={<GemIcon className="size-4" />}
            value={gems}
            className="from-teal-500 to-emerald-700 ring-teal-300/30"
          />
        </div>

        {/* Rewarded Ad button */}
        <button
          aria-label={t("watchAd")}
          onClick={() => setAdOpen(true)}
          className={[
            "flex size-9 items-center justify-center rounded-lg border transition active:scale-95",
            canWatchAd()
              ? "border-fuchsia-500/50 bg-fuchsia-800/70 text-fuchsia-200 hover:bg-fuchsia-700/70"
              : "border-stone-700 bg-stone-800/50 text-stone-500",
          ].join(" ")}
        >
          <Tv className="size-4" />
        </button>

        {/* Language */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button
              aria-label={t("language")}
              className="flex size-9 items-center justify-center rounded-lg border border-amber-900/40 bg-stone-800/70 text-amber-200 transition hover:bg-stone-700/70 active:scale-95"
            >
              <Globe className="size-4" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent
            align="end"
            className="border-amber-900/40 bg-stone-900 text-amber-50"
          >
            {LANGUAGES.map((l) => (
              <DropdownMenuItem
                key={l.id}
                onClick={() => setLanguage(l.id)}
                className={`cursor-pointer gap-2 text-sm ${
                  language === l.id ? "bg-amber-900/40 text-amber-200" : ""
                }`}
              >
                <span className="text-base">{l.flag}</span>
                {l.nativeLabel}
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Settings */}
        <button
          aria-label={t("settings")}
          onClick={() => setSettingsOpen(true)}
          className="flex size-9 items-center justify-center rounded-lg border border-amber-900/40 bg-stone-800/70 text-amber-200 transition hover:bg-stone-700/70 active:scale-95"
        >
          <Settings2 className="size-4" />
        </button>
      </div>

      {/* Mine tabs */}
      <div className="no-scrollbar mx-auto flex max-w-5xl gap-1.5 overflow-x-auto px-2 pb-2 sm:px-3">
        {MINES.map((m) => {
          const unlocked = mines[m.id].unlocked;
          const active = activeMine === m.id;
          // Progression-based unlock hints
          const progressionReady =
            (m.id === "gold" && copperComplete && !unlocked) ||
            (m.id === "rawGold" && goldComplete && !unlocked);
          return (
            <button
              key={m.id}
              onClick={() => handleTabClick(m.id)}
              disabled={!unlocked && !progressionReady}
              className={[
                "group relative flex min-w-[7.5rem] flex-1 items-center justify-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-semibold transition active:scale-[0.98] sm:text-sm",
                active
                  ? "border-transparent text-stone-950 shadow-md"
                  : unlocked
                    ? "border-amber-900/40 bg-stone-800/60 text-amber-100 hover:bg-stone-700/60"
                    : progressionReady
                      ? "border-emerald-600/50 bg-emerald-900/40 text-emerald-200 hover:bg-emerald-800/40"
                      : "border-stone-700/50 bg-stone-900/40 text-stone-500",
              ].join(" ")}
              style={
                active
                  ? { background: `linear-gradient(135deg, ${m.accent}, ${m.rockTintDark})` }
                  : undefined
              }
            >
              <span className="text-sm">{m.icon}</span>
              <span className="truncate">{m.shortName}</span>
              {!unlocked && !progressionReady && (
                <Lock className="size-3 text-stone-500" />
              )}
              {progressionReady && (
                <span className="rounded-full bg-emerald-600 px-1.5 py-0.5 text-[9px] font-bold text-white">
                  NEW
                </span>
              )}
            </button>
          );
        })}
        {/* Coming Soon tab */}
        <button
          onClick={() => toast.info(t("moreMinesSoon"))}
          className="flex min-w-[7.5rem] flex-1 cursor-pointer items-center justify-center gap-1.5 rounded-lg border border-stone-800/50 bg-stone-950/40 px-3 py-1.5 text-xs font-semibold text-stone-600 transition hover:bg-stone-900/60 hover:text-stone-500 sm:text-sm"
        >
          <Lock className="size-3" />
          <span className="truncate">{t("comingSoon")}</span>
        </button>
      </div>

      <SettingsDialog open={settingsOpen} onOpenChange={setSettingsOpen} onOpenHelp={onOpenHelp} />
      <RewardedAdDialog open={adOpen} onOpenChange={setAdOpen} />
    </header>
  );
}

function CurrencyPill({
  icon,
  value,
  className,
}: {
  icon: React.ReactNode;
  value: number;
  className?: string;
}) {
  return (
    <div
      className={`flex items-center gap-1 rounded-full bg-gradient-to-b px-2.5 py-1 text-xs font-bold text-white shadow-md ring-1 ring-inset sm:text-sm ${className}`}
    >
      {icon}
      <span className="tabular-nums">{formatNumber(value)}</span>
    </div>
  );
}
