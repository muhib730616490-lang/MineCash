"use client";
import { useGameStore } from "@/store/gameStore";
import { useActiveMineConfig } from "@/game/useMine";
import { Floor } from "./Floor";
import type { MineConfig } from "@/game/config";

/** The underground: a single elevator shaft column + 20 stacked floors. */
export function MineShaft() {
  const cfg = useActiveMineConfig();
  const floors = useGameStore((s) => s.mines[s.activeMine].floors);
  const coins = useGameStore((s) => s.coins);

  return (
    <div className="relative w-full" style={{ paddingLeft: "var(--imt-shaft-w)" }}>
      {/* elevator shaft column */}
      <div
        className="absolute left-0 top-0 z-10 overflow-hidden"
        style={{ width: "var(--imt-shaft-w)", height: "100%" }}
      >
        <ShaftColumn cfg={cfg} floorCount={floors.length} />
      </div>

      {/* floors */}
      <div className="relative">
        {floors.map((f, i) => (
          <Floor
            key={f.id}
            floor={f}
            coins={coins}
            prevUnlocked={f.id === 1 || !!floors[i - 1]?.unlocked}
            cfg={cfg}
          />
        ))}
      </div>
    </div>
  );
}

function ShaftColumn({ cfg, floorCount }: { cfg: MineConfig; floorCount: number }) {
  return (
    <div
      className="relative h-full w-full"
      style={{
        background: `linear-gradient(90deg, #1a0f08 0%, ${cfg.rockTintDark} 45%, #120a05 100%)`,
      }}
    >
      {/* ore-glow vertical light */}
      <div
        className="absolute left-1/2 top-0 h-full w-2/3 -translate-x-1/2 opacity-40"
        style={{ background: `linear-gradient(180deg, transparent, ${cfg.oreGlow}22, transparent)` }}
      />
      {/* metal rails */}
      <div className="absolute left-[22%] top-0 h-full w-[3px] bg-gradient-to-b from-slate-400/70 to-slate-600/40" />
      <div className="absolute right-[22%] top-0 h-full w-[3px] bg-gradient-to-b from-slate-400/70 to-slate-600/40" />
      {/* cross-ties every floor */}
      {Array.from({ length: floorCount }).map((_, i) => (
        <div
          key={i}
          className="absolute left-[18%] right-[18%] h-[2px] bg-stone-700/60"
          style={{ top: `calc(${i + 1} * var(--imt-floor-h) - 2px)` }}
        />
      ))}
      {/* depth markers every 5 floors */}
      {Array.from({ length: Math.floor(floorCount / 5) }).map((_, i) => {
        const n = (i + 1) * 5;
        return (
          <div
            key={`d${n}`}
            className="absolute left-1/2 -translate-x-1/2 rounded bg-stone-900/80 px-1 py-0.5 text-[8px] font-bold text-amber-300/80 shadow"
            style={{ top: `calc(${n - 1} * var(--imt-floor-h) + var(--imt-floor-h) / 2 - 8px)` }}
          >
            {n}m
          </div>
        );
      })}
      {/* top dock cap */}
      <div className="absolute left-0 right-0 top-0 h-3 bg-gradient-to-b from-stone-700 to-stone-900 shadow-md" />
    </div>
  );
}
