"use client";
import { Surface } from "./Surface";
import { MineShaft } from "./MineShaft";
import { Elevator } from "./Elevator";

/** The full vertical world: surface on top, the mine below, the elevator spanning both. */
export function Scene() {
  // Sizing variables set inline (responsive via Tailwind breakpoints is unreliable
  // for custom-property-only rules, so we fix them here; they cascade to all children).
  return (
    <div
      className="relative w-full"
      style={
        {
          "--imt-surf-h": "336px",
          "--imt-floor-h": "140px",
          "--imt-shaft-w": "70px",
        } as React.CSSProperties
      }
    >
      <Surface />
      <MineShaft />
      <Elevator />
    </div>
  );
}
