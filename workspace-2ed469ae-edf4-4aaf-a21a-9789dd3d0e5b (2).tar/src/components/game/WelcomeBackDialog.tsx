"use client";
import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useMetaStore } from "@/store/metaStore";
import { useGameStore } from "@/store/gameStore";
import { useT } from "@/game/useT";
import { formatNumber } from "@/lib/format";
import { formatTime } from "@/lib/format";
import { Tv, Clock, Sparkles, Check } from "lucide-react";
import { CoinIcon } from "./icons";
import { toast } from "sonner";

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
}

/** Welcome Back popup shown when the player returns after being away.
 * Shows time away + offline earnings with Claim (1x) and Claim 2X (ad) buttons. */
export function WelcomeBackDialog({ open, onOpenChange }: Props) {
  const t = useT();
  const offlineEarnings = useMetaStore((s) => s.profile.offlineEarnings);
  const offlineSecondsAway = useMetaStore((s) => s.profile.offlineSecondsAway);
  const claimOfflineEarnings = useMetaStore((s) => s.claimOfflineEarnings);
  const claimOfflineEarnings2x = useMetaStore((s) => s.claimOfflineEarnings2x);
  const grantReward = useGameStore((s) => s.grantReward);
  const grantCoins = useGameStore((s) => s.grantCoins);
  const [adPlaying, setAdPlaying] = useState(false);
  const [adCountdown, setAdCountdown] = useState(0);

  const handleClaim = () => {
    const amount = claimOfflineEarnings();
    if (amount > 0) {
      grantCoins(amount);
      toast.success(`+${formatNumber(amount)} coins!`, {
        description: "Offline earnings collected",
      });
    }
    onOpenChange(false);
  };

  const handleClaim2x = () => {
    // Simulate a 5-second ad
    setAdPlaying(true);
    setAdCountdown(5);
    const timer = setInterval(() => {
      setAdCountdown((c) => {
        if (c <= 1) {
          clearInterval(timer);
          setAdPlaying(false);
          const amount = claimOfflineEarnings2x();
          if (amount > 0) {
            grantCoins(amount);
            toast.success(`+${formatNumber(amount)} coins! (2×)`, {
              description: "Offline earnings doubled!",
            });
          }
          onOpenChange(false);
          return 0;
        }
        return c - 1;
      });
    }, 1000);
  };

  const timeAway = formatTime(offlineSecondsAway);
  const hasEarnings = offlineEarnings > 0;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="border-amber-900/50 bg-gradient-to-b from-stone-900 to-stone-950 text-amber-50 sm:max-w-md" showCloseButton={false}>
        <DialogTitle className="sr-only">Welcome Back</DialogTitle>
        <DialogDescription className="sr-only">Offline earnings report</DialogDescription>

        {adPlaying ? (
          /* Ad simulation overlay */
          <div className="flex flex-col items-center gap-4 py-8">
            <Tv className="size-12 text-amber-300/70" />
            <div className="text-sm font-bold text-amber-200">{t("adPlaying")}</div>
            <div className="flex items-center gap-1.5 rounded-full bg-stone-800 px-3 py-1 text-lg font-bold text-amber-300">
              {adCountdown}s
            </div>
            <div className="h-1.5 w-32 overflow-hidden rounded-full bg-stone-700">
              <div
                className="h-full bg-amber-500 transition-all duration-1000 ease-linear"
                style={{ width: `${((5 - adCountdown) / 5) * 100}%` }}
              />
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-4 py-4 text-center">
            {/* Sparkle icon */}
            <div className="relative flex size-16 items-center justify-center rounded-full bg-gradient-to-br from-amber-500 to-orange-600 shadow-lg">
              <Sparkles className="size-8 text-amber-50" />
              <div className="absolute -right-1 -top-1 flex size-5 items-center justify-center rounded-full bg-amber-400 text-stone-950">
                <Check className="size-3" />
              </div>
            </div>

            <div>
              <h2 className="text-xl font-extrabold text-amber-200">Welcome Back!</h2>
              <p className="mt-1 text-xs text-amber-200/60">Your mine kept working while you were away</p>
            </div>

            {/* Time away */}
            <div className="flex items-center gap-2 rounded-full border border-amber-700/40 bg-stone-800/60 px-4 py-1.5">
              <Clock className="size-3.5 text-amber-400" />
              <span className="text-xs font-bold text-amber-200">
                {timeAway} away
              </span>
            </div>

            {/* Coins earned */}
            <div className="w-full rounded-xl border border-amber-600/40 bg-gradient-to-br from-amber-900/30 to-stone-900 p-4">
              <div className="text-[10px] uppercase tracking-wider text-amber-300/70">Coins Earned Offline</div>
              <div className="mt-1 flex items-center justify-center gap-2">
                <CoinIcon className="size-7" />
                <span className="text-3xl font-extrabold text-amber-200">{formatNumber(offlineEarnings)}</span>
              </div>
            </div>

            {/* Claim buttons */}
            <div className="flex w-full gap-2">
              <Button
                className="flex-1 bg-amber-600 text-stone-950 hover:bg-amber-500"
                size="lg"
                onClick={handleClaim}
                disabled={!hasEarnings}
              >
                <CoinIcon className="size-4" />
                Claim
              </Button>
              <Button
                className="flex-1 bg-gradient-to-r from-fuchsia-600 to-purple-700 text-white hover:from-fuchsia-500 hover:to-purple-600"
                size="lg"
                onClick={handleClaim2x}
                disabled={!hasEarnings}
              >
                <Tv className="size-4" />
                Claim 2×
              </Button>
            </div>

            {!hasEarnings && (
              <p className="text-[10px] text-stone-500">
                No offline earnings this time. Stay longer for more!
              </p>
            )}
            <p className="text-[10px] text-stone-500">
              Watching an ad is optional — you can always claim the normal reward.
            </p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
