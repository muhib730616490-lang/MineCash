"use client";
import { useMetaStore } from "@/store/metaStore";
import { useT } from "@/game/useT";
import { User, Target, Gift, Share2, HelpCircle, Trophy, Wallet, Lock } from "lucide-react";

interface Props {
  onOpenProfile: () => void;
  onOpenMissions: () => void;
  onOpenDaily: () => void;
  onOpenReferral: () => void;
  onOpenAchievements: () => void;
  onOpenHelp: () => void;
  onOpenWallet: () => void;
}

/** Bottom navigation dock for meta-system panels. */
export function BottomDock({
  onOpenProfile,
  onOpenMissions,
  onOpenDaily,
  onOpenReferral,
  onOpenAchievements,
  onOpenHelp,
  onOpenWallet,
}: Props) {
  const t = useT();
  const pendingRewards = useMetaStore((s) => s.referral.pendingRewards);
  const canClaimDaily = useMetaStore((s) => s.canClaimDaily());
  const missions = useMetaStore((s) => s.missions);
  const claimableMissions = missions.filter((m) => m.completed && !m.claimed).length;
  const achievements = useMetaStore((s) => s.achievements);
  const claimableAchievements = achievements.filter((a) => a.unlocked && !a.claimed).length;
  const walletUnlocked = useMetaStore((s) => s.profile.walletUnlocked);

  return (
    <nav className="no-scrollbar mx-auto flex max-w-md items-center justify-around gap-1 overflow-x-auto border-t-2 border-amber-950/70 bg-gradient-to-t from-stone-950 to-stone-900 px-1 py-1.5 shadow-[0_-4px_18px_rgba(0,0,0,0.5)]">
      <DockBtn icon={<User className="size-4" />} label={t("profile")} onClick={onOpenProfile} />
      <DockBtn icon={<Target className="size-4" />} label={t("missions")} onClick={onOpenMissions} badge={claimableMissions > 0 ? claimableMissions : undefined} />
      <DockBtn icon={<Gift className="size-4" />} label={t("dailyReward")} onClick={onOpenDaily} badge={canClaimDaily ? "!" : undefined} highlight={canClaimDaily} />
      <DockBtn icon={walletUnlocked ? <Wallet className="size-4" /> : <Lock className="size-4" />} label="Wallet" onClick={onOpenWallet} />
      <DockBtn icon={<Trophy className="size-4" />} label={t("achievements")} onClick={onOpenAchievements} badge={claimableAchievements > 0 ? claimableAchievements : undefined} />
      <DockBtn icon={<Share2 className="size-4" />} label={t("referral")} onClick={onOpenReferral} badge={pendingRewards > 0 ? pendingRewards : undefined} />
      <DockBtn icon={<HelpCircle className="size-4" />} label={t("help")} onClick={onOpenHelp} />
    </nav>
  );
}

function DockBtn({
  icon,
  label,
  onClick,
  badge,
  highlight,
}: {
  icon: React.ReactNode;
  label: string;
  onClick: () => void;
  badge?: number | string;
  highlight?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={[
        "relative flex flex-1 flex-col items-center gap-0.5 rounded-xl px-1 py-2 min-h-[48px] transition active:scale-95",
        highlight
          ? "bg-amber-900/40 text-amber-200"
          : "text-amber-200/70 hover:bg-stone-800/60 hover:text-amber-100",
      ].join(" ")}
    >
      <div className="relative">
        {icon}
        {badge !== undefined && (
          <span className="absolute -right-2 -top-2 flex size-4 min-w-4 items-center justify-center rounded-full bg-red-500 px-0.5 text-[9px] font-bold text-white">
            {badge}
          </span>
        )}
      </div>
      <span className="text-[9px] font-medium leading-none">{label}</span>
    </button>
  );
}
