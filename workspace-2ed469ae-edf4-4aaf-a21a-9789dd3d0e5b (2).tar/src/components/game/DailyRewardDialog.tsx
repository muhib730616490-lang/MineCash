"use client";
import { PanelDialog } from "./PanelDialog";
import { Button } from "@/components/ui/button";
import { useMetaStore } from "@/store/metaStore";
import { useGameStore } from "@/store/gameStore";
import { useT } from "@/game/useT";
import { formatNumber } from "@/lib/format";
import { CoinIcon, GemIcon } from "./icons";
import { Gift, Flame, Check } from "lucide-react";
import { toast } from "sonner";
import {
  DAILY_REWARD_DAYS,
  DAILY_REWARDS,
  dateKey,
  daysBetween,
} from "@/game/config";

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
}

export function DailyRewardDialog({ open, onOpenChange }: Props) {
  const t = useT();
  const daily = useMetaStore((s) => s.dailyReward);
  const canClaimDaily = useMetaStore((s) => s.canClaimDaily);
  const claimDailyReward = useMetaStore((s) => s.claimDailyReward);
  const grantReward = useGameStore((s) => s.grantReward);

  const today = dateKey(Date.now());
  const claimedToday = daily.lastClaimDate === today;
  const canClaim = canClaimDaily();

  // Determine which day would be claimed next
  let nextDay = 1;
  if (daily.lastClaimDate !== "") {
    const gap = daysBetween(daily.lastClaimDate, today);
    if (gap === 1) {
      nextDay = Math.min(daily.streak + 1, DAILY_REWARD_DAYS);
    } else {
      nextDay = 1;
    }
  }

  const handleClaim = () => {
    const reward = claimDailyReward();
    if (reward) {
      grantReward(reward.coins, reward.gems);
      toast.success(`+${formatNumber(reward.coins)} coins, +${reward.gems} gems!`, {
        description: t("dailyReward") + " " + t("claim"),
      });
    }
  };

  return (
    <PanelDialog
      open={open}
      onOpenChange={onOpenChange}
      title={t("dailyReward")}
      icon={<Gift className="size-5" />}
      description={t("dailyRewardDesc")}
    >
      {/* Streak indicator */}
      <div className="flex items-center justify-center gap-2 rounded-xl border border-orange-700/40 bg-orange-900/20 p-3">
        <Flame className="size-5 text-orange-400" />
        <span className="text-sm font-bold text-orange-300">
          {t("streak")}: {daily.streak}/{DAILY_REWARD_DAYS}
        </span>
      </div>

      {/* 7-day grid */}
      <div className="grid grid-cols-4 gap-2">
        {DAILY_REWARDS.map((reward, i) => {
          const dayNum = i + 1;
          const isClaimed = daily.streak >= dayNum;
          const isNext = !isClaimed && dayNum === nextDay && canClaim;
          const isLast = i === DAILY_REWARDS.length - 1;
          return (
            <div
              key={i}
              className={[
                "relative flex flex-col items-center gap-1 rounded-lg border-2 p-2 transition",
                isLast ? "col-span-2" : "",
                isClaimed
                  ? "border-emerald-600/50 bg-emerald-900/20"
                  : isNext
                    ? "border-amber-400 bg-amber-900/30 imt-glow-pulse"
                    : "border-stone-700/50 bg-stone-800/30",
              ].join(" ")}
            >
              <div className="text-[9px] font-bold text-stone-400">{t("day")} {dayNum}</div>
              <div className="flex items-center gap-0.5">
                <CoinIcon className="size-3" />
                <span className="text-[10px] font-bold text-amber-300">{formatNumber(reward.coins)}</span>
              </div>
              {reward.gems > 0 && (
                <div className="flex items-center gap-0.5">
                  <GemIcon className="size-2.5" />
                  <span className="text-[9px] font-bold text-teal-300">{reward.gems}</span>
                </div>
              )}
              {isClaimed && (
                <div className="absolute -right-1 -top-1 flex size-4 items-center justify-center rounded-full bg-emerald-500 text-white">
                  <Check className="size-2.5" />
                </div>
              )}
              {isLast && (
                <div className="absolute -top-2 left-1/2 -translate-x-1/2 rounded-full bg-gradient-to-r from-amber-500 to-orange-500 px-2 py-0.5 text-[8px] font-bold text-white">
                  JACKPOT
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Claim button */}
      {canClaim ? (
        <Button
          className="w-full bg-gradient-to-r from-amber-600 to-orange-600 text-stone-950 hover:from-amber-500 hover:to-orange-500"
          size="lg"
          onClick={handleClaim}
        >
          <Gift className="size-4" />
          {t("claim")} {t("day")} {nextDay}
        </Button>
      ) : (
        <div className="rounded-lg border border-stone-700/50 bg-stone-800/40 p-3 text-center text-sm font-medium text-stone-400">
          {claimedToday ? t("alreadyClaimed") : t("comeBackTomorrow")}
        </div>
      )}
    </PanelDialog>
  );
}
