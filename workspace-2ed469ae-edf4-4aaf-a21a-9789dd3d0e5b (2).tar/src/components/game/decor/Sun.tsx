import React from 'react'

interface DecorProps {
  className?: string
}

/**
 * Warm glowing sun with a soft pulsing halo and slowly rotating rays.
 * Purely presentational — the parent positions this component.
 */
export function Sun(props: DecorProps) {
  const rays = Array.from({ length: 12 }, (_, i) => {
    const angle = (i * 360) / 12
    const opacity = i % 2 === 0 ? 0.9 : 0.55
    return (
      <rect
        key={i}
        x="58.5"
        y="12"
        width="3"
        height="18"
        rx="1.5"
        fill="#FFD24A"
        opacity={opacity}
        transform={`rotate(${angle} 60 60)`}
      />
    )
  })

  return (
    <svg
      viewBox="0 0 120 120"
      width="100%"
      height="100%"
      preserveAspectRatio="xMidYMid meet"
      shapeRendering="geometricPrecision"
      className={props.className}
      aria-hidden="true"
    >
      <defs>
        <radialGradient id="sun-glow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#FFE9A8" stopOpacity="0.55" />
          <stop offset="55%" stopColor="#FFD66B" stopOpacity="0.18" />
          <stop offset="100%" stopColor="#FFC542" stopOpacity="0" />
        </radialGradient>
        <radialGradient id="sun-halo" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#FFE9A8" stopOpacity="0.95" />
          <stop offset="45%" stopColor="#FFD24A" stopOpacity="0.45" />
          <stop offset="100%" stopColor="#FFC542" stopOpacity="0" />
        </radialGradient>
        <radialGradient id="sun-body" cx="38%" cy="34%" r="68%">
          <stop offset="0%" stopColor="#FFF6D2" />
          <stop offset="55%" stopColor="#FFD24A" />
          <stop offset="100%" stopColor="#F5961F" />
        </radialGradient>
        <radialGradient id="sun-sheen" cx="40%" cy="32%" r="60%">
          <stop offset="0%" stopColor="#FFFFFF" stopOpacity="0.85" />
          <stop offset="100%" stopColor="#FFFFFF" stopOpacity="0" />
        </radialGradient>
      </defs>

      <style>{`
        .sun-glow-static { transform-box: fill-box; transform-origin: 50% 50%; }
        .sun-halo-pulse {
          transform-box: fill-box;
          transform-origin: 50% 50%;
          animation: sun-pulse 5s ease-in-out infinite;
        }
        .sun-rays-spin {
          transform-box: fill-box;
          transform-origin: 50% 50%;
          animation: sun-spin 60s linear infinite;
        }
        @keyframes sun-pulse {
          0%, 100% { transform: scale(1); opacity: 0.92; }
          50%      { transform: scale(1.09); opacity: 1; }
        }
        @keyframes sun-spin {
          from { transform: rotate(0deg); }
          to   { transform: rotate(360deg); }
        }
        @media (prefers-reduced-motion: reduce) {
          .sun-halo-pulse, .sun-rays-spin { animation: none !important; }
        }
      `}</style>

      {/* Outer soft glow (static) */}
      <circle className="sun-glow-static" cx="60" cy="60" r="58" fill="url(#sun-glow)" />

      {/* Pulsing halo */}
      <circle className="sun-halo-pulse" cx="60" cy="60" r="46" fill="url(#sun-halo)" />

      {/* Rotating rays */}
      <g className="sun-rays-spin">{rays}</g>

      {/* Sun body */}
      <circle cx="60" cy="60" r="30" fill="url(#sun-body)" />

      {/* Sheen highlight */}
      <ellipse cx="50" cy="48" rx="16" ry="10" fill="url(#sun-sheen)" />
    </svg>
  )
}

export default Sun
