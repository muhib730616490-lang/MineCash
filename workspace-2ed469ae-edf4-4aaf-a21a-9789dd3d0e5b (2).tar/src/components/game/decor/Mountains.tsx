import React from 'react'

interface DecorProps {
  className?: string
}

/**
 * Layered mountain silhouettes for parallax depth: distant atmospheric
 * haze layer, mid sage-green layer with snow caps, and a darker front layer.
 * Earthy green/teal palette. Slight haze shimmer on the back layer.
 */
export function Mountains(props: DecorProps) {
  return (
    <svg
      viewBox="0 0 1200 320"
      width="100%"
      height="auto"
      preserveAspectRatio="xMidYMax slice"
      shapeRendering="geometricPrecision"
      className={props.className}
      aria-hidden="true"
    >
      <defs>
        <linearGradient id="mtn-back" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#B7C4D2" />
          <stop offset="100%" stopColor="#9CB1C2" />
        </linearGradient>
        <linearGradient id="mtn-back-haze" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#D6E2EA" stopOpacity="0.6" />
          <stop offset="100%" stopColor="#D6E2EA" stopOpacity="0" />
        </linearGradient>
        <linearGradient id="mtn-mid" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#6FA38C" />
          <stop offset="100%" stopColor="#4F8472" />
        </linearGradient>
        <linearGradient id="mtn-front" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#3E7C66" />
          <stop offset="100%" stopColor="#2A5847" />
        </linearGradient>
        <linearGradient id="mtn-snow" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#FFFFFF" />
          <stop offset="100%" stopColor="#E4EEF3" />
        </linearGradient>
      </defs>

      <style>{`
        .mtn-haze {
          transform-box: fill-box;
          transform-origin: 50% 50%;
          animation: mtn-shimmer 9s ease-in-out infinite;
        }
        @keyframes mtn-shimmer {
          0%, 100% { opacity: 0.55; }
          50%      { opacity: 0.9; }
        }
        @media (prefers-reduced-motion: reduce) {
          .mtn-haze { animation: none !important; }
        }
      `}</style>

      {/* Distant atmospheric layer */}
      <path
        d="M0 220 L120 140 L240 200 L360 110 L500 180 L640 90 L800 170 L940 130 L1080 190 L1200 130 L1200 320 L0 320 Z"
        fill="url(#mtn-back)"
      />
      <path
        className="mtn-haze"
        d="M0 220 L120 140 L240 200 L360 110 L500 180 L640 90 L800 170 L940 130 L1080 190 L1200 130 L1200 220 L0 220 Z"
        fill="url(#mtn-back-haze)"
      />

      {/* Mid layer */}
      <path
        d="M0 260 L160 180 L320 240 L460 160 L620 220 L780 150 L940 210 L1080 170 L1200 230 L1200 320 L0 320 Z"
        fill="url(#mtn-mid)"
      />
      {/* Snow caps on tallest mid-layer peaks */}
      <path d="M460 160 L486 198 L434 198 Z" fill="url(#mtn-snow)" opacity="0.92" />
      <path d="M780 150 L808 192 L752 192 Z" fill="url(#mtn-snow)" opacity="0.92" />

      {/* Front layer */}
      <path
        d="M0 300 L140 232 L300 282 L440 212 L600 272 L780 222 L940 270 L1080 242 L1200 280 L1200 320 L0 320 Z"
        fill="url(#mtn-front)"
      />
    </svg>
  )
}

export default Mountains
