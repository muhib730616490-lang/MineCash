import React from 'react'

interface DecorProps {
  className?: string
}

interface CloudDef {
  id: string
  scale: number
  y: number
  duration: number // seconds for one full sweep
  phase: number // 0..1 starting offset in the loop
  opacity: number
}

// Phases are chosen so all clouds are initially visible across the 0..800 sky.
const CLOUDS: CloudDef[] = [
  { id: 'cloud-1', scale: 1.0, y: 38, duration: 62, phase: 0.2, opacity: 0.95 },
  { id: 'cloud-2', scale: 0.65, y: 95, duration: 82, phase: 0.42, opacity: 0.82 },
  { id: 'cloud-3', scale: 0.85, y: 68, duration: 72, phase: 0.66, opacity: 0.92 },
  { id: 'cloud-4', scale: 0.55, y: 118, duration: 56, phase: 0.8, opacity: 0.78 },
]

function CloudShape() {
  return (
    <g>
      {/* Soft bottom shadow for volume */}
      <ellipse cx="60" cy="52" rx="58" ry="13" fill="#C2Cdda" opacity="0.5" />
      {/* Layered puffs */}
      <ellipse cx="30" cy="36" rx="22" ry="17" fill="#F4F7FC" />
      <ellipse cx="58" cy="26" rx="29" ry="22" fill="#FFFFFF" />
      <ellipse cx="90" cy="34" rx="24" ry="19" fill="#F4F7FC" />
      <ellipse cx="68" cy="46" rx="34" ry="13" fill="#FFFFFF" />
      <ellipse cx="40" cy="44" rx="22" ry="10" fill="#EAF1FA" opacity="0.85" />
      {/* Top highlight */}
      <ellipse cx="55" cy="18" rx="15" ry="6" fill="#FFFFFF" opacity="0.95" />
    </g>
  )
}

/**
 * Wide row of fluffy cartoon clouds drifting slowly across the sky.
 * Each cloud sweeps from off-screen left to off-screen right and wraps invisibly.
 */
export function Clouds(props: DecorProps) {
  return (
    <svg
      viewBox="0 0 800 160"
      width="100%"
      height="auto"
      preserveAspectRatio="xMidYMid slice"
      shapeRendering="geometricPrecision"
      className={props.className}
      aria-hidden="true"
    >
      <style>{`
        .cloud-drift {
          transform-box: view-box;
          animation-name: cloud-drift;
          animation-timing-function: linear;
          animation-iteration-count: infinite;
        }
        @keyframes cloud-drift {
          from { transform: translateX(-160px); }
          to   { transform: translateX(960px); }
        }
        @media (prefers-reduced-motion: reduce) {
          .cloud-drift { animation: none !important; }
        }
      `}</style>

      {CLOUDS.map((c) => (
        <g
          key={c.id}
          className="cloud-drift"
          style={{
            animationDuration: `${c.duration}s`,
            animationDelay: `${-c.phase * c.duration}s`,
          } as React.CSSProperties}
        >
          <g transform={`translate(0 ${c.y}) scale(${c.scale})`} opacity={c.opacity}>
            <CloudShape />
          </g>
        </g>
      ))}
    </svg>
  )
}

export default Clouds
