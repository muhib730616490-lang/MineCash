import React from 'react'

interface DecorProps {
  className?: string
}

interface TreeDef {
  id: string
  x: number
  y: number
  scale: number
  type: 'round' | 'pine'
  delay: number
  duration: number
}

const TREES: TreeDef[] = [
  { id: 'tree-1', x: 50, y: 125, scale: 0.8, type: 'round', delay: 0, duration: 4.2 },
  { id: 'tree-2', x: 125, y: 110, scale: 0.95, type: 'pine', delay: -1.5, duration: 4.8 },
  { id: 'tree-3', x: 200, y: 140, scale: 0.7, type: 'round', delay: -0.8, duration: 4.5 },
]

function RoundTree() {
  return (
    <>
      {/* Trunk */}
      <rect x="-7" y="22" width="14" height="50" rx="5" fill="#8B5A2B" />
      <rect x="-7" y="22" width="6" height="50" rx="3" fill="#6F4520" />
      {/* Canopy - layered circles for volume */}
      <ellipse cx="-18" cy="5" rx="22" ry="20" fill="#3E8C3A" />
      <ellipse cx="18" cy="5" rx="22" ry="20" fill="#3E8C3A" />
      <ellipse cx="0" cy="-8" rx="28" ry="22" fill="#4FA346" />
      <ellipse cx="-12" cy="14" rx="20" ry="14" fill="#4FA346" />
      <ellipse cx="12" cy="14" rx="20" ry="14" fill="#57B04D" />
      {/* Highlights */}
      <ellipse cx="-6" cy="-14" rx="10" ry="6" fill="#6FC061" opacity="0.85" />
      <ellipse cx="9" cy="-6" rx="6" ry="4" fill="#7DCC6E" opacity="0.7" />
    </>
  )
}

function PineTree() {
  return (
    <>
      {/* Trunk */}
      <rect x="-6" y="40" width="12" height="40" rx="4" fill="#8B5A2B" />
      <rect x="-6" y="40" width="5" height="40" rx="2.5" fill="#6F4520" />
      {/* Pine canopy - layered triangles */}
      <path d="M0 -55 L22 -15 L-22 -15 Z" fill="#2F7A3F" />
      <path d="M0 -28 L34 18 L-34 18 Z" fill="#358244" />
      <path d="M0 5 L42 45 L-42 45 Z" fill="#3D8B4C" />
      {/* Highlights */}
      <path d="M0 -55 L6 -25 L-9 -22 L-4 -55 Z" fill="#56A85C" opacity="0.55" />
      <path d="M0 -28 L5 0 L-8 -2 L-2 -28 Z" fill="#56A85C" opacity="0.4" />
    </>
  )
}

/**
 * A small group of cartoon trees (round + pine mix) with a gentle sway.
 * Whole tree pivots around the trunk base.
 */
export function Trees(props: DecorProps) {
  return (
    <svg
      viewBox="0 0 240 200"
      width="100%"
      height="auto"
      preserveAspectRatio="xMidYMax meet"
      shapeRendering="geometricPrecision"
      className={props.className}
      aria-hidden="true"
    >
      <style>{`
        .tree-sway {
          transform-box: fill-box;
          transform-origin: 50% 100%;
          animation-name: tree-sway;
          animation-timing-function: ease-in-out;
          animation-iteration-count: infinite;
          animation-direction: alternate;
          animation-duration: var(--tree-duration, 4.5s);
          animation-delay: var(--tree-delay, 0s);
        }
        @keyframes tree-sway {
          from { transform: rotate(-2.5deg); }
          to   { transform: rotate(2.5deg); }
        }
        @media (prefers-reduced-motion: reduce) {
          .tree-sway { animation: none !important; }
        }
      `}</style>

      {TREES.map((t) => {
        const Tree = t.type === 'round' ? RoundTree : PineTree
        return (
          <g key={t.id} transform={`translate(${t.x} ${t.y}) scale(${t.scale})`}>
            <g
              className="tree-sway"
              style={{
                '--tree-delay': `${t.delay}s`,
                '--tree-duration': `${t.duration}s`,
              } as React.CSSProperties}
            >
              <Tree />
            </g>
          </g>
        )
      })}
    </svg>
  )
}

export default Trees
