import React from 'react'

interface DecorProps {
  className?: string
}

interface Flower {
  cx: number
  cy: number
  color: string
}

interface BushDef {
  id: string
  x: number
  y: number
  scale: number
  delay: number
  duration: number
  flowers: Flower[]
}

const BUSHES: BushDef[] = [
  {
    id: 'bush-1',
    x: 38,
    y: 58,
    scale: 1.0,
    delay: 0,
    duration: 4.0,
    flowers: [
      { cx: -16, cy: -8, color: '#F5A8C8' },
      { cx: 12, cy: -14, color: '#FFD56B' },
      { cx: 22, cy: -2, color: '#E78AC8' },
    ],
  },
  {
    id: 'bush-2',
    x: 118,
    y: 64,
    scale: 0.85,
    delay: -1.2,
    duration: 4.6,
    flowers: [
      { cx: -12, cy: -10, color: '#FFD56B' },
      { cx: 18, cy: -6, color: '#F5A8C8' },
    ],
  },
  {
    id: 'bush-3',
    x: 178,
    y: 70,
    scale: 0.6,
    delay: -0.5,
    duration: 4.3,
    flowers: [{ cx: 0, cy: -8, color: '#E78AC8' }],
  },
]

function BushShadow() {
  return <ellipse cx="0" cy="24" rx="40" ry="5" fill="#1F3A28" opacity="0.16" />
}

function BushLeaves({ flowers }: { flowers: Flower[] }) {
  return (
    <>
      {/* Back lobes (darker) */}
      <ellipse cx="-22" cy="6" rx="18" ry="16" fill="#3D7A3F" />
      <ellipse cx="22" cy="6" rx="18" ry="16" fill="#3D7A3F" />
      {/* Front lobes */}
      <ellipse cx="-12" cy="0" rx="20" ry="18" fill="#4F9A4A" />
      <ellipse cx="14" cy="0" rx="22" ry="18" fill="#4F9A4A" />
      <ellipse cx="0" cy="-6" rx="20" ry="16" fill="#5BA855" />
      {/* Highlights */}
      <ellipse cx="-4" cy="-12" rx="10" ry="6" fill="#73C069" opacity="0.75" />
      <ellipse cx="8" cy="-8" rx="6" ry="4" fill="#86D27A" opacity="0.65" />
      {/* Tiny flowers */}
      {flowers.map((f, i) => (
        <g key={i}>
          <circle cx={f.cx} cy={f.cy} r="3" fill={f.color} />
          <circle cx={f.cx} cy={f.cy} r="1" fill="#FFFFFF" opacity="0.85" />
        </g>
      ))}
    </>
  )
}

/**
 * A couple of rounded leafy bushes with tiny flowers. Slight idle sway
 * pivots around the base of the foliage (shadow stays put).
 */
export function Bushes(props: DecorProps) {
  return (
    <svg
      viewBox="0 0 200 90"
      width="100%"
      height="auto"
      preserveAspectRatio="xMidYMax meet"
      shapeRendering="geometricPrecision"
      className={props.className}
      aria-hidden="true"
    >
      <style>{`
        .bush-sway {
          transform-box: fill-box;
          transform-origin: 50% 100%;
          animation-name: bush-sway;
          animation-timing-function: ease-in-out;
          animation-iteration-count: infinite;
          animation-direction: alternate;
          animation-duration: var(--bush-duration, 4.2s);
          animation-delay: var(--bush-delay, 0s);
        }
        @keyframes bush-sway {
          from { transform: rotate(-1.8deg); }
          to   { transform: rotate(1.8deg); }
        }
        @media (prefers-reduced-motion: reduce) {
          .bush-sway { animation: none !important; }
        }
      `}</style>

      {BUSHES.map((b) => (
        <g key={b.id} transform={`translate(${b.x} ${b.y}) scale(${b.scale})`}>
          <BushShadow />
          <g
            className="bush-sway"
            style={{
              '--bush-delay': `${b.delay}s`,
              '--bush-duration': `${b.duration}s`,
            } as React.CSSProperties}
          >
            <BushLeaves flowers={b.flowers} />
          </g>
        </g>
      ))}
    </svg>
  )
}

export default Bushes
