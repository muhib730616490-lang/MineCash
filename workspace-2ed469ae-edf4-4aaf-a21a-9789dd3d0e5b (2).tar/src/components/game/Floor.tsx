"use client";
import { useEffect, useRef, useState } from "react";
import type { FloorState } from "@/game/types";
import type { MineConfig } from "@/game/config";
import {
  MAX_MINER_LEVEL,
  minerUpgradeCost,
  minerManagerCost,
  floorUnlockCostCoins,
  floorUnlockAds,
  canUnlockFloorWithAds,
  workerCountFromLevel,
  minerCycleTime,
  oreUnitValue,
  ORE_PER_BATCH,
  FLOOR_AD_DURATION,
} from "@/game/config";
import { useGameStore } from "@/store/gameStore";
import { useMetaStore } from "@/store/metaStore";
import { useT } from "@/game/useT";
import { useFeedback } from "@/game/useFeedback";
import { formatNumber } from "@/lib/format";
import { Worker } from "./Worker";
import { Manager } from "./Manager";
import { CoinIcon } from "./icons";
import {
  UserCheck,
  Lock,
  ChevronDown,
  Hammer,
  Hand,
  Tv,
  Zap,
} from "lucide-react";

interface FloorProps {
  floor: FloorState;
  coins: number;
  prevUnlocked: boolean;
  cfg: MineConfig;
}

export function Floor({ floor, coins, prevUnlocked, cfg }: FloorProps) {
  if (!floor.unlocked) {
    return <LockedFloor floor={floor} coins={coins} prevUnlocked={prevUnlocked} cfg={cfg} />;
  }
  return <ActiveFloor floor={floor} coins={coins} cfg={cfg} />;
}

/* ----------------------------- Locked floor ----------------------------- */
function LockedFloor({ floor, coins, prevUnlocked, cfg }: FloorProps) {
  const t = useT();
  const feedback = useFeedback();
  const unlockFloor = useGameStore((s) => s.unlockFloor);
  const watchAdForFloorUnlock = useGameStore((s) => s.watchAdForFloorUnlock);
  const coinCost = floorUnlockCostCoins(floor.id);
  const adCost = floorUnlockAds(floor.id);
  const canUseAds = canUnlockFloorWithAds(floor.id);
  const canAfford = coins >= coinCost;
  const unlockable = prevUnlocked;
  const [adCountdown, setAdCountdown] = useState<number | null>(null);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Ad countdown for floor unlock (no global cooldown — one-time per floor)
  useEffect(() => {
    if (adCountdown === null) return;
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(() => {
      setAdCountdown((c) => {
        if (c === null) return null;
        if (c <= 1) {
          if (timerRef.current) clearInterval(timerRef.current);
          watchAdForFloorUnlock(floor.id);
          return null;
        }
        return c - 1;
      });
    }, 1000);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [adCountdown, floor.id, watchAdForFloorUnlock]);

  const startAd = () => {
    setAdCountdown(FLOOR_AD_DURATION);
  };

  return (
    <div
      className="relative h-[var(--imt-floor-h)] w-full overflow-hidden border-b-2 border-black/60"
      style={{ background: `linear-gradient(180deg, ${cfg.rockTintDark} 0%, #160d06 45%, ${cfg.rockTintDark} 100%)` }}
    >
      <div className="absolute inset-0 opacity-30" style={{ backgroundImage: `radial-gradient(${cfg.rockTint} 1.5px, transparent 1.5px), radial-gradient(#00000066 1px, transparent 1px)`, backgroundSize: "26px 26px, 15px 15px" }} />
      <svg viewBox="0 0 400 140" preserveAspectRatio="none" className="absolute inset-0 h-full w-full opacity-70" aria-hidden>
        <g fill={cfg.rockTint}>
          <path d="M0 140 L0 108 Q26 94 46 102 Q66 86 88 98 L88 140 Z" />
          <path d="M300 140 L300 106 Q328 90 358 100 Q380 86 400 98 L400 140 Z" />
          <circle cx="120" cy="118" r="11" />
          <circle cx="150" cy="128" r="7" />
          <circle cx="200" cy="122" r="9" />
          <circle cx="244" cy="130" r="6" />
          <circle cx="270" cy="116" r="10" />
        </g>
      </svg>
      <div className="absolute right-6 top-1/2 h-16 w-1.5 -translate-y-1/2 rounded-full opacity-50 blur-[1px]" style={{ background: `linear-gradient(${cfg.oreGlow}, transparent, ${cfg.oreGlow})` }} />
      <div className="absolute inset-0 bg-black/35" />

      <div className="absolute left-1.5 top-1.5 z-10 rounded bg-stone-900/80 px-1.5 py-0.5 text-[10px] font-bold text-stone-400">
        {t("floor")} {floor.id}
      </div>

      {/* Ad countdown overlay */}
      {adCountdown !== null && (
        <div className="absolute inset-0 z-30 flex flex-col items-center justify-center gap-2 bg-black/80 backdrop-blur-sm">
          <Tv className="size-8 text-amber-300/70" />
          <div className="text-sm font-bold text-amber-200">{t("adPlaying")}</div>
          <div className="flex items-center gap-1.5 rounded-full bg-stone-800 px-3 py-1 text-lg font-bold text-amber-300">
            {adCountdown}s
          </div>
          <div className="h-1 w-32 overflow-hidden rounded-full bg-stone-700">
            <div
              className="h-full bg-amber-500 transition-all duration-1000 ease-linear"
              style={{ width: `${((FLOOR_AD_DURATION - adCountdown) / FLOOR_AD_DURATION) * 100}%` }}
            />
          </div>
        </div>
      )}

      <div className="absolute inset-0 z-10 flex flex-col items-center justify-center gap-2">
        <div className="flex size-11 items-center justify-center rounded-full border-2 border-stone-600/80 bg-stone-900/80 text-stone-300 shadow-lg backdrop-blur-sm">
          <Lock className="size-5" />
        </div>
        {unlockable ? (
          <div className="flex flex-col items-center gap-2">
            {/* Coin unlock button — large, touch-friendly */}
            <button
              onClick={() => {
                feedback("purchase");
                unlockFloor(floor.id);
                useMetaStore.getState().trackMission("unlockFloor", 1);
              }}
              disabled={!canAfford}
              className={[
                "flex min-h-[42px] items-center gap-2 rounded-xl border-2 px-4 py-2 text-sm font-bold shadow-md transition active:scale-95",
                canAfford
                  ? "border-amber-400/60 bg-gradient-to-b from-amber-500 to-amber-600 text-stone-950 hover:from-amber-400 hover:to-amber-500"
                  : "cursor-not-allowed border-stone-600/50 bg-stone-800/70 text-stone-500",
              ].join(" ")}
            >
              <ChevronDown className="size-4" />
              {t("unlock")}
              <CoinIcon className="size-4" />
              {formatNumber(coinCost)}
            </button>
            {/* Ad unlock button (floors 2-10 only) — large, touch-friendly */}
            {canUseAds && (
              <button
                onClick={() => { feedback("tap"); startAd(); }}
                disabled={adCountdown !== null}
                className="flex min-h-[38px] items-center gap-2 rounded-xl border-2 border-fuchsia-400/50 bg-gradient-to-b from-fuchsia-600 to-fuchsia-700 px-4 py-2 text-xs font-bold text-fuchsia-50 shadow-md transition hover:from-fuchsia-500 hover:to-fuchsia-600 active:scale-95 disabled:opacity-50"
              >
                <Tv className="size-4" />
                {t("watchAd")} ({floor.adsWatched}/{adCost})
              </button>
            )}
          </div>
        ) : (
          <div className="rounded-lg border border-stone-700/70 bg-stone-900/70 px-2.5 py-1 text-[11px] font-medium text-stone-400">
            {t("floor")} {floor.id - 1} → {floor.id}
          </div>
        )}
      </div>
    </div>
  );
}

/* ----------------------------- Active floor ----------------------------- */
function ActiveFloor({ floor, coins, cfg }: { floor: FloorState; coins: number; cfg: MineConfig }) {
  const t = useT();
  const upgradeMiner = useGameStore((s) => s.upgradeMiner);
  const hireMinerManager = useGameStore((s) => s.hireMinerManager);
  const tapFloor = useGameStore((s) => s.tapFloor);
  const trackMission = useMetaStore((s) => s.trackMission);
  const incrementUpgrades = useMetaStore((s) => s.incrementUpgrades);
  const incrementManagersHired = useMetaStore((s) => s.incrementManagersHired);
  const feedback = useFeedback();

  const upgradeCost = minerUpgradeCost(floor.minerLevel, floor.id);
  const mgrCost = minerManagerCost(floor.id);
  const perOre = oreUnitValue(cfg.baseOreValue, floor.id);
  const cycle = minerCycleTime(floor.minerLevel);
  const workerCount = workerCountFromLevel(floor.minerLevel);
  const isAuto = floor.minerManagerHired;
  const isMaxLevel = floor.minerLevel >= MAX_MINER_LEVEL;
  const canUpgrade = !isMaxLevel && coins >= upgradeCost;
  const canHireMgr = !isAuto && coins >= mgrCost;

  // depth-based visual richness: higher floors get more decorations
  const depthTier = floor.id <= 3 ? 0 : floor.id <= 8 ? 1 : floor.id <= 14 ? 2 : 3;
  const lanternCount = 1 + depthTier;
  const beamCount = 3 + depthTier;

  // Worker positions — spread across the mining area (middle of floor),
  // raised above the bottom button bar so they never overlap buttons.
  const workerPositions: { left: string; bottom: string }[] = [];
  if (workerCount === 1) {
    workerPositions.push({ left: "60%", bottom: "52px" });
  } else if (workerCount === 2) {
    workerPositions.push({ left: "55%", bottom: "52px" });
    workerPositions.push({ left: "67%", bottom: "56px" });
  } else {
    workerPositions.push({ left: "52%", bottom: "52px" });
    workerPositions.push({ left: "62%", bottom: "58px" });
    workerPositions.push({ left: "72%", bottom: "52px" });
  }

  return (
    <div
      className="relative h-[var(--imt-floor-h)] w-full overflow-hidden border-b-2 border-black/50"
      style={{ background: `linear-gradient(180deg, ${cfg.rockTintDark} 0%, ${cfg.rockTintDark} 18%, ${cfg.rockTint} 30%, ${cfg.rockTint} 74%, ${cfg.rockTintDark} 86%, #2a1c10 100%)` }}
    >
      {/* tap-to-mine overlay (only when manual) */}
      {!isAuto && (
        <button
          onClick={() => tapFloor(floor.id)}
          className="absolute inset-0 z-30 cursor-pointer"
          aria-label={t("tapToMine")}
        />
      )}

      {/* rock texture */}
      <div className="absolute inset-0 opacity-25" style={{ backgroundImage: `radial-gradient(${cfg.rockTintDark} 1.5px, transparent 1.5px), radial-gradient(#00000055 1px, transparent 1px)`, backgroundSize: "28px 28px, 17px 17px", backgroundPosition: "0 0, 8px 8px" }} />
      {/* tunnel light ellipse */}
      <div className="absolute left-1/2 top-1/2 h-[80%] w-[70%] -translate-x-1/2 -translate-y-1/2 rounded-[50%] imt-floor-glow" style={{ background: `radial-gradient(ellipse, ${cfg.oreGlow}${depthTier >= 2 ? "28" : "18"} 0%, transparent 70%)` }} />

      {/* support beams */}
      <div className="absolute left-0 right-0 top-0 h-3 bg-gradient-to-b from-[#7a4a22] to-[#4a2c10] shadow-md" />
      {Array.from({ length: beamCount }).map((_, i) => {
        const x = 16 + (i * (68 / (beamCount - 1)));
        return (
          <div key={i} className="absolute bottom-0 top-0 w-2.5 bg-gradient-to-r from-[#5a3416] via-[#8a5a2b] to-[#5a3416] opacity-90" style={{ left: `${x}%` }} />
        );
      })}

      {/* hanging lanterns */}
      {Array.from({ length: lanternCount }).map((_, i) => {
        const x = 30 + i * (40 / Math.max(1, lanternCount - 1));
        return (
          <div key={`l${i}`} className="absolute top-0 flex flex-col items-center" style={{ left: `${x}%` }}>
            <div className="h-3 w-px bg-stone-600" />
            <div className="relative">
              <div className="size-3 rounded-full bg-amber-300 shadow-[0_0_12px_4px_rgba(251,191,36,0.7)] imt-lantern" />
              <div className="absolute -bottom-6 left-1/2 h-10 w-16 -translate-x-1/2 rounded-[50%]" style={{ background: `radial-gradient(ellipse at top, rgba(251,191,36,${0.2 + depthTier * 0.08}), transparent 70%)` }} />
            </div>
          </div>
        );
      })}

      {/* mine cart rails on floor (deeper floors) */}
      {depthTier >= 1 && (
        <div className="absolute bottom-[6px] left-[15%] right-[18%] h-2 opacity-40">
          <div className="absolute top-0 left-0 h-0.5 w-full bg-stone-500" />
          <div className="absolute top-1.5 left-0 h-0.5 w-full bg-stone-500" />
        </div>
      )}

      {/* ore vein (right wall) */}
      <OreVein cfg={cfg} depthTier={depthTier} />

      {/* pending ore pile near shaft (left) */}
      <PendingOrePile count={floor.pendingOre} cfg={cfg} />

      {/* mining dust particles */}
      <MiningDust cfg={cfg} active={isAuto || !isAuto} />

      {/* manager (if hired) — stands beside workers, to their left, never overlapping */}
      {floor.minerManagerHired && (
        <div className="absolute z-10 imt-pop-in" style={{ left: "30%", bottom: "54px" }}>
          <Manager size={54} />
        </div>
      )}

      {/* workers — always animated, positioned in the middle area, never overlapping buttons */}
      {workerPositions.map((pos, i) => (
        <div
          key={`w${i}`}
          className="absolute z-[5]"
          style={{ left: pos.left, bottom: pos.bottom, zIndex: 5 + i }}
        >
          <Worker
            state="mining"
            direction="right"
            size={58}
            variant={(floor.id + i) % 4}
            speed={1 + (i % 3) * 0.1}
          />
        </div>
      ))}

      {/* carrier hauling ore to the shaft (only when manager hired — automated transport) */}
      {isAuto && (
        <div className="imt-haul absolute z-[8]" style={{ bottom: "52px", animationDelay: `${(floor.id % 5) * 0.6}s` }}>
          <Worker state="carrying" direction="right" size={54} variant={(floor.id + 2) % 4} speed={1} />
        </div>
      )}

      {/* progress strip (top) */}
      <div className="absolute left-0 top-0 h-[3px] w-full bg-black/40">
        <div
          className="h-full transition-[width] duration-150 ease-linear"
          style={{ width: `${Math.min(100, floor.progress * 100)}%`, background: `linear-gradient(90deg, ${cfg.oreColor}, ${cfg.oreGlow})` }}
        />
      </div>

      {/* floor label + auto/manual badge */}
      <div className="absolute left-1.5 top-1.5 z-40 flex items-center gap-1">
        <div className="rounded bg-stone-900/80 px-1.5 py-0.5 text-[10px] font-bold text-amber-200 shadow">
          {t("floor")} {floor.id}
        </div>
        <div className={[
          "rounded px-1 py-0.5 text-[9px] font-bold",
          isAuto ? "bg-emerald-700/80 text-emerald-100" : "bg-amber-700/80 text-amber-100",
        ].join(" ")}>
          {isAuto ? t("autoOn") : t("autoOff")}
        </div>
        {/* worker count indicator */}
        <div className="rounded bg-stone-900/80 px-1 py-0.5 text-[9px] font-bold text-sky-200 shadow">
          {workerCount}×⛏
        </div>
      </div>

      {/* tap hint (manual mode only) — moved closer to workers */}
      {!isAuto && (
        <div className="absolute left-1/2 z-20 -translate-x-1/2 animate-pulse rounded-full border border-amber-400/50 bg-stone-900/85 px-2.5 py-1 text-[10px] font-bold text-amber-200 shadow-lg" style={{ bottom: "100px" }}>
          <Hand className="mr-1 inline size-3" />
          {t("tapToMine")}
        </div>
      )}

      {/* per-ore value badge (top-right, informational only) */}
      <div className="absolute right-1.5 top-1.5 z-40 flex items-center gap-1 rounded-lg bg-stone-900/80 px-2 py-1 text-[10px] font-bold text-amber-200 shadow">
        <CoinIcon className="size-3" />
        {perOre}
        <span className="text-amber-400/60">/{t("perOre")}</span>
      </div>

      {/* pending ore badge (top area, left of per-ore) */}
      {floor.pendingOre > 0 && (
        <div className="absolute z-40 rounded-lg border border-amber-400/40 bg-stone-900/80 px-2 py-1 text-[10px] font-bold text-amber-200 shadow" style={{ right: "70px", top: "6px" }}>
          {formatNumber(floor.pendingOre)} ⛏
        </div>
      )}

      {/* BOTTOM BUTTON BAR — thumb-friendly, full-width, 2 large buttons */}
      <div className="absolute bottom-0 left-0 right-0 z-40 flex gap-1.5 border-t border-black/40 bg-gradient-to-t from-stone-950/95 to-stone-900/80 p-1.5 backdrop-blur-sm">
        <FloorButton
          icon={<Hammer className="size-4" />}
          label={isMaxLevel ? t("maxWorkers") : formatNumber(upgradeCost)}
          sub={`Lv ${floor.minerLevel}/${MAX_MINER_LEVEL}`}
          disabled={isMaxLevel || coins < upgradeCost}
          accent="amber"
          glow={canUpgrade}
          onClick={() => {
            feedback("upgrade");
            upgradeMiner(floor.id);
            trackMission("upgradeMiner", 1);
            incrementUpgrades();
          }}
        />
        <FloorButton
          icon={isAuto ? <UserCheck className="size-4" /> : <Zap className="size-4" />}
          label={isAuto ? "✓" : formatNumber(mgrCost)}
          sub={t("manager")}
          disabled={isAuto || coins < mgrCost}
          accent={isAuto ? "stone" : "violet"}
          glow={canHireMgr}
          onClick={() => {
            feedback("purchase");
            hireMinerManager(floor.id);
            trackMission("hireManager", 1);
            incrementManagersHired();
          }}
        />
      </div>
    </div>
  );
}

/* ----------------------------- Sub-components ----------------------------- */
function OreVein({ cfg, depthTier }: { cfg: MineConfig; depthTier: number }) {
  const glowIntensity = 0.6 + depthTier * 0.1;
  return (
    <div className="absolute right-0 top-1/2 h-[80%] w-[16%] -translate-y-1/2" aria-hidden>
      <svg viewBox="0 0 80 120" preserveAspectRatio="none" className="crisp h-full w-full">
        <defs>
          <radialGradient id={`ov-${cfg.id}-${depthTier}`} cx="0.4" cy="0.4" r="0.7">
            <stop offset="0" stopColor={cfg.oreGlow} stopOpacity={glowIntensity + 0.3} />
            <stop offset="0.6" stopColor={cfg.oreColor} />
            <stop offset="1" stopColor={cfg.rockTintDark} />
          </radialGradient>
        </defs>
        <path d="M0 0 L80 0 L80 120 L0 120 Z" fill={cfg.rockTintDark} opacity="0.6" />
        <path d="M10 20 Q30 8 50 18 Q70 10 78 28 L78 70 Q66 86 48 78 Q30 90 18 76 Q6 64 10 20 Z" fill={`url(#ov-${cfg.id}-${depthTier})`} stroke={cfg.oreColor} strokeWidth="1.5" className="imt-ore-pulse" style={{ color: cfg.oreGlow }} />
        <circle cx="28" cy="36" r="2.5" fill={cfg.oreGlow} className="imt-sparkle" style={{ color: cfg.oreGlow }} />
        <circle cx="52" cy="50" r="2" fill={cfg.oreGlow} className="imt-sparkle" style={{ color: cfg.oreGlow, animationDelay: "0.8s" }} />
        <circle cx="38" cy="64" r="2.2" fill={cfg.oreGlow} className="imt-sparkle" style={{ color: cfg.oreGlow, animationDelay: "1.5s" }} />
        {depthTier >= 2 && <circle cx="62" cy="30" r="1.8" fill={cfg.oreGlow} className="imt-sparkle" style={{ color: cfg.oreGlow, animationDelay: "2s" }} />}
      </svg>
    </div>
  );
}

function PendingOrePile({ count, cfg }: { count: number; cfg: MineConfig }) {
  if (count <= 0) return null;
  const chunks = Math.min(8, Math.ceil(count / 2));
  return (
    <div className="absolute z-[3]" style={{ left: "11%", bottom: "52px" }} aria-hidden>
      <div className="relative flex items-end gap-0.5">
        {Array.from({ length: chunks }).map((_, i) => (
          <div
            key={i}
            className="imt-ore-pulse"
            style={{
              width: `${8 - (i % 3)}px`,
              height: `${6 + (i % 4) * 3}px`,
              background: `linear-gradient(180deg, ${cfg.oreGlow}, ${cfg.oreColor})`,
              borderRadius: "40% 40% 30% 30%",
              color: cfg.oreGlow,
              boxShadow: `0 0 4px ${cfg.oreGlow}`,
              animationDelay: `${i * 0.2}s`,
            }}
          />
        ))}
      </div>
    </div>
  );
}

function MiningDust({ cfg, active }: { cfg: MineConfig; active: boolean }) {
  if (!active) return null;
  return (
    <div className="pointer-events-none absolute z-[4]" style={{ right: "22%", bottom: "58px" }} aria-hidden>
      {Array.from({ length: 4 }).map((_, i) => (
        <div
          key={i}
          className="imt-dust absolute size-1 rounded-full"
          style={{
            background: cfg.rockTint,
            "--dx": `${(i - 1.5) * 12}px`,
            animationDelay: `${i * 0.22}s`,
            animationDuration: "0.9s",
          } as React.CSSProperties}
        />
      ))}
    </div>
  );
}

/* Premium touch-friendly floor button — large, rounded, with press animation */
function FloorButton({
  icon,
  label,
  sub,
  disabled,
  accent,
  glow,
  onClick,
}: {
  icon: React.ReactNode;
  label: string;
  sub?: string;
  disabled?: boolean;
  accent: "amber" | "violet" | "stone";
  glow?: boolean;
  onClick: () => void;
}) {
  const [pressed, setPressed] = useState(false);
  const accents: Record<string, string> = {
    amber: "border-amber-400/60 bg-gradient-to-b from-amber-600 to-amber-700 text-amber-50 hover:from-amber-500 hover:to-amber-600",
    violet: "border-fuchsia-400/60 bg-gradient-to-b from-fuchsia-600 to-fuchsia-700 text-fuchsia-50 hover:from-fuchsia-500 hover:to-fuchsia-600",
    stone: "border-stone-500/50 bg-gradient-to-b from-stone-600 to-stone-700 text-stone-200",
  };
  return (
    <button
      onClick={() => {
        if (disabled) return;
        setPressed(true);
        setTimeout(() => setPressed(false), 200);
        onClick();
      }}
      disabled={disabled}
      className={[
        "relative flex flex-1 items-center justify-center gap-1.5 rounded-xl border-2 px-2 py-2 min-h-[42px] text-xs font-bold shadow-md transition-all",
        pressed ? "scale-95 imt-btn-press" : "active:scale-95",
        disabled
          ? "cursor-not-allowed border-stone-700/50 bg-stone-800/60 text-stone-600"
          : accents[accent],
        !disabled && glow ? "imt-btn-glow" : "",
      ].join(" ")}
    >
      <span className="flex shrink-0 items-center">{icon}</span>
      <span className="flex min-w-0 flex-col items-start leading-tight">
        <span className="flex items-center gap-0.5 tabular-nums">
          <CoinIcon className="size-3" />
          {label}
        </span>
        {sub && <span className="text-[9px] font-medium opacity-80">{sub}</span>}
      </span>
    </button>
  );
}
