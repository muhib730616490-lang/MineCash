"use client";
import { useEffect, useState, useRef } from "react";
import { useGameStore } from "@/store/gameStore";
import { useMetaStore } from "@/store/metaStore";
import { useAdminConfig } from "@/store/adminConfig";
import { useGameLoop } from "@/game/useGameLoop";
import { useMetaBridge } from "@/game/useMetaBridge";
import { useT } from "@/game/useT";
import { processReferralLink } from "@/store/metaStore";
import { estimateIncomeRate } from "@/game/config";
import { TopBar } from "./TopBar";
import { Scene } from "./Scene";
import { LogisticsPanel } from "./LogisticsPanel";
import { WelcomeFlow } from "./WelcomeFlow";
import { BottomDock } from "./BottomDock";
import { ProfileDialog } from "./ProfileDialog";
import { SettingsDialog } from "./SettingsDialog";
import { ReferralDialog } from "./ReferralDialog";
import { DailyRewardDialog } from "./DailyRewardDialog";
import { MissionsDialog } from "./MissionsDialog";
import { AchievementsDialog } from "./AchievementsDialog";
import { HelpCenterDialog } from "./HelpCenterDialog";
import { WalletDialog } from "./WalletDialog";
import { AdminPanel } from "./AdminPanel";
import { WelcomeBackDialog } from "./WelcomeBackDialog";
import { WalletUnlockDialog } from "./WalletUnlockDialog";
import { PickaxeIcon } from "./icons";

export function Game() {
  const hydrated = useGameStore((s) => s.hydrated);
  const t = useT();
  useGameLoop();
  useMetaBridge();

  // Dialog state
  const [profileOpen, setProfileOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [referralOpen, setReferralOpen] = useState(false);
  const [dailyOpen, setDailyOpen] = useState(false);
  const [missionsOpen, setMissionsOpen] = useState(false);
  const [achievementsOpen, setAchievementsOpen] = useState(false);
  const [helpOpen, setHelpOpen] = useState(false);
  const [walletOpen, setWalletOpen] = useState(false);
  const [adminOpen, setAdminOpen] = useState(false);
  const [welcomeBackOpen, setWelcomeBackOpen] = useState(false);
  const [walletUnlockOpen, setWalletUnlockOpen] = useState(false);

  // On mount: process referral link + calculate offline earnings + check wallet unlock.
  // Uses a ref to ensure this only runs once.
  const initRef = useRef(false);
  useEffect(() => {
    if (initRef.current) return;
    initRef.current = true;

    processReferralLink();

    // Check for admin access via URL param
    if (new URLSearchParams(window.location.search).get("admin") === "1") {
      setTimeout(() => setAdminOpen(true), 100);
    }

    // --- Offline earnings + wallet unlock (deferred to avoid setState in effect) ---
    const meta = useMetaStore.getState();
    const game = useGameStore.getState();
    const adminConfig = useAdminConfig.getState();

    // Check wallet unlock first (if gold mine unlocked but wallet not yet unlocked)
    let shouldShowWalletUnlock = false;
    if (!meta.profile.walletUnlocked && game.mines.gold.unlocked) {
      meta.unlockWallet();
      shouldShowWalletUnlock = true;
    }

    // Calculate offline earnings if welcome flow completed
    let shouldShowWelcomeBack = false;
    if (meta.welcomeCompleted) {
      const now = Date.now();
      const lastSeen = meta.profile.lastSeenAt || now;
      const secondsAway = (now - lastSeen) / 1000;
      if (secondsAway > 60) {
        const rate = estimateIncomeRate(game.mines, 1, game.activeMine);
        const earnings = meta.calculateOfflineEarnings(
          rate,
          adminConfig.offline.efficiency,
          adminConfig.offline.maxHours
        );
        if (earnings > 0) {
          shouldShowWelcomeBack = true;
        } else {
          meta.clearOfflineEarnings();
        }
      } else {
        useMetaStore.setState((s) => ({
          profile: { ...s.profile, lastSeenAt: now },
        }));
      }
    }

    // Defer dialog opening to next tick to avoid setState-in-effect warning
    if (shouldShowWelcomeBack || shouldShowWalletUnlock) {
      setTimeout(() => {
        if (shouldShowWelcomeBack) setWelcomeBackOpen(true);
        if (shouldShowWalletUnlock) setWalletUnlockOpen(true);
      }, 100);
    }
  }, []);

  if (!hydrated) {
    return <LoadingSplash label={t("loading")} />;
  }

  return (
    <div className="flex h-[100dvh] flex-col overflow-hidden bg-stone-950">
      <TopBar onOpenHelp={() => setHelpOpen(true)} onOpenAdmin={() => setAdminOpen(true)} />
      <main className="mine-scroll relative flex-1 overflow-y-auto overflow-x-hidden bg-stone-950">
        <Scene />
        <div className="h-4" />
      </main>
      <LogisticsPanel />
      <BottomDock
        onOpenProfile={() => setProfileOpen(true)}
        onOpenMissions={() => setMissionsOpen(true)}
        onOpenDaily={() => setDailyOpen(true)}
        onOpenReferral={() => setReferralOpen(true)}
        onOpenAchievements={() => setAchievementsOpen(true)}
        onOpenHelp={() => setHelpOpen(true)}
        onOpenWallet={() => setWalletOpen(true)}
      />
      <WelcomeFlow />
      <WelcomeBackDialog open={welcomeBackOpen} onOpenChange={setWelcomeBackOpen} />
      <WalletUnlockDialog open={walletUnlockOpen} onOpenChange={setWalletUnlockOpen} />
      <ProfileDialog open={profileOpen} onOpenChange={setProfileOpen} />
      <SettingsDialog open={settingsOpen} onOpenChange={setSettingsOpen} onOpenHelp={() => setHelpOpen(true)} />
      <ReferralDialog open={referralOpen} onOpenChange={setReferralOpen} />
      <DailyRewardDialog open={dailyOpen} onOpenChange={setDailyOpen} />
      <MissionsDialog open={missionsOpen} onOpenChange={setMissionsOpen} />
      <AchievementsDialog open={achievementsOpen} onOpenChange={setAchievementsOpen} />
      <HelpCenterDialog open={helpOpen} onOpenChange={setHelpOpen} />
      <WalletDialog open={walletOpen} onOpenChange={setWalletOpen} />
      <AdminPanel open={adminOpen} onOpenChange={setAdminOpen} />
    </div>
  );
}

function LoadingSplash({ label }: { label: string }) {
  return (
    <div className="flex h-[100dvh] flex-col items-center justify-center gap-4 bg-gradient-to-b from-stone-900 via-stone-950 to-black text-amber-100">
      <div className="relative flex size-20 items-center justify-center">
        <div className="absolute inset-0 rounded-full border-4 border-amber-900/40" />
        <PickaxeIcon className="size-10 text-amber-400 imt-spin-slow" />
      </div>
      <div className="text-sm font-semibold tracking-wide text-amber-200/80">{label}</div>
    </div>
  );
}
