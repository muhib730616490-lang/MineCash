"use client";
import { PanelDialog } from "./PanelDialog";
import { Button } from "@/components/ui/button";
import { useMetaStore } from "@/store/metaStore";
import { useGameStore } from "@/store/gameStore";
import { useT } from "@/game/useT";
import { formatNumber } from "@/lib/format";
import { CoinIcon, GemIcon } from "./icons";
import { Trophy, Check, Lock, Gift } from "lucide-react";
import { ACHIEVEMENTS } from "@/game/config";
import { toast } from "sonner";

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
}

export function AchievementsDialog({ open, onOpenChange }: Props) {
  const t = useT();
  const achievements = useMetaStore((s) => s.achievements);
  const claimAchievement = useMetaStore((s) => s.claimAchievement);
  const grantReward = useGameStore((s) => s.grantReward);

  const handleClaim = (id: string) => {
    const reward = claimAchievement(id);
    if (reward) {
      grantReward(reward.coins, reward.gems);
      toast.success(`+${formatNumber(reward.coins)} coins, +${reward.gems} gems!`, {
        description: t("achievements") + " " + t("claim"),
      });
    }
  };

  const unlockedCount = achievements.filter((a) => a.unlocked).length;
  const lang = useMetaStore.getState().settings.language;

  return (
    <PanelDialog
      open={open}
      onOpenChange={onOpenChange}
      title={t("achievements")}
      icon={<Trophy className="size-5" />}
      description={`${unlockedCount}/${achievements.length} ${t("unlocked")} · ${t("achievementsDesc")}`}
    >
      <div className="space-y-2">
        {ACHIEVEMENTS.map((def) => {
          const state = achievements.find((a) => a.id === def.id);
          if (!state) return null;
          const name = lang === "ar" ? def.nameAr : def.name;
          const desc = lang === "ar" ? def.descriptionAr : def.description;
          return (
            <div
              key={def.id}
              className={[
                "flex items-center gap-3 rounded-xl border p-3 transition",
                state.unlocked
                  ? state.claimed
                    ? "border-stone-700/50 bg-stone-800/20 opacity-70"
                    : "border-emerald-600/50 bg-emerald-900/20"
                  : "border-stone-700/50 bg-stone-800/30",
              ].join(" ")}
            >
              <div className={[
                "flex size-11 shrink-0 items-center justify-center rounded-full text-xl",
                state.unlocked ? "bg-gradient-to-br from-amber-500 to-orange-600" : "bg-stone-700 grayscale",
              ].join(" ")}>
                {state.unlocked ? def.icon : <Lock className="size-4 text-stone-500" />}
              </div>
              <div className="min-w-0 flex-1">
                <div className="text-xs font-bold text-amber-100">{name}</div>
                <div className="text-[10px] text-stone-400">{desc}</div>
                <div className="mt-1 flex items-center gap-1">
                  <span className="flex items-center gap-0.5 text-[9px] font-bold text-amber-300">
                    <CoinIcon className="size-2.5" />
                    {formatNumber(def.rewardCoins)}
                  </span>
                  {def.rewardGems > 0 && (
                    <span className="flex items-center gap-0.5 text-[9px] font-bold text-teal-300">
                      <GemIcon className="size-2.5" />
                      {def.rewardGems}
                    </span>
                  )}
                </div>
              </div>
              {state.unlocked && !state.claimed && (
                <Button
                  className="shrink-0 bg-emerald-600 text-white hover:bg-emerald-500"
                  size="sm"
                  onClick={() => handleClaim(def.id)}
                >
                  <Gift className="size-3" />
                  {t("claim")}
                </Button>
              )}
              {state.claimed && (
                <div className="flex shrink-0 items-center gap-1 text-[10px] font-bold text-stone-500">
                  <Check className="size-3" /> {t("rewardClaimed")}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </PanelDialog>
  );
}
