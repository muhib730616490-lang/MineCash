// Small reusable SVG icons for the game UI (coins, gems, etc.)
import type { SVGProps } from "react";

export function CoinIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 24 24" fill="none" {...props}>
      <circle cx="12" cy="12" r="10" fill="url(#coinG)" stroke="#b45309" strokeWidth="1.5" />
      <circle cx="12" cy="12" r="7" fill="none" stroke="#fde68a" strokeWidth="1.5" opacity="0.7" />
      <path
        d="M12 7.5l1.4 2.9 3.1.45-2.25 2.2.53 3.1L12 17.6l-2.78 1.46.53-3.1-2.25-2.2 3.1-.45L12 7.5z"
        fill="#fef3c7"
      />
      <defs>
        <radialGradient id="coinG" cx="0.35" cy="0.3" r="0.8">
          <stop offset="0" stopColor="#fde047" />
          <stop offset="0.6" stopColor="#f59e0b" />
          <stop offset="1" stopColor="#b45309" />
        </radialGradient>
      </defs>
    </svg>
  );
}

export function GemIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 24 24" fill="none" {...props}>
      <path
        d="M6 3h12l4 6-10 12L2 9l4-6z"
        fill="url(#gemG)"
        stroke="#0f766e"
        strokeWidth="1.4"
        strokeLinejoin="round"
      />
      <path d="M2 9h20" stroke="#5eead4" strokeWidth="1.2" opacity="0.8" />
      <path d="M9 3l-3 6 6 12 6-12-3-6" fill="none" stroke="#a7f3d0" strokeWidth="0.8" opacity="0.6" />
      <defs>
        <linearGradient id="gemG" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#5eead4" />
          <stop offset="0.5" stopColor="#14b8a6" />
          <stop offset="1" stopColor="#0d9488" />
        </linearGradient>
      </defs>
    </svg>
  );
}

export function PickaxeIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg viewBox="0 0 24 24" fill="none" {...props}>
      <path
        d="M3 4c4 0 9 1 12 4 3 3 4 8 4 12"
        stroke="currentColor"
        strokeWidth="2.2"
        strokeLinecap="round"
        fill="none"
      />
      <path
        d="M2.5 4.5C5 2.5 9 2 12 3.5L11 7c-2-1-5-.5-7 1L2.5 4.5z"
        fill="currentColor"
        opacity="0.9"
      />
    </svg>
  );
}
