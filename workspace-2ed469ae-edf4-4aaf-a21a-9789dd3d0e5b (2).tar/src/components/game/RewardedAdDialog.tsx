"use client";
import { useEffect, useRef, useState } from "react";
import { useMetaStore } from "@/store/metaStore";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useGameStore } from "@/store/gameStore";
import { useT } from "@/game/useT";
import { useActiveMineConfig } from "@/game/useMine";
import { estimateIncomeRate, AD_CASH_SECONDS } from "@/game/config";
import { formatNumber } from "@/lib/format";
import { CoinIcon, GemIcon } from "./icons";
import { Tv, Zap, Gift, Play, Check } from "lucide-react";
import type { AdRewardType } from "@/game/types";
import { toast } from "sonner";

const AD_DURATION = 5; // seconds of simulated ad

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
}

export function RewardedAdDialog({ open, onOpenChange }: Props) {
  const t = useT();
  const cfg = useActiveMineConfig();
  const claimAdReward = useGameStore((s) => s.claimAdReward);
  const mines = useGameStore((s) => s.mines);
  const activeMine = useGameStore((s) => s.activeMine);
  const [phase, setPhase] = useState<"choose" | "playing" | "done">("choose");
  const [selectedType, setSelectedType] = useState<AdRewardType | null>(null);
  const [countdown, setCountdown] = useState(AD_DURATION);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const rate = estimateIncomeRate(mines, cfg.baseOreValue, activeMine);
  const cashReward = Math.max(50, Math.floor(rate * AD_CASH_SECONDS));

  // Countdown timer effect (uses interval callback, not synchronous setState).
  useEffect(() => {
    if (phase !== "playing") return;
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(() => {
      setCountdown((c) => {
        if (c <= 1) {
          if (timerRef.current) clearInterval(timerRef.current);
          setPhase("done");
          return 0;
        }
        return c - 1;
      });
    }, 1000);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [phase]);

  const handleOpenChange = (v: boolean) => {
    if (!v) {
      // Reset state when closing (via event handler, not effect).
      setPhase("choose");
      setSelectedType(null);
      setCountdown(AD_DURATION);
    }
    onOpenChange(v);
  };

  const startAd = (type: AdRewardType) => {
    setSelectedType(type);
    setCountdown(AD_DURATION);
    setPhase("playing");
  };

  const claim = () => {
    if (!selectedType) return;
    const result = claimAdReward(selectedType);
    // Track ad watched for missions + achievements
    useMetaStore.getState().trackMission("watchAds", 1);
    useMetaStore.getState().incrementAdsWatched();
    if (selectedType === "cash" && typeof result === "number") {
      toast.success(`+${formatNumber(result)} coins!`, { description: "Instant cash reward" });
    } else if (selectedType === "boost") {
      toast.success("2× Boost activated!", { description: "Double income for 5 minutes" });
    } else {
      toast.success(`+${result || 5} gems!`, { description: "Free gems reward" });
    }
    handleOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="border-amber-900/50 bg-gradient-to-b from-stone-900 to-stone-950 text-amber-50 sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-lg font-bold text-amber-200">
            <Tv className="size-5" />
            {t("rewardedAd")}
          </DialogTitle>
        </DialogHeader>

        {phase === "choose" && (
          <div className="space-y-3 py-2">
            <RewardOption
              icon={<CoinIcon className="size-6" />}
              title={t("instantCash")}
              desc={t("instantCashDesc")}
              reward={`+${formatNumber(cashReward)}`}
              accent="from-amber-600 to-amber-800"
              onClick={() => startAd("cash")}
            />
            <RewardOption
              icon={<Zap className="size-6 text-yellow-300" />}
              title={t("boost2x")}
              desc={t("boost2xDesc")}
              reward="2× / 5min"
              accent="from-fuchsia-600 to-purple-800"
              onClick={() => startAd("boost")}
            />
            <RewardOption
              icon={<Gift className="size-6 text-teal-300" />}
              title={t("freeGems")}
              desc={t("freeGemsDesc")}
              reward="+5 💎"
              accent="from-teal-600 to-emerald-800"
              onClick={() => startAd("gems")}
            />
          </div>
        )}

        {phase === "playing" && (
          <div className="flex flex-col items-center gap-4 py-8">
            <div className="relative flex h-32 w-full items-center justify-center overflow-hidden rounded-xl border border-amber-900/40 bg-stone-800">
              <div
                className="absolute inset-0 opacity-20"
                style={{ background: `linear-gradient(135deg, ${cfg.accent}, ${cfg.rockTintDark})` }}
              />
              <Tv className="size-12 text-amber-300/70" />
              <div className="absolute bottom-2 right-2 rounded bg-black/60 px-2 py-0.5 text-xs font-bold text-white">
                {countdown}s
              </div>
              <div className="absolute bottom-0 left-0 h-1 bg-amber-500" style={{ width: `${((AD_DURATION - countdown) / AD_DURATION) * 100}%` }} />
            </div>
            <p className="text-sm text-amber-200/70">{t("adPlaying")}</p>
          </div>
        )}

        {phase === "done" && (
          <div className="flex flex-col items-center gap-4 py-6">
            <div className="flex size-16 items-center justify-center rounded-full bg-emerald-600 shadow-lg">
              <Check className="size-8 text-white" />
            </div>
            <p className="text-lg font-bold text-amber-100">{t("adComplete")}</p>
            {selectedType === "cash" && (
              <div className="flex items-center gap-2 rounded-lg border border-amber-400/40 bg-amber-900/30 px-4 py-2 text-lg font-bold text-amber-200">
                <CoinIcon className="size-5" /> +{formatNumber(cashReward)}
              </div>
            )}
            {selectedType === "boost" && (
              <div className="flex items-center gap-2 rounded-lg border border-fuchsia-400/40 bg-fuchsia-900/30 px-4 py-2 text-lg font-bold text-fuchsia-200">
                <Zap className="size-5" /> 2× {t("boostActive")}
              </div>
            )}
            {selectedType === "gems" && (
              <div className="flex items-center gap-2 rounded-lg border border-teal-400/40 bg-teal-900/30 px-4 py-2 text-lg font-bold text-teal-200">
                <GemIcon className="size-5" /> +5
              </div>
            )}
            <Button
              className="w-full bg-amber-600 text-stone-950 hover:bg-amber-500"
              size="lg"
              onClick={claim}
            >
              {t("claimReward")}
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

function RewardOption({
  icon,
  title,
  desc,
  reward,
  accent,
  onClick,
}: {
  icon: React.ReactNode;
  title: string;
  desc: string;
  reward: string;
  accent: string;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="flex w-full items-center gap-3 rounded-xl border border-stone-700 bg-stone-800/50 p-3 text-start transition hover:border-amber-700/50 hover:bg-stone-800 active:scale-[0.98]"
    >
      <div className={`flex size-12 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br ${accent} shadow`}>
        {icon}
      </div>
      <div className="min-w-0 flex-1">
        <div className="text-sm font-bold text-amber-100">{title}</div>
        <div className="text-xs text-amber-200/60">{desc}</div>
      </div>
      <div className="flex items-center gap-1 rounded-lg bg-stone-900/60 px-2 py-1 text-xs font-bold text-amber-300">
        {reward}
      </div>
      <Play className="size-4 text-amber-400" />
    </button>
  );
}
