"use client";
import { useGameStore } from "@/store/gameStore";
import { useActiveMineConfig } from "@/game/useMine";
import { elevatorCapacity } from "@/game/config";

/**
 * The single elevator serving every unlocked floor. Positioned absolutely over
 * the shaft column; its `top` is driven by the store's visual floor and
 * animated via CSS transition (duration synced to the movement phase).
 */
export function Elevator() {
  const m = useActiveMineConfig();
  const e = useGameStore((s) => s.mines[s.activeMine].elevator);
  const moving = e.phase === "descending" || e.phase === "ascending";
  const visualFloor = moving ? e.targetFloor : e.currentFloor;
  const dur = moving ? Math.round(e.phaseDuration * 1000) : 0;
  const cap = elevatorCapacity(e.capacityLevel);
  const fill = cap > 0 ? Math.min(1, e.cargo / cap) : 0;

  return (
    <div
      className="pointer-events-none absolute z-20"
      style={
        {
          top: "calc(var(--imt-surf-h) + (var(--imt-vfloor) - 1) * var(--imt-floor-h) + (var(--imt-floor-h) - 124px) / 2)",
          left: 0,
          width: "var(--imt-shaft-w)",
          height: "124px",
          "--imt-vfloor": visualFloor,
          transitionProperty: "top",
          transitionDuration: `${dur}ms`,
          transitionTimingFunction: "linear",
        } as React.CSSProperties
      }
    >
      {/* hoist cables */}
      <div className="absolute left-1/2 top-0 h-[4000px] w-px -translate-x-1/2 bg-gradient-to-b from-slate-300/70 to-slate-400/40" style={{ marginLeft: "-8px" }} />
      <div className="absolute left-1/2 top-0 h-[4000px] w-px -translate-x-1/2 bg-gradient-to-b from-slate-300/70 to-slate-400/40" style={{ marginLeft: "8px" }} />

      {/* manager badge (floating above elevator when hired) */}
      {e.managerHired && (
        <div className="absolute -top-3 left-1/2 z-30 -translate-x-1/2 rounded-full border border-emerald-400/60 bg-emerald-700/90 px-1.5 py-0.5 text-[8px] font-bold text-emerald-50 shadow-lg">
          AUTO
        </div>
      )}

      <svg viewBox="0 0 76 124" className="crisp absolute bottom-0 left-1/2 h-[124px] w-auto -translate-x-1/2" aria-hidden>
        <defs>
          <linearGradient id="el-frame" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#d97706" />
            <stop offset="1" stopColor="#92400e" />
          </linearGradient>
          <linearGradient id="el-ore" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor={m.oreGlow} />
            <stop offset="1" stopColor={m.oreColor} />
          </linearGradient>
        </defs>

        <rect x="6" y="104" width="64" height="12" rx="2" fill="url(#el-frame)" stroke="#451a03" strokeWidth="2" />
        <rect x="6" y="30" width="6" height="76" rx="2" fill="url(#el-frame)" stroke="#451a03" strokeWidth="1.5" />
        <rect x="64" y="30" width="6" height="76" rx="2" fill="url(#el-frame)" stroke="#451a03" strokeWidth="1.5" />
        <path d="M2 32 L38 14 L74 32 Z" fill="#7c2d12" stroke="#451a03" strokeWidth="2" strokeLinejoin="round" />
        <rect x="2" y="30" width="72" height="5" rx="2" fill="#92400e" stroke="#451a03" strokeWidth="1.5" />
        <rect x="12" y="36" width="52" height="68" fill="#1c1208" />

        {fill > 0 && (
          <rect
            x="14"
            y={104 - fill * 38}
            width="48"
            height={fill * 38}
            fill="url(#el-ore)"
            stroke={m.rockTintDark}
            strokeWidth="1"
          />
        )}
        {fill > 0.15 && <circle cx="24" cy="98" r="2.4" fill={m.oreGlow} className="imt-sparkle" style={{ color: m.oreGlow }} />}
        {fill > 0.3 && <circle cx="50" cy="94" r="2" fill={m.oreGlow} className="imt-sparkle" style={{ color: m.oreGlow, animationDelay: "0.6s" }} />}

        {/* operator */}
        <g>
          <rect x="33" y="58" width="10" height="20" rx="3" fill="#1f2937" />
          <circle cx="38" cy="54" r="5" fill="#f4c6a0" />
          <path d="M32 52 Q38 46 44 52 L44 50 Q38 44 32 50 Z" fill={e.managerHired ? "#22c55e" : "#fbbf24"} />
          <circle cx="38" cy="49" r="1.6" fill="#fef3c7" className="imt-lantern" />
        </g>

        {/* status lamp */}
        <circle cx="38" cy="22" r="3" fill={moving ? "#fbbf24" : "#22c55e"} className="imt-lantern" />
      </svg>

      {/* cargo badge */}
      <div className="absolute -right-1 top-2 z-30 rounded-full border border-amber-300/40 bg-stone-900/85 px-1.5 py-0.5 text-[9px] font-bold text-amber-200 shadow">
        {e.cargo}/{cap}
      </div>
    </div>
  );
}
