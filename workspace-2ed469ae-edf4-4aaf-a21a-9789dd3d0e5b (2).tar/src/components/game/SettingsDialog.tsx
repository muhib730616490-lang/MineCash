"use client";
import { useState } from "react";
import { PanelDialog } from "./PanelDialog";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useMetaStore } from "@/store/metaStore";
import { useGameStore } from "@/store/gameStore";
import { useT } from "@/game/useT";
import { LANGUAGES } from "@/game/i18n";
import type { Language } from "@/game/types";
import {
  Settings2,
  Volume2,
  VolumeX,
  Music,
  Music2,
  Bell,
  BellOff,
  Monitor,
  Shield,
  HelpCircle,
  Info,
  RotateCcw,
  ShoppingCart,
} from "lucide-react";
import { toast } from "sonner";

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onOpenHelp: () => void;
}

export function SettingsDialog({ open, onOpenChange, onOpenHelp }: Props) {
  const t = useT();
  const settings = useMetaStore((s) => s.settings);
  const setLanguage = useMetaStore((s) => s.setLanguage);
  const setMusic = useMetaStore((s) => s.setMusic);
  const setSound = useMetaStore((s) => s.setSound);
  const setNotifications = useMetaStore((s) => s.setNotifications);
  const setGraphics = useMetaStore((s) => s.setGraphicsQuality);
  const resetMeta = useMetaStore((s) => s.resetMeta);
  const resetGame = useGameStore((s) => s.resetGame);
  const setGameLanguage = useGameStore((s) => s.setLanguage);
  const [confirmReset, setConfirmReset] = useState(false);

  const handleLanguageChange = (l: Language) => {
    setLanguage(l);
    setGameLanguage(l);
  };

  const handleReset = () => {
    resetGame();
    resetMeta();
    setConfirmReset(false);
    onOpenChange(false);
    toast.success("Game reset");
  };

  return (
    <PanelDialog
      open={open}
      onOpenChange={onOpenChange}
      title={t("settings")}
      icon={<Settings2 className="size-5" />}
      description="Deep Delve — Idle Mining Tycoon"
    >
      {/* Language */}
      <SettingRow icon={<Settings2 className="size-4 text-amber-300" />} label={t("language")}>
        <Select value={settings.language} onValueChange={(v) => handleLanguageChange(v as Language)}>
          <SelectTrigger className="h-8 w-36 border-amber-900/40 bg-stone-900 text-xs">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="border-amber-900/40 bg-stone-900 text-amber-50">
            {LANGUAGES.map((l) => (
              <SelectItem key={l.id} value={l.id} className="text-xs">
                <span className="mr-1">{l.flag}</span>
                {l.nativeLabel}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </SettingRow>

      {/* Music */}
      <SettingRow icon={settings.musicOn ? <Music className="size-4 text-amber-300" /> : <Music2 className="size-4 text-stone-500" />} label={t("music")}>
        <Switch checked={settings.musicOn} onCheckedChange={setMusic} />
      </SettingRow>

      {/* Sound */}
      <SettingRow icon={settings.soundOn ? <Volume2 className="size-4 text-amber-300" /> : <VolumeX className="size-4 text-stone-500" />} label={t("sound")}>
        <Switch checked={settings.soundOn} onCheckedChange={setSound} />
      </SettingRow>

      {/* Notifications */}
      <SettingRow icon={settings.notificationsOn ? <Bell className="size-4 text-amber-300" /> : <BellOff className="size-4 text-stone-500" />} label={t("notifications")}>
        <Switch checked={settings.notificationsOn} onCheckedChange={setNotifications} />
      </SettingRow>

      {/* Graphics Quality */}
      <SettingRow icon={<Monitor className="size-4 text-amber-300" />} label={t("graphicsQuality")}>
        <Select value={settings.graphicsQuality} onValueChange={(v) => setGraphics(v as "low" | "medium" | "high")}>
          <SelectTrigger className="h-8 w-28 border-amber-900/40 bg-stone-900 text-xs">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="border-amber-900/40 bg-stone-900 text-amber-50">
            <SelectItem value="low" className="text-xs">{t("low")}</SelectItem>
            <SelectItem value="medium" className="text-xs">{t("medium")}</SelectItem>
            <SelectItem value="high" className="text-xs">{t("high")}</SelectItem>
          </SelectContent>
        </Select>
      </SettingRow>

      {/* Privacy */}
      <button
        onClick={() => toast.info(t("privacy") + " — " + t("aboutDesc"))}
        className="flex w-full items-center gap-3 rounded-lg border border-amber-900/30 bg-stone-800/40 p-3 text-start transition hover:bg-stone-800/60"
      >
        <Shield className="size-4 text-amber-300" />
        <span className="flex-1 text-sm font-medium text-amber-100">{t("privacy")}</span>
        <span className="text-xs text-stone-500">›</span>
      </button>

      {/* Help */}
      <button
        onClick={() => {
          onOpenChange(false);
          onOpenHelp();
        }}
        className="flex w-full items-center gap-3 rounded-lg border border-amber-900/30 bg-stone-800/40 p-3 text-start transition hover:bg-stone-800/60"
      >
        <HelpCircle className="size-4 text-amber-300" />
        <span className="flex-1 text-sm font-medium text-amber-100">{t("help")}</span>
        <span className="text-xs text-stone-500">›</span>
      </button>

      {/* About */}
      <button
        onClick={() => toast.info(t("about"), { description: t("aboutDesc") })}
        className="flex w-full items-center gap-3 rounded-lg border border-amber-900/30 bg-stone-800/40 p-3 text-start transition hover:bg-stone-800/60"
      >
        <Info className="size-4 text-amber-300" />
        <span className="flex-1 text-sm font-medium text-amber-100">{t("about")}</span>
        <span className="text-xs text-stone-500">›</span>
      </button>

      {/* Restore Purchases */}
      <button
        onClick={() => toast.info(t("restorePurchasesDesc"))}
        className="flex w-full items-center gap-3 rounded-lg border border-amber-900/30 bg-stone-800/40 p-3 text-start transition hover:bg-stone-800/60"
      >
        <ShoppingCart className="size-4 text-amber-300" />
        <span className="flex-1 text-sm font-medium text-amber-100">{t("restorePurchases")}</span>
        <span className="text-xs text-stone-500">›</span>
      </button>

      {/* Reset */}
      {!confirmReset ? (
        <Button
          variant="outline"
          className="w-full border-red-900/50 bg-red-950/30 text-red-300 hover:bg-red-900/40 hover:text-red-200"
          onClick={() => setConfirmReset(true)}
        >
          <RotateCcw className="size-4" />
          {t("resetGame")}
        </Button>
      ) : (
        <div className="space-y-2 rounded-lg border border-red-900/50 bg-red-950/30 p-3">
          <p className="text-center text-xs text-red-200">{t("resetConfirm")}</p>
          <div className="flex gap-2">
            <Button
              variant="outline"
              className="flex-1 border-stone-600 bg-transparent text-amber-100"
              onClick={() => setConfirmReset(false)}
            >
              {t("cancel")}
            </Button>
            <Button variant="destructive" className="flex-1" onClick={handleReset}>
              {t("confirm")}
            </Button>
          </div>
        </div>
      )}
    </PanelDialog>
  );
}

function SettingRow({ icon, label, children }: { icon: React.ReactNode; label: string; children: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-lg border border-amber-900/30 bg-stone-800/40 p-3">
      <div className="flex items-center gap-2">
        {icon}
        <Label className="text-sm font-medium">{label}</Label>
      </div>
      {children}
    </div>
  );
}
