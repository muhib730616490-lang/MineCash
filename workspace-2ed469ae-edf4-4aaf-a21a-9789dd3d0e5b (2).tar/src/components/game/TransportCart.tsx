"use client";
import { useGameStore } from "@/store/gameStore";
import { useActiveMineConfig } from "@/game/useMine";
import { cartCapacity } from "@/game/config";

/**
 * The single transport cart that carries ore from the warehouse off-screen to
 * sell. Moves along the surface track via CSS transition driven by the store.
 */
export function TransportCart() {
  const m = useActiveMineConfig();
  const cart = useGameStore((s) => s.mines[s.activeMine].cart);
  const moving = cart.phase === "departing" || cart.phase === "returning";
  const cap = cartCapacity(cart.capacityLevel);
  const fill = cap > 0 ? Math.min(1, cart.cargo / cap) : 0;

  return (
    <div
      className="pointer-events-none absolute bottom-1 z-30"
      style={
        {
          left: "calc(var(--imt-pos) * (100% - 74px))",
          width: "74px",
          "--imt-pos": cart.position,
          transitionProperty: "left",
          transitionDuration: moving ? `${Math.round(cart.phaseDuration * 1000)}ms` : "0ms",
          transitionTimingFunction: "cubic-bezier(0.4, 0, 0.2, 1)",
        } as React.CSSProperties
      }
    >
      <svg viewBox="0 0 90 64" className="crisp h-auto w-full" aria-hidden>
        <defs>
          <linearGradient id="tc-body" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#a86a33" />
            <stop offset="1" stopColor="#6e4218" />
          </linearGradient>
          <linearGradient id="tc-ore" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor={m.oreGlow} />
            <stop offset="1" stopColor={m.oreColor} />
          </linearGradient>
        </defs>

        {/* ore load (height by fill) */}
        {fill > 0 && (
          <g>
            <rect
              x="16"
              y={44 - fill * 24}
              width="58"
              height={fill * 24}
              rx="3"
              fill="url(#tc-ore)"
              stroke={m.rockTintDark}
              strokeWidth="1"
            />
            <circle cx="26" cy={42 - fill * 20} r="3" fill={m.oreGlow} className="imt-sparkle" style={{ color: m.oreGlow }} />
            <circle cx="48" cy={40 - fill * 22} r="2.4" fill={m.oreGlow} className="imt-sparkle" style={{ color: m.oreGlow, animationDelay: "0.7s" }} />
            <circle cx="62" cy={44 - fill * 18} r="2.2" fill={m.oreGlow} className="imt-sparkle" style={{ color: m.oreGlow, animationDelay: "1.2s" }} />
          </g>
        )}

        {/* cart body (trapezoid) */}
        <path
          d="M10 44 L16 22 L74 22 L80 44 Z"
          fill="url(#tc-body)"
          stroke="#4a2c10"
          strokeWidth="2"
          strokeLinejoin="round"
        />
        <rect x="14" y="42" width="62" height="6" rx="2" fill="#6e4218" stroke="#4a2c10" strokeWidth="1.5" />

        {/* wheels */}
        <circle cx="26" cy="50" r="8" fill="#2a1a0c" stroke="#6b4226" strokeWidth="2.5" />
        <circle cx="26" cy="50" r="2.5" fill="#caa15a" />
        <circle cx="64" cy="50" r="8" fill="#2a1a0c" stroke="#6b4226" strokeWidth="2.5" />
        <circle cx="64" cy="50" r="2.5" fill="#caa15a" />

        {/* coupling */}
        <line x1="80" y1="40" x2="88" y2="40" stroke="#4a2c10" strokeWidth="2.5" strokeLinecap="round" />
      </svg>

      {/* cargo badge while carrying */}
      {cart.cargo > 0 && (
        <div className="absolute -top-3 left-1/2 z-30 -translate-x-1/2 rounded-full border border-amber-300/50 bg-stone-900/90 px-1.5 py-0.5 text-[10px] font-bold text-amber-200 shadow-lg">
          {cart.cargo}
        </div>
      )}
    </div>
  );
}
