"use client";
import { PanelDialog } from "./PanelDialog";
import { useMetaStore } from "@/store/metaStore";
import { useGameStore } from "@/store/gameStore";
import { useT } from "@/game/useT";
import { getMineConfig, MINES, FLOOR_COUNT } from "@/game/config";
import { formatNumber } from "@/lib/format";
import { formatTime } from "@/lib/format";
import { CoinIcon, GemIcon } from "./icons";
import { User, Clock, Pickaxe, Users, Trophy, Target, Share2 } from "lucide-react";

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
}

export function ProfileDialog({ open, onOpenChange }: Props) {
  const t = useT();
  const account = useMetaStore((s) => s.account);
  const profile = useMetaStore((s) => s.profile);
  const referral = useMetaStore((s) => s.referral);
  const achievements = useMetaStore((s) => s.achievements);
  const missions = useMetaStore((s) => s.missions);
  const coins = useGameStore((s) => s.coins);
  const gems = useGameStore((s) => s.gems);
  const activeMine = useGameStore((s) => s.activeMine);
  const mines = useGameStore((s) => s.mines);

  const cfg = getMineConfig(activeMine);
  // Find current deepest unlocked floor
  const activeMineRuntime = mines[activeMine];
  let currentFloor = 1;
  if (activeMineRuntime) {
    for (let i = FLOOR_COUNT - 1; i >= 0; i--) {
      if (activeMineRuntime.floors[i].unlocked) {
        currentFloor = i + 1;
        break;
      }
    }
  }

  const unlockedAchievements = achievements.filter((a) => a.unlocked).length;
  const completedMissions = missions.filter((m) => m.completed).length;

  return (
    <PanelDialog
      open={open}
      onOpenChange={onOpenChange}
      title={t("profile")}
      icon={<User className="size-5" />}
    >
      {/* Player name + account */}
      <div className="flex items-center gap-3 rounded-xl border border-amber-900/40 bg-stone-800/40 p-3">
        <div className="flex size-12 items-center justify-center rounded-full bg-gradient-to-br from-amber-600 to-amber-800 text-lg font-bold text-stone-950">
          {profile.name.charAt(0).toUpperCase()}
        </div>
        <div className="flex-1">
          <div className="text-sm font-bold text-amber-100">{profile.name}</div>
          <div className="text-[10px] text-amber-200/60">
            {account.type === "google" ? `Google: ${account.googleEmail}` : t("quickStart")}
          </div>
        </div>
        <span className="rounded-full border border-emerald-600/40 bg-emerald-900/30 px-2 py-0.5 text-[9px] font-bold text-emerald-300">
          {account.type === "google" ? "Google" : "Local"}
        </span>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 gap-2">
        <StatCard icon={<CoinIcon className="size-4" />} label={t("coins")} value={formatNumber(coins)} accent="text-amber-300" />
        <StatCard icon={<GemIcon className="size-4" />} label={t("gems")} value={formatNumber(gems)} accent="text-teal-300" />
        <StatCard icon={<Pickaxe className="size-4 text-orange-400" />} label={t("currentMine")} value={cfg.name} accent="text-orange-300" />
        <StatCard icon={<Pickaxe className="size-4 text-sky-400" />} label={t("currentFloor")} value={`${currentFloor}/${FLOOR_COUNT}`} accent="text-sky-300" />
        <StatCard icon={<Clock className="size-4 text-purple-400" />} label={t("playTime")} value={formatTime(profile.totalPlayTime)} accent="text-purple-300" />
        <StatCard icon={<Trophy className="size-4 text-yellow-400" />} label={t("achievements")} value={`${unlockedAchievements}/${achievements.length}`} accent="text-yellow-300" />
      </div>

      {/* Referral stats */}
      <div className="rounded-xl border border-amber-900/40 bg-stone-800/40 p-3">
        <div className="mb-2 flex items-center gap-2 text-xs font-bold text-amber-200">
          <Share2 className="size-4" /> {t("referralStats")}
        </div>
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div className="rounded bg-stone-900/60 p-2">
            <div className="text-stone-400">{t("invitedFriends")}</div>
            <div className="text-lg font-bold text-amber-200">{referral.totalInvited}</div>
          </div>
          <div className="rounded bg-stone-900/60 p-2">
            <div className="text-stone-400">{t("active")}</div>
            <div className="text-lg font-bold text-emerald-300">{referral.activeInvited}</div>
          </div>
        </div>
      </div>

      {/* Mission progress */}
      <div className="rounded-xl border border-amber-900/40 bg-stone-800/40 p-3">
        <div className="mb-1 flex items-center gap-2 text-xs font-bold text-amber-200">
          <Target className="size-4" /> {t("missionProgress")}
        </div>
        <div className="text-xs text-amber-200/70">
          {completedMissions}/{missions.length} {t("missions")} {t("completed" as string) || "completed"}
        </div>
        <div className="mt-1 h-2 overflow-hidden rounded-full bg-stone-900">
          <div
            className="h-full bg-gradient-to-r from-amber-500 to-amber-400 transition-all"
            style={{ width: `${missions.length > 0 ? (completedMissions / missions.length) * 100 : 0}%` }}
          />
        </div>
      </div>
    </PanelDialog>
  );
}

function StatCard({ icon, label, value, accent }: { icon: React.ReactNode; label: string; value: string; accent: string }) {
  return (
    <div className="rounded-lg border border-stone-700/50 bg-stone-800/40 p-2.5">
      <div className="flex items-center gap-1 text-[10px] text-stone-400">
        {icon}
        {label}
      </div>
      <div className={`mt-0.5 truncate text-sm font-bold ${accent}`}>{value}</div>
    </div>
  );
}
